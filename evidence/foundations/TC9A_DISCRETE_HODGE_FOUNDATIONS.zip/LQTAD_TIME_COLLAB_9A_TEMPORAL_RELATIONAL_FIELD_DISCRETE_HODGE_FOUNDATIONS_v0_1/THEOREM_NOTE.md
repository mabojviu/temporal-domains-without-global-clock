# TIME-COLLAB-9A — Temporal Relational Field / Discrete Hodge Foundations

## 1. Temporal scale connection

For an oriented CAL relation i->j with positive relative scale a_{j<-i}, define

    gamma_ij = log a_{j<-i}.

The logarithm is used only to linearize the positive multiplicative scale group. Exact
finite proofs may treat gamma directly as an additive group element.

A local chart rescaling c_i>0, q_i=log c_i, acts as

    gamma -> gamma + D0 q.

Therefore the physically meaningful calibration information must live in the gauge quotient
C^1 / im(D0), unless a gauge is explicitly fixed.

## 2. Curl / circulation

If the relational atlas supplies registered compositional 2-cells F, define

    curl gamma = D1 gamma.

Because D1 D0 = 0,

    D1(gamma + D0 q) = D1 gamma.

So registered-cell curl is gauge-invariant.

Crucial restriction: a bare graph has no preferred 2-cells. In that case one may discuss
cycle periods/holonomy, but not pretend that a local curl has been defined by spatial faces.

## 3. Divergence

With unit weights,

    div gamma = -D0^T gamma.

Under gauge transformation,

    div(gamma + D0 q) = div gamma - L0 q,
    L0 = D0^T D0.

Thus raw divergence is gauge-dependent. It is mathematically definable but is not presently
a gauge-invariant physical observable. Calling it a source or sink of time would be premature.

## 4. Hodge decomposition

For a finite registered relational 2-complex,

    gamma = D0 s + D1^T psi + h,

where

    h in ker(D0^T) intersect ker(D1).

The three sectors are:

- exact / gradient: compatible with a scalar log-scale potential;
- coexact / circulatory: local gauge-invariant curl content;
- harmonic: curl-free and divergence-free but globally non-exact.

This last sector is essential for the temporal-domain program. A nontrivial harmonic period
can obstruct a single global scalar clock even when every registered local curl vanishes.

## 5. Scalarization criterion

A common global scale potential exists exactly when

    gamma in im(D0).

Therefore

    curl gamma = 0

is not sufficient on complexes with nontrivial H^1. One must also eliminate the harmonic
cohomology class / all independent cycle periods.

Nothing here is yet spacetime curvature, a gravitational field, or a source equation.
