# TIME-COLLAB-9A result

`PASS_TIME_COLLAB_9A_TEMPORAL_RELATIONAL_FIELD_DISCRETE_HODGE_FOUNDATIONS`

Exact audit: 16/16 PASS.

The main result is a restriction as important as the construction itself:

1. `gamma_ij = log a_ij` naturally behaves as a discrete temporal calibration 1-cochain.
2. Its relational curl `D1 gamma` is gauge-invariant whenever the atlas explicitly supplies
   compositional 2-cells.
3. Its raw divergence `-D0^T gamma` is **not** gauge-invariant; under local clock rescaling
   it changes by `-L0 q`.
4. Hodge decomposition separates exact/gradient, coexact/circulatory, and harmonic sectors.
5. A nonzero harmonic sector can be locally curl-free yet obstruct global scalarization.
6. Without registered 2-cells, a graph supplies holonomy/cycle periods, not a local curl field.

This gives a mathematically controlled route from temporal domains to a relational temporal
field, while blocking premature identifications with spacetime geometry or gravity.
