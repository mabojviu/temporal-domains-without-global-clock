# TIME-COLLAB-8A — Temporal domains and partial glue

The central distinction is that "common time" is not one binary property.

For two internally coherent temporal domains A and B:

1. **No active ORD/CAL relation**  
   Their relative affine gauge is unidentifiable. There is no cross-domain precedence.

2. **ORD-only interaction**  
   A cross-domain precedence can make only a subset of event pairs comparable. This is
   a genuine partial common temporal order, but it supplies no affine clock calibration.

3. **One CAL relation**  
   If both domains are internally affine-scalarizable, one CAL bridge fixes their relative
   Aff+(1) gauge and therefore allows a common scalarization. But there is no independent
   cycle with which to falsify that cross-domain calibration; the glue is nonredundant.

4. **Redundant CAL relations**  
   Each cross link independently infers a relative domain transformation

   K_BA = H_b g_{b<-a} H_a^{-1}.

   The union is jointly scalarizable iff all inferred K_BA agree. Equivalently, all CAL
   cycle holonomies are identity. A disagreement can obstruct a global scalar reduction
   while both domains remain internally coherent.

For a connected graph of domains, arbitrary CAL data on a tree always integrates; cycles
are required for redundant falsification. Exact enumeration over every connected domain
graph with 2..5 vertices verifies the cycle-holonomy criterion.

Active split is also typed. Removing all active cross-domain ORD/CAL links separates active
temporal coordination. Historical provenance remains, but cannot create future comparisons.
A later reglue requires a fresh active temporal relation.

This formalizes "temporal islands" as a relational possibility without assuming that nature
literally has such islands.
