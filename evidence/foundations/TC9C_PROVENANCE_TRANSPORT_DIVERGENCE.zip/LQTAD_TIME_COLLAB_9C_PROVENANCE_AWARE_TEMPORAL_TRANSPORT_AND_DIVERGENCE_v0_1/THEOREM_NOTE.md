# TIME-COLLAB-9C — Provenance-Aware Temporal Transport and Divergence

## 1. Why divergence must act on a current, not on gamma

TC9A/9B established that the raw calibration connection gamma is gauge-dependent and that
-D0^T gamma cannot be a physical source density.

TC9C therefore introduces a different object:

    J_e

a gauge-invariant temporal-content current attached to a local micro-event e.

The divergence operator is applied to J_e, not to gamma.

## 2. Provenance selects transport

Each event supplies a finite rooted provenance tree T_e with write-anchor r_e.

Let

    Delta rho_v = rho_v^+ - rho_v^-,

where rho is the gauge-invariant TC9B density.

For a tree edge parent p -> child c define

    J_e(p->c) = sum_{v in subtree(c)} Delta rho_v.

Define

    (div_T J)_v = outgoing current - incoming current.

Then exactly

    Delta rho + div_T J = S.

For every non-root vertex,

    S_v = 0,

while at the write-anchor,

    S_r = sum_v Delta rho_v.

Thus the provenance tree gives a unique local decomposition into transport plus net
production/removal.

## 3. Interpretation

If

    sum_v Delta rho_v = 0,

then S=0 and the update is pure redistribution.

If the sum is positive, the event produces gauge-invariant nonintegrable temporal-calibration
content. If negative, it removes such content.

This does not mean creation or destruction of physical time itself.

## 4. Why provenance is necessary

On a graph with cycles, the divergence equation alone does not determine J uniquely:
one may add any divergence-free cycle current. A rooted event-provenance tree removes this
ambiguity without invoking a global graph optimizer or gauge fixing.

Changing the provenance root changes the spatialization of transport/source within the event
patch, but not the total production. That dependence is intentional: provenance is part of
the microdynamics, not a clock gauge.

## 5. Resulting differential vocabulary

The theory now supports three differently typed operations:

    gradient:   D0 s              on the scalarizable temporal potential sector
    curl:       D1 gamma          on registered CAL 2-cells
    divergence: div_T J           on gauge-invariant provenance-selected temporal current

They are not three operations on the same primitive field. Their typing is what keeps the
construction gauge-consistent.
