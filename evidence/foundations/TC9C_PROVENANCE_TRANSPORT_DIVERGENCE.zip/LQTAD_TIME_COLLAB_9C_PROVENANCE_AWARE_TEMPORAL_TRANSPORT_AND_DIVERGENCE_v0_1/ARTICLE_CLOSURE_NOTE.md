# Article closure note after TC9C

TC9C supplies the missing plausible divergence sector.

The paper can now state, with explicit typing:

1. **Temporal gradient**
   The exact sector D0 s represents globally integrable relative clock-scale structure.

2. **Temporal curl / circulation**
   D1 gamma is gauge-invariant on registered relational CAL 2-cells; cycle periods capture
   harmonic/global obstruction.

3. **Temporal divergence**
   Raw div gamma is forbidden as physical because it is gauge-dependent.
   A legitimate divergence acts instead on a gauge-invariant temporal-content current J
   selected by local event provenance:

       Delta rho + div_T J = S.

   This separates redistribution (S=0) from production/removal (S != 0) of nonintegrable
   temporal-calibration structure.

## Recommended manuscript claim

A finite relational event network can support coherent and partially shared temporal
structure without a primitive global scalar clock. Its calibration sector admits a
gauge-covariant connection, gauge-invariant circulation/holonomy, an exact/coexact/harmonic
Hodge decomposition, and—once micro-event provenance selects a local transport current—a
gauge-invariant continuity equation that distinguishes transport from production/removal of
nonintegrable temporal-calibration content.

## Still excluded

The manuscript must not claim:
- literal creation/destruction of physical time;
- continuum spacetime;
- Lorentz symmetry;
- a spacetime metric;
- gravity or Einstein equations;
- that the relational complex is spatial geometry.

A topology-changing/noisy extension would strengthen the next paper or a later revision,
but is not logically required to make the present divergence construction complete.
