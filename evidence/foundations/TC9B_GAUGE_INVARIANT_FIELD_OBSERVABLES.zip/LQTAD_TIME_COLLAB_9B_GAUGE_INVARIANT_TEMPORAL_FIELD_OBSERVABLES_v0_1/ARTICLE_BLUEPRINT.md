# Article blueprint

## Provisional title

**Temporal Domains Without a Global Clock: Partial Gluing, Holonomy, and Gauge-Invariant Field Structure in Finite Relational Event Networks**

## Core paper claim

A finite relational event network can possess coherent, typed, partially shared temporal
structure without requiring a primitive globally scalar clock. Global scalarization is a
special integrable reduction of a richer temporal atlas.

## Suggested structure

1. Introduction: global scalar time as an optional reduction.
2. Local temporal ontology: ORD, CAL, CORR and active provenance.
3. Relational coherence with global scalar deconditioning (TC7 / CERT-016).
4. Temporal domains and partial glue (TC8A).
5. Matched-connectivity holdout: connectivity is not temporality (TC8H / CERT-017).
6. Temporal scale connection gamma_ij=log a_{j<-i}.
7. Discrete Hodge decomposition: exact, coexact, harmonic sectors (TC9A).
8. No-go for naive temporal divergence (TC9B).
9. Gauge-invariant dynamic production of nonintegrable temporal calibration content.
10. Limitations and next falsification tests.

## Candidate headline equations

    gamma -> gamma + D0 q
    F = D1 gamma
    gamma = D0 s + D1^T psi + h
    P_perp D0 = 0
    eta = P_perp gamma
    E_inv = ||eta||^2
    rho_i = 1/2 sum_{e incident i} eta_e^2
    sigma_i = rho_i(t+1)-rho_i(t)

## What must remain out of the paper's claims

No continuum theorem, Lorentz symmetry, spacetime metric, gravity, Einstein equations,
or literal claim that nature is composed of temporal islands.
