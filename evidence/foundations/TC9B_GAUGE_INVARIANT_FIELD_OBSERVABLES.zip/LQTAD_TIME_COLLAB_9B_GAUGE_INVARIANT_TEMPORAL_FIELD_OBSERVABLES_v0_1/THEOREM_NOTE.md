# TIME-COLLAB-9B — Gauge-Invariant Temporal-Field Observables

## Static source no-go

For the temporal scale connection gamma, a local clock rescaling acts by

    gamma -> gamma + D0 q.

A weighted incidence divergence

    A gamma = -D0^T W gamma

would be gauge-invariant only if A D0=0. But

    A D0 = -D0^T W D0 = -L_W.

For positive W on a connected graph, L_W is nonzero on every nonconstant gauge mode.
Therefore a nontrivial positive-weight raw divergence of gamma cannot define a gauge-invariant
static temporal source density.

Registered-cell curvature F=D1 gamma is gauge-invariant. The associated coexact current

    J_curv = D1^T F

is also gauge-invariant, but

    D0^T J_curv = (D1 D0)^T F = 0.

So static curvature circulation also cannot provide a nonzero vertex source/sink.

## Canonical invariant content

Let P_perp be the orthogonal projector onto the complement of im(D0), and define

    eta = P_perp gamma.

Then eta is gauge-invariant and vanishes for globally scalarizable CAL scale connections.

Define

    E_inv = ||eta||^2

and

    rho_i = 1/2 sum_{e incident i} eta_e^2.

Then rho_i is gauge-invariant and sum_i rho_i=E_inv.

## Dynamic production

Across two updates, with independently chosen local clock gauges at each update,

    sigma_i = rho_i(t+1)-rho_i(t)

remains gauge-invariant. Likewise,

    Delta E_inv = sum_i sigma_i.

On a fixed complex,

    Delta E_inv = Delta E_coexact + Delta E_harmonic.

This measures production/removal of nonintegrable temporal calibration structure.

It does NOT yet distinguish local production from redistribution, because a continuity equation

    Delta rho + div J = S

requires a transport current J selected by microdynamics/provenance. Kinematics alone does not
choose that current uniquely.
