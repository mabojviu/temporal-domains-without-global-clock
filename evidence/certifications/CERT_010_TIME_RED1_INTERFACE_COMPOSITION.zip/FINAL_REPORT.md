# TIME-RED-1 Scientific Attempt 1 — Independent Adjudication

## Final adjudication
**PASS_CLEAN**

Independent audit: **76/76 PASS**.

The official frozen runner and this independent adjudication agree exactly. The consumed one-shot authorization `LQTAD-TIME-RED1-SCIENTIFIC-ATTEMPT1-19C0172F48724C15` completed all 156 authorized cases, persisted all 156 results, produced no witnesses, and returned no terminal error.

## Scientific counts
- Training: 78/78 PASS
- Unseen holdout: 78/78 PASS
- E1: 156/156 PASS
- E2: 156/156 PASS
- E1/E2 agreement: 156/156
- Independent reference where required: 48/48 agreement
- Counterexample/inconclusive witnesses: 0

## Cryptographic anchors
- Return ZIP SHA-256: `000533c00d5e62b3baacfe30ab2dc5209b7acb854c9d0e25a6cb315c9327cb64`
- CASE_SET SHA-256: `392a7d07831950a2f207a7f7d00c6806df45b444c8a496bdf1e1defcbcbc5ce0`
- Freeze root: `b28592282482dc9357daf3421e0c379769e8d82c97920ff42d9241323ac8bc6a`
- Authorization: `LQTAD-TIME-RED1-SCIENTIFIC-ATTEMPT1-19C0172F48724C15` — CONSUMED

## Certificate
`CERT-010` is assigned as:

**TIME-RED-1 Transverse Relational-Time and Interface-Composition Qualification**

Status: `CLOSED_QUALIFIED_WITHIN_FROZEN_DECLARED_DOMAIN`.

This certifies only the finite frozen declared TIME-RED-1 domain and claims C01-C08. It does **not** establish universal or fundamental time emergence, a continuum limit, relativity, gravity, microcausality, or universal unravelling independence.

## Governance
Attempt 1 is consumed. It must not be rerun or replayed under the same authorization.
