# TIME-COLLAB-3H — Final Adjudication / CERT-011

## Verdict

**Official holdout:** `PASS_ROBUSTNESS_GENERICITY_HOLDOUT`

**Independent final audit:** `PASS_TIME_COLLAB_3H_SCIENTIFIC_ATTEMPT_1_INDEPENDENT_FINAL_AUDIT` — **46/46 PASS**

**Certificate:** `CERT-011 — CLOSED_QUALIFIED_WITHIN_FROZEN_HOLDOUT_DOMAIN`

## Governance

- Authorization: `LQTAD-TIME-COLLAB-3H-SCIENTIFIC-ATTEMPT1-8AFAB90FEDC58BCD`
- Terminal authorization state: `CONSUMED`
- Return SHA-256: `95655b7461df1cadb9e91b71be9c037e2450fa89dc52816b8d881ca591af7046`
- CASE_SET SHA-256: `6723a07feb3d3cdc266ea28203849315605ed36369c99174f1668319901fc2f2`
- Freeze root: `7605dafed6fe36db617b381817fea83192634b2612c133ba6edb1a9f1f97cf85`
- Scientific records: 288/288
- Frozen evaluator independently reproduced 288/288 records exactly.
- Frozen adjudicator independently reproduced H0-H8 and the final verdict.

## Scientific result

The substantive primary effect was **kappa > 2**, not the weaker endpoint floor kappa >= 2.

- SPARSE_BASE: **64/64** kappa>2; preregistered minimum 24/64.
- SHORTCUT_STRESS: **44/64** kappa>2; minimum 12/64.
- TOKEN_LOSS: **43/64** remained connected; all **43/43** connected cases retained kappa>2.
- RICH_RULE: **64/64** nonconstant and **64/64** kappa>2.
- Positive chain controls: **16/16** kappa=n.
- Negative direct-bypass controls: **16/16** kappa=2.

Importantly, adversity was visible rather than erased:
- **20/64 SHORTCUT_STRESS** cases collapsed to endpoint-only kappa=2.
- **21/64 TOKEN_LOSS** cases became disconnected.

Thus the holdout passes with substantial margins while still showing the expected failure/degradation channels.

## Scope

CERT-011 qualifies robustness only in the frozen finite ensembles and under the frozen generator, evaluator, target and thresholds. It is not a universal genericity theorem, a confinement theorem, a derivation of locality, or a result about continuum spacetime, relativity, or gravity.
