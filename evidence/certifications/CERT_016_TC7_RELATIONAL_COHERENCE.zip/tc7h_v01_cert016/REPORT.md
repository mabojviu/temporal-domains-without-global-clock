# TIME-COLLAB-7H v0.1 — Final audit and CERT-016

## Result

`PASS_RELATIONAL_COHERENCE_WITH_GLOBAL_SCALAR_DECONDITIONING`

All frozen H0-H10 pass.

Post-return audit:
`PASS_TC7H_V01_POSTRETURN_AUDIT_WITH_NUMERICAL_REPRODUCIBILITY_ADDENDUM`

Global audit:
`PASS_TIME_COLLAB_GLOBAL_AUDIT_9_TC7H_V01_POSTRETURN_WITH_NUMERICAL_REPRODUCIBILITY_ADDENDUM`

## Central separation

LOCAL_MISMATCH_SCALE:
- N=24: 12/12
- N=48: 12/12
- N=96: 12/12
- N=192: 12/12
- total: 48/48

Local prediction p90:
- N=24: 0.0099491134
- N=192: 0.0098429345
- ratio: 0.989328

Global scalar effective resistance:
- R(24)=4.9577708766
- R(48)=9.7577708764
- R(96)=19.3577708764
- R(192)=38.5577708764
- log-log slope=0.986606
- R(192)/R(48)=3.951494

Thus the tested finite model shows the preregistered decoupling:
bounded-radius relational coherence remains stable while global scalar synchronization
becomes increasingly ill-conditioned.

Negative controls also behave as preregistered:
- modest local dropout: {24: 9, 48: 10, 96: 10, 192: 10}
- strong local loss+noise: {24: 0, 48: 0, 96: 0, 192: 0}
- dense gaps: {24: 0, 48: 0, 96: 0, 192: 0}
- sparse gaps: {24: 0, 48: 0, 96: 0, 192: 0}
- severe redundancy collapse: {24: 0, 48: 0, 96: 0, 192: 0}; N192 median triangle density=0.424479

Maximum local noise envelope=0.0116657222<0.03.

## Reproducibility

Cross-platform replay is not bitwise-identical in 4/216 records.
Maximum numeric difference=4.441e-16. There are zero structural or classification
mismatches, and H0-H10 plus the verdict reproduce exactly.

Three exact primary-threshold contacts occur at triangle_density=0.75, all in the strong
negative-control family. That field is discrete/combinatorial and is exactly invariant
between runtimes; it is not one of the floating fields that differs.

This is not a continuum or relativity theorem.
