# TIME-COLLAB-6H v0.2 — Final audit and CERT-015

## Scientific verdict

`PASS_SCALE_COMPATIBILITY_WITH_OBSTRUCTION_CONTROLS`

All frozen scientific gates H0-H11 pass.

Post-return audit:
`PASS_TC6H_V02_POSTRETURN_AUDIT_WITH_NUMERICAL_REPRODUCIBILITY_ADDENDUM`

Global audit:
`PASS_TIME_COLLAB_GLOBAL_AUDIT_7_TC6H_V02_POSTRETURN_WITH_NUMERICAL_REPRODUCIBILITY_ADDENDUM`

## Numerical reproducibility note

Cross-platform replay is **not bitwise identical**. 180/192 records differ in least-squares-derived
floating values, but the maximum absolute discrepancy is only `9.159e-16`.

There are:
- 0 structural mismatches,
- 0 classification mismatches,
- exact H0-H11 gate reproduction,
- exact verdict reproduction.

The nearest scientific numeric threshold lies `3.857e-05` away, giving a threshold-margin
to runtime-delta ratio of approximately `4.211e+10`.

This is recorded explicitly as a technical reproducibility addendum. No scientific rule was altered.

## Scale result

CALIBRATION_MISMATCH_SCALE:
- N=12: 11/12
- N=24: 12/12
- N=48: 12/12
- N=72: 12/12
- total: 47/48

Median LOEO p90 ratio N72/N12: `1.013668`.

REDUNDANCY_EROSION at N=72:
- macro-compatible: 3/9
- bridged: 6/9

CHURN_PLUS_NOISE:
- N=12: 0/9 macro-compatible
- N=24: 0/9
- N=48: 0/9
- N=72: 0/9

Maximum noise envelope: `0.0126269108 < 0.12`.

## Interpretation

Within the frozen finite sizes N={12,24,48,72}, the same fixed-resolution relational predictor
remains compatible under unseen calibration mismatch without retuning by size. Deliberate loss
of redundancy and stronger churn+noise obstruct it as preregistered.

This is not an asymptotic, continuum, spacetime, Lorentzian or gravitational result.
