# TIME-COLLAB-GLOBAL-AUDIT-0 v1.1

## Terminal verdict

The global freeze **failed on first adversarial pass**.

- Pre-repair verdict: `FAIL_GLOBAL_FREEZE_BLOCKED`
- Substantive blockers found: **6**
- Nonretroactive repairs/addenda: **GA0-R01 through GA0-R06**
- Post-repair verdict: `PASS_TIME_COLLAB_GLOBAL_AUDIT_0_EXACT_FINITE_PRE_NOISE_CORPUS`
- Post-repair audit: **91/91 PASS**
- Certificate: **CERT-013**

The v1.0 audit harness also contained one non-scientific string-membership assertion bug for the TC5 scalar-clock nonclaim. v1.1 corrects only that predicate; no scientific artifact, gate, threshold, result or repair was changed.

## Six substantive failures found before the global freeze

1. **TC3P paired-history topology.** The untagged union of two alternative realized-history DAGs need not itself be a DAG. Repair: retain two tagged history DAGs and define support/path depth over the pair.

2. **TC3P multi-source attenuation.** The original geometric tail omitted the multiplicity `M_U` of the initial intervention front. Repair:
   `P(depth>=n) <= min(1, M_U (Bq)^n/(1-Bq))` when `Bq<1`, with the finite-DAG truncated sum as the primary bound.

3. **Untyped collaboration number.** TC1 kappa is participant-level whereas TC4 used domain blocks. Repair: write `kappa_Omega^U(Q)` with an explicit coalition universe.

4. **TC4/TC5 chart-domain collision.** TC4 active domains are maximal connected components of `A_H`; therefore a live `A_H` edge cannot connect two distinct maximal components without merging them. Repair: TC5 vertices are temporal charts/patches, possibly overlapping inside one maximal active component.

5. **CERT-012 H9 evidence class.** The frozen v0.2 evaluator never increments `isolation_failures`. H9 is therefore a constructive/regression invariant, not an independent stochastic falsifier. CERT-012 remains qualified, but the 3688 checks are coverage, not 3688 independent attempts to falsify isolation.

6. **TC4H episode resurrection.** The frozen evaluator can later complete an old split episode after a noncollaborative reconnection. A stricter non-resurrection shadow oracle changes **37/320** lifecycle labels, but still passes every frozen primary threshold and H10:
   - BALANCED: 39/56 (official 44)
   - HIGH_CHURN: 36/56 (official 42)
   - SHORTCUT: 29/56 (official 40)
   - TRANSFER_LOSS: 26/56 (official 35)
   - RICH_LOCAL_STATE: 38/56 (official 44)

Thus CERT-012's qualitative lifecycle qualification survives the stricter semantics, while future campaigns inherit the non-resurrection rule.

## Independent global stress checks

- TC3 essential-variable theorem: **65,812 Boolean functions** through n=4, **0 mismatches**.
- TC4 active-graph updates: **10,650 exact edge-update checks** through n=5, **0 anomalies**.
- Canonical package chain: ZIP CRCs, SHA-256 sidecars and outer manifests reproduce.
- Cross-phase semantics preserve:
  - reconstructibility != causal influence;
  - incomparability != operational independence;
  - active connectivity != historical precedence;
  - historical ORD persistence != future post-split influence;
  - CAL holonomy != ORD cycle;
  - affine holonomy != spatial/gravitational curvature;
  - scalarizability = optional reduction, not primitive ontology.

## Certificate

`CERT-013 — TIME-COLLAB Exact Finite Pre-Noise Global Coherence Qualification`

Status:

`CLOSED_QUALIFIED_EXACT_FINITE_PRE_NOISE_CORPUS_WITH_NONRETROACTIVE_ADDENDA`

This is the global freeze immediately before the approximate/noisy atlas frontier. It does not authorize continuum, manifold, spacetime, Lorentzian, relativistic or gravitational claims.
