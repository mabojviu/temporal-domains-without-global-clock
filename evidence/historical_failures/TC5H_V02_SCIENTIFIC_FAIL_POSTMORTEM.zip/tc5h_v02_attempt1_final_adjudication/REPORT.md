# TC5H v0.2 — Scientific Attempt 1 final adjudication

## Official result

`FAIL_TC5H_NOISY_DYNAMIC_ATLAS_ROBUSTNESS_HOLDOUT`

No certificate is issued.

Authorization `LQTAD-TIME-COLLAB-5H-V02-SCIENTIFIC-ATTEMPT1-34CCB61B91D90374` is **CONSUMED** and must never be reused.

## Why it failed

Only two frozen gates failed:

- **H1_EXACT_CONTROL**: 23/24 rather than 24/24. The failed case `TC5H-95eac56ef5b20b5c56bf31e4` generated a pure tree and therefore had **0 eligible cyclic snapshots**. This is a control well-posedness failure.
- **H2_GAPPED_CONTROL**: 23/24 rather than 24/24. In `TC5H-d29f323e1c5ceb020828bf4f`, the injected gap edge `(1,2)` was removed by turnover at step 6. The detector correctly saw obstruction for the first 6 snapshots, then the negative witness no longer existed. Obstruction fraction was **6/18 = 33.3%**, below the frozen 80% control gate.

These facts do **not** rescue v0.2. The frozen rule required H0-H13 all PASS.

## Scientific families

The four scientific-family gates all passed:

- CALIBRATION_NOISE: **39/64**, gate >=20, margin +19.
- EDGE_TURNOVER: **43/64**, gate >=28, margin +15.
- CHURN_PLUS_NOISE: **7/64**, gate >=4, margin +3.
- BOTTLENECK_CYCLE_LOSS: **44/64**, gate >=30, margin +14.
- EDGE_TURNOVER minus CHURN_PLUS_NOISE: **56.25 percentage points**, gate >=20 pp.

Near-gap ambiguity: **30/32** boundary cases and **0/32** gap-control classifications.
Maximum envelope: **0.13843 < 0.20**.
GA0-R06 non-resurrection regression: **400/400 PASS**.

This is postmortem information only; it is not a v0.2 qualification.

## Independent replay

Frozen evaluator/adjudicator replay reproduced the exact gates, summary and FAIL verdict.
399/400 records were exactly equal. One record differed only by a floating-point last-bit
value in `max_envelope` (~5e-19), with identical classifications and no gate impact.

## Prospective repair

A fresh v0.3 may repair only the ill-posed controls:

1. exact control: deterministically cyclic/static;
2. gapped control: persistent static gap, or gap reinjected on every fresh control episode.

The clean minimal design is to set turnover=0 for H1/H2 because they are **detector controls**,
while turnover physics remains tested in the scientific families.

v0.3 must have fresh signature, particular audit, global audit, nonce, CASE_SET and one-shot authorization.
