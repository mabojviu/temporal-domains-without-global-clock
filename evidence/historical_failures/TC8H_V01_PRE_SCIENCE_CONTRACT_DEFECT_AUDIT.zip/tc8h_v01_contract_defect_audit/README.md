# TC8H v0.1 pre-science contract defect

The external preflight is technically valid, but science is blocked. H12's prose requires matched link counts across ORD_SINGLE, CAL_TREE and CORR_ONLY, while the frozen generator/adjudicator do not implement that contract.

Status: `ABANDONED_PRE_SCIENCE_AFTER_PREFLIGHT_GATE_CONTRACT_MISMATCH`

No scientific case was executed. v0.1 is not a scientific FAIL; it is abandoned before science.
