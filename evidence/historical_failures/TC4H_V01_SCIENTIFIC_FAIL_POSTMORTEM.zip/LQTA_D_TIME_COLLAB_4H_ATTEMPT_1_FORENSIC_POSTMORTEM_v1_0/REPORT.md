# TIME-COLLAB-4H Attempt 1 — Forensic postmortem

Official verdict remains **FAIL**.

## Frozen failures

H3 BALANCED, H5 SHORTCUT, H6 TRANSFER_LOSS, H7 RICH_LOCAL_STATE and H9 POST-SPLIT ISOLATION failed.

## Measurement-contract finding

The frozen prose says H9 is over **qualifying split probes**, but the frozen evaluator increments the denominator for **every** random `probe_split` event.

Official H9:
- 1527/3184 = 47.96%

Diagnostic eligible probes (post collaborative split and crossing the stored split partitions):
- 368/697 = 52.80%

This is a real contract mismatch, but **does not rescue Attempt 1**.

## Structural lifecycle diagnostic without mandatory random probe event

{
  "BALANCED_TURNOVER": {
    "cases": 56,
    "cases_with_collab_merge": 54,
    "cases_with_collab_split": 54,
    "cases_with_structural_remerge": 45,
    "eligible_isolation_passes": 94,
    "eligible_isolation_rate": 0.5562130177514792,
    "eligible_split_probes": 169,
    "structural_full_no_probe": 45
  },
  "HIGH_CHURN": {
    "cases": 56,
    "cases_with_collab_merge": 56,
    "cases_with_collab_split": 56,
    "cases_with_structural_remerge": 43,
    "eligible_isolation_passes": 112,
    "eligible_isolation_rate": 0.6436781609195402,
    "eligible_split_probes": 174,
    "structural_full_no_probe": 43
  },
  "RICH_LOCAL_STATE": {
    "cases": 56,
    "cases_with_collab_merge": 55,
    "cases_with_collab_split": 54,
    "cases_with_structural_remerge": 40,
    "eligible_isolation_passes": 46,
    "eligible_isolation_rate": 0.5111111111111111,
    "eligible_split_probes": 90,
    "structural_full_no_probe": 40
  },
  "SHORTCUT_TURNOVER": {
    "cases": 56,
    "cases_with_collab_merge": 55,
    "cases_with_collab_split": 55,
    "cases_with_structural_remerge": 39,
    "eligible_isolation_passes": 59,
    "eligible_isolation_rate": 0.427536231884058,
    "eligible_split_probes": 138,
    "structural_full_no_probe": 39
  },
  "TRANSFER_LOSS": {
    "cases": 56,
    "cases_with_collab_merge": 54,
    "cases_with_collab_split": 54,
    "cases_with_structural_remerge": 30,
    "eligible_isolation_passes": 57,
    "eligible_isolation_rate": 0.4523809523809524,
    "eligible_split_probes": 126,
    "structural_full_no_probe": 30
  }
}

This diagnostic is nonconfirmatory. It may be used only to design a new campaign with the measurement contract repaired before a fresh nonce/holdout.
