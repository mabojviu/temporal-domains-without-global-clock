# TIME-COLLAB-3H Scientific Attempt 1 — Transport Repair v0.1.2

Authorization remains unchanged:

`LQTAD-TIME-COLLAB-3H-SCIENTIFIC-ATTEMPT1-8AFAB90FEDC58BCD` — `ISSUED_UNCLAIMED`

This package changes transport only. It uses a deliberately short root name (`TC3H_A1_R2`) and performs a PowerShell presence check for every required file **before** any Python preclaim/scientific action.

Frozen scientific files, `CASE_SET.json`, authorization, thresholds, target, families and scientific runner are unchanged.

## Extraction

Create a short clean directory, for example:

```powershell
mkdir C:\LQTA\TC3H_A1_R2
```

Extract the **contents** of this ZIP directly into that directory. After extraction, this must exist:

```text
C:\LQTA\TC3H_A1_R2\scripts\verify_scientific_attempt_binding.py
```

Then:

```powershell
cd C:\LQTA\TC3H_A1_R2
powershell -ExecutionPolicy Bypass -File .\run_scientific_attempt_1.ps1
```

Do not execute from either previous v0.1.0 or v0.1.1 directory.

Once `DURABLE_LEDGER\AUTHORIZATION_CLAIM.json` appears, the authorization is consumed.
