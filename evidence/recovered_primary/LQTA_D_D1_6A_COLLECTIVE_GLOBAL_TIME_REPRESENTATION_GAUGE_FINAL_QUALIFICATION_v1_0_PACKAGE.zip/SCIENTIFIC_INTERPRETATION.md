# Scientific interpretation

D1.6A supports the conditional direction

\[
\Theta(C)\ 	ext{given}
\quad\Longrightarrow\quad
	ext{global scalar time and total serialization are operationally gauge}.
\]

It does not yet support the stronger reconstruction direction

\[
\{	ext{autonomous local clocks and causal access}\}
\quad\Longrightarrow\quad
\Theta(C).
\]

The first direction is now qualified on the frozen finite domain. The second direction is
the central target of D1.6B.
