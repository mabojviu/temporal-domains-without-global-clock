# Claim boundaries

## Qualified

- Global scalar-coordinate gauge after collective precedence data are supplied.
- Serialization gauge for declared concurrent abstract events.
- Conflict-local-minimum equivalence on the frozen finite domain.
- Dynamic feedback without causal cycles in the tested chains.
- Exact detection of declared coordination obstructions.
- Deterministic byte-identical regeneration of the accepted results.

## Not qualified

- Reconstruction of conflict and precedence from autonomous MCWF local clocks.
- Fully distributed generation of the collective temporal structure.
- Universal coordinator eliminability.
- Operator-blind holdout performance.
- Relativistic locality, Lorentz covariance or microcausality.
- Continuum or macroscopic emergence of a smooth global time.
- The claim that global time is fundamentally nonexistent.
