# Numbering and non-retroactivity

This is a phase-final D1.6A qualification package. It does not alter CERT-009, the submitted
article, D1.5 artifacts, or any frozen upstream certification. No new master CERT number is
assigned by this package.
