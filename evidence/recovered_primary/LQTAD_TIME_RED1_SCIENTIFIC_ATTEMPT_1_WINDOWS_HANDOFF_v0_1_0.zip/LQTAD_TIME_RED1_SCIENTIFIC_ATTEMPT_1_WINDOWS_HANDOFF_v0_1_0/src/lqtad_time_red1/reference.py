from __future__ import annotations
import sys
from pathlib import Path
V=Path(__file__).resolve().parents[2]/'vendor'
if str(V) not in sys.path: sys.path.insert(0,str(V))
from lqtad_time_red1_adapter0 import simple_root,reference_2c_from_root,reference_b3_from_root,reference_b3_from_2b_envelope,ad_2a_2b
from lqtad_time_red1_adapter0.canonical import digest
from lqtad_d16b3.model import tv

REFERENCE_FAMILIES={f'TR1-MP-{p}-{i:02d}' for p in ('AC','BD','AD') for i in range(1,5)}
def evaluate(case:dict,result:dict)->dict:
    f=case['family_id']
    if f not in REFERENCE_FAMILIES: return {'required':False,'agreement':True,'scope':'NONE'}
    p=case['parameters']; root=simple_root(seed=int(p['seed']),trajectory=int(p['trajectory']),domains=2); a=result['actual']
    if '-AC-' in f:
        ref=reference_2c_from_root(root)
        if f.endswith('-01'): agree=a['right']==ref
        elif f.endswith('-02'): agree=a['defect']==0
        elif f.endswith('-03'): agree=a['resource_right']==ref['resource_digest']
        else: agree=a['source_right']==ref['source_digest']
    elif '-BD-' in f:
        aa=ad_2a_2b(root); ref=reference_b3_from_2b_envelope(aa,int(p['weight_num']),int(p['weight_den']),'A')
        if f.endswith('-01'): agree=a['right']==ref
        elif f.endswith('-02'): agree=tv(a['left']['exact_law'],ref['exact_law'])==0
        elif f.endswith('-03'): agree=a['resource_right']==digest(aa['resource_ledger'])
        else: agree=a['source_right']==aa['source_extended_digest']
    else:
        ref=reference_b3_from_root(root,int(p['weight_num']),int(p['weight_den']),'A')
        if f.endswith('-01'): agree=a['right']==ref
        elif f.endswith('-02'): agree=tv(a['left']['exact_law'],ref['exact_law'])==0
        elif f.endswith('-03'): agree=len(a['resource_right'])==64
        else: agree=len(a['source_right'])==64
    return {'required':True,'agreement':bool(agree),'scope':f.split('-')[2],'reference_digest':digest(ref) if 'ref' in locals() else None}
