from __future__ import annotations

def _same(x,y): return x==y

def evaluate(case:dict,result:dict,reference:dict|None=None)->dict:
    f=case['family_id']; x=result['actual']; verdict=False
    if f in ('TR1-RT-01','TR1-RT-02'): verdict=_same((x['left'],x['trace_left']),(x['right'],x['trace_right']))
    elif f=='TR1-RT-03': verdict=_same(x['left'],x['right'])
    elif f=='TR1-RT-04': verdict=_same(x['remote_before'],x['remote_after']) and bool(x['local_changed'])
    elif f=='TR1-RT-05': verdict=len({x['shared_left'],x['shared_right']})==1 and x['other_channel'] not in {x['shared_left']}
    elif f=='TR1-RT-06': verdict=(len(set(x['resource_ids']))==2==len(x['resource_ids']) and sum(x['counters'])==0 and min(x['residuals'])>0)
    elif f=='TR1-RT-07': verdict=_same(x['left'],x['right'])
    elif f=='TR1-RT-08': verdict=bool(x['commute']) and _same(x['left'],x['right'])
    elif f=='TR1-RT-09': verdict=all([x['txA_valid'],x['txB_valid']]) and set(x['left'])==set(x['right']) and set(x['resource_final'])=={'rA','rB'}
    elif f=='TR1-RT-10': verdict=_same(x['normalized_once'],x['normalized_twice'])
    elif f=='TR1-RT-11': verdict=_same(x['normalized'],x['renormalized']) and tuple(i['op'] for i in x['normalized'])==('MERGE','SPLIT')
    elif f=='TR1-RT-12': verdict=_same(x['tree1'],x['tree2']) and not bool(x['holonomy'])
    elif f=='TR1-IF-01': verdict=x['valid'] and not x['introduced'] and x['schema'].endswith('2B-VIEW-1')
    elif f=='TR1-IF-02': verdict=len({x['root_before'],x['root_after']})==1 and len({x['resource_A'],x['resource_B']})==1
    elif f=='TR1-IF-03': verdict=bool(x['pure_embedding']) and tuple(x['record'])==('e0','e1') and x['augmented_exact'] is True
    elif f=='TR1-IF-04': verdict=tuple(x['trace'][1:3])==('AD-2A-2B','AD-2B-2C') and len(x['source_digest'])==64 and len(x['resource_digest'])==64
    elif f=='TR1-IF-05': verdict=(not x['law_error']) and (not x['coordinate_uncertainty']['value']) and (not x['error_provenance']['adapter'])
    elif f=='TR1-IF-06': verdict=bool(x['stable']) and x['margin']>x['coordinate']['value']
    elif f=='TR1-IF-07': verdict=set(x['record']).issubset(set(x['kernel_support']))
    elif f=='TR1-IF-08': verdict=x['A']==x['B']==x['C']==x['D']
    elif f.startswith('TR1-MP-'):
        suffix=f.rsplit('-',1)[1]
        if suffix=='01': verdict=_same(x['left'],x['right'])
        elif suffix=='02': verdict=(not x['defect']) and x['unit']=='dimensionless'
        elif suffix=='03': verdict=_same(x['resource_left'],x['resource_right'])
        elif suffix=='04': verdict=_same(x['source_left'],x['source_right'])
    elif f=='TR1-LH-01': verdict=all([x['cert_b'],x['cert_c']]) and _same(x['before'],x['after']) and not _same(x['before'],x['merged'])
    elif f=='TR1-LH-02': verdict=set(x['grown'])=={'A','B'} and x['contracted']==['A'] and x['certificate']
    elif f=='TR1-LH-03': verdict=x['before_digest']!=x['working_digest'] and x['rollback_bytes_equal'] is True
    elif f=='TR1-LH-04': verdict=x['telescopic']-x['actual']>=0 and x['geometric']>=0
    elif f=='TR1-LH-05': verdict=(not x['holonomy']) and len({repr(v) for v in x['levels']})==1
    elif f=='TR1-LH-06': verdict=len(x['keys'])==len(set(x['keys']))==len(x['values']) and x['owner']=='A'
    elif f=='TR1-LH-07': verdict=x['rollback_equal'] and x['committed_record']==['e0'] and x['before_digest']!=x['pending_digest']
    elif f=='TR1-LH-08': verdict=_same(x['before_digest'],x['after_digest']) and bool(x['restored_valid'])
    else: raise ValueError(f)
    if reference and reference.get('required'): verdict=verdict and bool(reference.get('agreement'))
    return {'evaluator':'E2','case_id':case['case_id'],'condition':bool(verdict),'metrics':{}}
