from __future__ import annotations
import sys
from pathlib import Path
V=Path(__file__).resolve().parents[2]/'vendor'
if str(V) not in sys.path: sys.path.insert(0,str(V))
from lqtad_time_red1_adapter0.canonical import canonicalize,canonical_bytes,digest,loads_canonical
