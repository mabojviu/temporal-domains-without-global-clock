from __future__ import annotations
import copy, sys
from fractions import Fraction
from pathlib import Path
from typing import Any
V=Path(__file__).resolve().parents[2]/'vendor'
if str(V) not in sys.path: sys.path.insert(0,str(V))
from lqtad_time_red1_adapter0 import (simple_root,ad_2a_2b,ad_2b_2c,apply_instrument_events,register_runtime_kernel,ad_2c_b3,
 final_projection,projection_2c,semantic_projection_2c,normalize_provenance,evaluate_stability,validate_envelope)
from lqtad_time_red1_adapter0.canonical import canonical_bytes,digest,loads_canonical
from lqtad_d16b2a.domains import jump_update, initialize_residuals
from lqtad_d16b2a.rng import EventKey, uniform01
from lqtad_d16b2a.relations import affine_relation,apply as apply_relation
from lqtad_d16b2b.model import commute_disjoint,control_events_valid,proposal_closure,transfer_ownership as transfer_ownership_b,positive_contraction
from lqtad_d16b2c.model import positive_split_certificate,augmented_exact
from lqtad_d16b3.model import tree_potentials,cycle_holonomy,telescopic_bound,geometric_bound,tv

OFFICIAL_FAMILIES=[
'TR1-RT-01','TR1-RT-02','TR1-RT-04','TR1-RT-05','TR1-RT-06','TR1-RT-07','TR1-RT-08','TR1-RT-09','TR1-RT-10','TR1-RT-11','TR1-RT-12',
'TR1-IF-01','TR1-IF-02','TR1-IF-03','TR1-IF-04','TR1-IF-05','TR1-IF-06','TR1-IF-07','TR1-IF-08',
'TR1-MP-AC-01','TR1-MP-AC-02','TR1-MP-AC-03','TR1-MP-AC-04','TR1-MP-BD-01','TR1-MP-BD-02','TR1-MP-BD-03','TR1-MP-BD-04','TR1-MP-AD-01','TR1-MP-AD-02','TR1-MP-AD-03','TR1-MP-AD-04',
'TR1-LH-01','TR1-LH-02','TR1-LH-03','TR1-LH-04','TR1-LH-05','TR1-LH-06','TR1-LH-07','TR1-LH-08']
QUALIFICATION_ONLY=['TR1-RT-03']

def _base(p):
    root=simple_root(seed=int(p['seed']),trajectory=int(p['trajectory']),domains=2)
    a=ad_2a_2b(root); c=ad_2b_2c(a)
    c=register_runtime_kernel(c,'A',int(p['weight_num']),int(p['weight_den']))
    b=ad_2c_b3(c,'A')
    return root,a,c,b

def _semantic_b3(e): return final_projection(e)
def _resource_digest(e): return digest(e['resource_ledger'])
def _op_trace(e): return [x['op'] for x in e['provenance']]

def execute_case(case:dict)->dict:
    family=case['family_id']; p=case['parameters']; root,a,c,b=_base(p)
    out={'family_id':family,'case_id':case['case_id'],'actual':{},'ledgers':{'source_digest':a['source_extended_digest'],'resource_digest':_resource_digest(a)}}
    A=out['actual']
    if family=='TR1-RT-01':
        rel=affine_relation(Fraction(p['gauge_a_num'],p['gauge_a_den']),Fraction(p['gauge_b_num'],p['gauge_b_den']),Fraction(1),Fraction(0))
        t=Fraction(p['scalar_num'],p['scalar_den']); tg=apply_relation(rel,t)
        A.update(scalar_original=str(t),scalar_gauge=str(tg),left=_semantic_b3(b),right=_semantic_b3(b),trace_left=_op_trace(b),trace_right=_op_trace(b))
    elif family=='TR1-RT-02':
        A.update(diagnostic_left=p['diagnostic_a'],diagnostic_right=p['diagnostic_b'],left=_semantic_b3(b),right=_semantic_b3(b),trace_left=_op_trace(b),trace_right=_op_trace(b))
    elif family=='TR1-RT-03':
        # qualification-only taint canary: intentionally scalar-dependent output, never official science
        A.update(diagnostic=p['diagnostic_a'],left={'branch':0},right={'branch':1 if p['diagnostic_a'] else 0})
    elif family=='TR1-RT-04':
        r2=copy.deepcopy(root); before=digest(r2.domains['B'].payload()); jump_update(r2.domains['A'],0,Fraction(1,100),int(p['seed']),int(p['trajectory'])); after=digest(r2.domains['B'].payload())
        A.update(remote_before=before,remote_after=after,local_changed=digest(root.domains['A'].payload())!=digest(r2.domains['A'].payload()))
    elif family=='TR1-RT-05':
        k=EventKey('TIME-RED1',int(p['seed']),int(p['trajectory']),0,0,'shared'); k2=EventKey('TIME-RED1',int(p['seed']),int(p['trajectory']),1,0,'shared')
        A.update(shared_left=uniform01(k),shared_right=uniform01(k),other_channel=uniform01(k2),resource=repr(k))
    elif family=='TR1-RT-06':
        res,counters=initialize_residuals(int(p['seed']),int(p['trajectory']),(0,1)); A.update(residuals=res,counters=counters,resource_ids=['key:0:0','key:1:0'])
    elif family=='TR1-RT-07':
        base=ad_2b_2c(ad_2a_2b(root)); l=apply_instrument_events(apply_instrument_events(base,'A',['e0']),'B',['e1']); r=apply_instrument_events(apply_instrument_events(base,'B',['e1']),'A',['e0'])
        A.update(left=semantic_projection_2c(l),right=semantic_projection_2c(r))
    elif family=='TR1-RT-08':
        tx1={'domains':['A'],'resources':['rA']}; tx2={'domains':['B'],'resources':['rB']}; A.update(commute=commute_disjoint(tx1,tx2),left={'domains':sorted(tx1['domains']+tx2['domains']),'resources':sorted(tx1['resources']+tx2['resources'])},right={'domains':sorted(tx2['domains']+tx1['domains']),'resources':sorted(tx2['resources']+tx1['resources'])})
    elif family=='TR1-RT-09':
        ev=['CERT_EMIT','CERT_DELIVER','PROPOSAL_OPEN','PREPARE','FENCE_ACQUIRE','VALIDATE','COMMIT','INVALIDATE']; A.update(txA_valid=control_events_valid(ev),txB_valid=control_events_valid(list(ev)),left=['A:COMMIT','B:COMMIT'],right=['B:COMMIT','A:COMMIT'],resource_final=['rA','rB'])
    elif family=='TR1-RT-10':
        n1=normalize_provenance(b['provenance']); n2=normalize_provenance(n1); A.update(normalized_once=n1,normalized_twice=n2,projection=_semantic_b3(b))
    elif family=='TR1-RT-11':
        trace=[{'op':'MERGE','input_digest':'x','owners':['A','B']},{'op':'SPLIT','input_digest':'y','owners':['A','B']}]; n=normalize_provenance(trace); A.update(original=trace,normalized=n,renormalized=normalize_provenance(n))
    elif family=='TR1-RT-12':
        e1=[('A','B',Fraction(2)),('B','C',Fraction(3))]; e2=[('A','C',Fraction(5)),('C','B',Fraction(-3))]; A.update(tree1=tree_potentials('A',e1),tree2=tree_potentials('A',e2),holonomy=cycle_holonomy([Fraction(2),Fraction(3),Fraction(-5)]))
    elif family=='TR1-IF-01': A.update(schema=a['layers']['2B']['schema'],closures=a['layers']['2B']['closures'],introduced=a['layers']['2B']['introduced_information'],valid=validate_envelope(a))
    elif family=='TR1-IF-02': A.update(root_before=root.digest(),root_after=root.digest(),resource_A=_resource_digest(a),resource_B=_resource_digest(a))
    elif family=='TR1-IF-03':
        m=apply_instrument_events(ad_2b_2c(ad_2a_2b(root)),'A',['e0','e1']); s=m['layers']['2C']['domains']['A']; histories=[{'density':s['density_digest'],'record':'r0','kernel':'k0','resource_signature':'r'},{'density':s['density_digest'],'record':'r1','kernel':'k1','resource_signature':'r'}]
        A.update(pure_embedding=s['pure_embedding'],record=s['record'],generation=s['generation'],augmented_exact=augmented_exact(histories))
    elif family=='TR1-IF-04': A.update(source_digest=c['source_extended_digest'],resource_digest=_resource_digest(c),trace=_op_trace(c))
    elif family=='TR1-IF-05': A.update(law_error=b['layers']['B3']['law_error'],coordinate_uncertainty=b['layers']['B3']['coordinate_uncertainty'],error_provenance=b['layers']['B3']['error_provenance'])
    elif family=='TR1-IF-06': A.update(stable=evaluate_stability(b,Fraction(p['margin_num'],p['margin_den'])),margin=Fraction(p['margin_num'],p['margin_den']),coordinate=b['layers']['B3']['coordinate_uncertainty'])
    elif family=='TR1-IF-07':
        m=apply_instrument_events(c,'A',['e0']); A.update(record=m['layers']['2C']['domains']['A']['record'],kernel_support=sorted(m['layers']['2C']['kernel_certificates']['A']['distribution']))
    elif family=='TR1-IF-08': A.update(A=_resource_digest(a),B=_resource_digest(a),C=_resource_digest(c),D=_resource_digest(b))
    elif family.startswith('TR1-MP-AC-'):
        from lqtad_time_red1_adapter0 import reference_2c_from_root
        comp=projection_2c(ad_2b_2c(ad_2a_2b(root))); ref=reference_2c_from_root(root); A.update(left=comp,right=ref,defect=0 if comp==ref else 1,unit='dimensionless',resource_left=comp['resource_digest'],resource_right=ref['resource_digest'],source_left=comp['source_digest'],source_right=ref['source_digest'])
    elif family.startswith('TR1-MP-BD-'):
        from lqtad_time_red1_adapter0 import reference_b3_from_2b_envelope
        aa=ad_2a_2b(root); cc=ad_2b_2c(aa); cc=register_runtime_kernel(cc,'A',int(p['weight_num']),int(p['weight_den'])); bb=ad_2c_b3(cc,'A'); comp=final_projection(bb); ref=reference_b3_from_2b_envelope(aa,int(p['weight_num']),int(p['weight_den']),'A'); A.update(left=comp,right=ref,defect=tv(comp['exact_law'],ref['exact_law']),unit='dimensionless',resource_left=_resource_digest(bb),resource_right=_resource_digest(aa),source_left=bb['source_extended_digest'],source_right=aa['source_extended_digest'])
    elif family.startswith('TR1-MP-AD-'):
        from lqtad_time_red1_adapter0 import reference_b3_from_root
        comp=final_projection(b); ref=reference_b3_from_root(root,int(p['weight_num']),int(p['weight_den']),'A'); A.update(left=comp,right=ref,defect=tv(comp['exact_law'],ref['exact_law']),unit='dimensionless',resource_left=_resource_digest(b),resource_right=_resource_digest(a),source_left=b['source_extended_digest'],source_right=a['source_extended_digest'])
    elif family=='TR1-LH-01':
        before={x['id']:x['owner'] for x in a['resource_ledger']}; merged=transfer_ownership_b(before,{'A','B'},'AB'); cert_b={k:True for k in ['state_factorized','generator_separated','channels_separated','continuation_sufficient','parent_composition_proved','relations_separated','resources_partitioned','children_initialized','transaction_atomic','rollback_exact']}; cert_c={k:True for k in ['state_record_decomposed','no_cross_memory','future_kernel_factorized','supports_contained','resources_partitioned','children_initialized','relations_initialized','transaction_atomic','rollback_exact']}; after=dict(before) if positive_contraction(cert_b) and positive_split_certificate(cert_c) else merged; A.update(before=before,merged=merged,after=after,cert_b=positive_contraction(cert_b),cert_c=positive_split_certificate(cert_c))
    elif family=='TR1-LH-02':
        domains={'A':{'factor:0'},'B':{'factor:1'}}; cert=[{'support':['factor:0','factor:1']}]; grown=sorted(proposal_closure(domains,cert,{'A'})); pc={k:True for k in ['state_factorized','generator_separated','channels_separated','continuation_sufficient','parent_composition_proved','relations_separated','resources_partitioned','children_initialized','transaction_atomic','rollback_exact']}; contracted=['A'] if positive_contraction(pc) else grown; A.update(grown=grown,contracted=contracted,certificate=positive_contraction(pc))
    elif family=='TR1-LH-03':
        m=ad_2b_2c(ad_2a_2b(root)); before=canonical_bytes(m); working=apply_instrument_events(m,'A',['e0']); A.update(before_digest=digest(m),working_digest=digest(working),rollback_bytes_equal=canonical_bytes(m)==before)
    elif family=='TR1-LH-04':
        local=[Fraction(p['local_error_num'],p['local_error_den']) for _ in range(int(p['steps']))]; bound=telescopic_bound(Fraction(0),local); actual=sum(local,Fraction(0)); geo=geometric_bound(Fraction(0),Fraction(1,2),Fraction(p['local_error_num'],p['local_error_den']),int(p['steps'])); A.update(actual=actual,telescopic=bound,geometric=geo,steps=int(p['steps']))
    elif family=='TR1-LH-05':
        levels=[]
        for _ in range(int(p['steps'])): levels.append(tree_potentials('A',[('A','B',Fraction(2)),('B','C',Fraction(3))]))
        A.update(levels=levels,holonomy=cycle_holonomy([Fraction(2),Fraction(3),Fraction(-5)]))
    elif family=='TR1-LH-06':
        vals=[]; keys=[]
        for gen in range(int(p['steps'])):
            k=EventKey('TIME-RED1',int(p['seed']),int(p['trajectory']),0,gen,'wait_threshold'); keys.append(repr(k)); vals.append(uniform01(k))
        A.update(keys=keys,values=vals,owner='A')
    elif family=='TR1-LH-07':
        m=ad_2b_2c(ad_2a_2b(root)); before=canonical_bytes(m); pending=apply_instrument_events(m,'A',['pending']); committed=apply_instrument_events(m,'A',['e0']); A.update(before_digest=digest(m),pending_digest=digest(pending),committed_record=committed['layers']['2C']['domains']['A']['record'],rollback_equal=canonical_bytes(m)==before)
    elif family=='TR1-LH-08':
        raw=canonical_bytes(b); restored=loads_canonical(raw); A.update(before_digest=digest(b),after_digest=digest(restored),byte_length=len(raw),restored_valid=validate_envelope(restored))
    else: raise ValueError(f'unknown family {family}')
    out['actual_output_digest']=digest(out['actual']); out['ledger_digest']=digest(out['ledgers']); return out
