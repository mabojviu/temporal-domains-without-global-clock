from __future__ import annotations
import hashlib,json
from .runtime import OFFICIAL_FAMILIES

def _u64(s:str)->int: return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],'big')
def _params(material:str,family:str,variant:int)->dict:
    u=_u64(f'{material}|{family}|{variant}')
    weight_den=7+(u%5); weight_num=(u//7)%weight_den
    return {
      'seed': int(u%1000003)+1,'trajectory':int((u>>8)%97),'variant':int(variant),
      'weight_num':int(weight_num),'weight_den':int(weight_den),
      'gauge_a_num':int(2+(u%3)),'gauge_a_den':1,'gauge_b_num':int((u>>5)%5+1),'gauge_b_den':1,
      'scalar_num':int((u>>10)%13+1),'scalar_den':int((u>>15)%5+1),
      'diagnostic_a':int((u>>20)%1000),'diagnostic_b':int((u>>30)%1000+1001),
      'margin_num':int((u>>18)%9+2),'margin_den':1,
      'steps':int((u>>23)%5+2),'local_error_num':1,'local_error_den':int((u>>29)%50+100),
    }
def materialize(partition:str,material:str,freeze_root:str,variants_per_family:int=2)->dict:
    if partition not in {'TRAINING','HOLDOUT'}: raise ValueError(partition)
    cases=[]
    for fam in OFFICIAL_FAMILIES:
        for v in range(variants_per_family):
            params=_params(material,fam,v)
            payload={'schema':'LQTAD-TIME-RED1-CASE-3','partition':partition,'family_id':fam,'parameters':params,'freeze_root':freeze_root}
            cid=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            cases.append({'case_id':cid,**payload})
    return {'schema':'LQTAD-TIME-RED1-CASE-SET-3','partition':partition,'freeze_root':freeze_root,'case_count':len(cases),'cases':cases}
