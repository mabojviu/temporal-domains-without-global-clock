from __future__ import annotations
from .runtime import OFFICIAL_FAMILIES,QUALIFICATION_ONLY
FORBIDDEN={'actual_output','actual_output_digest','expected_verdict','expected_gate_result','evaluator_output','oracle_output','reference_answer','future_kernel','target_defect','target_bound','witness_class'}
def _scan(o,path='$'):
    errs=[]
    if isinstance(o,dict):
        for k,v in o.items():
            if k in FORBIDDEN: errs.append(f'forbidden:{path}.{k}')
            errs.extend(_scan(v,f'{path}.{k}'))
    elif isinstance(o,list):
        for i,v in enumerate(o): errs.extend(_scan(v,f'{path}[{i}]'))
    return errs
def validate_case(case:dict,allow_qualification=False)->list[str]:
    e=_scan(case)
    req={'case_id','schema','partition','family_id','parameters','freeze_root'}
    if set(case)!=req: e.append('top-level-fields')
    if case.get('schema')!='LQTAD-TIME-RED1-CASE-3': e.append('schema')
    fam=case.get('family_id'); allowed=set(OFFICIAL_FAMILIES)|(set(QUALIFICATION_ONLY) if allow_qualification else set())
    if fam not in allowed: e.append('family')
    if case.get('partition') not in {'TRAINING','HOLDOUT','QUALIFICATION'}: e.append('partition')
    p=case.get('parameters',{})
    required={'seed','trajectory','variant','weight_num','weight_den','gauge_a_num','gauge_a_den','gauge_b_num','gauge_b_den','scalar_num','scalar_den','diagnostic_a','diagnostic_b','margin_num','margin_den','steps','local_error_num','local_error_den'}
    if set(p)!=required: e.append('parameter-fields')
    try:
        if int(p['weight_den'])<=0 or not (0<=int(p['weight_num'])<=int(p['weight_den'])): e.append('weight')
        if int(p['gauge_a_num'])<=0 or int(p['gauge_a_den'])<=0: e.append('gauge')
        if int(p['scalar_den'])<=0 or int(p['margin_num'])<=0 or int(p['margin_den'])<=0: e.append('positive')
        if not (2<=int(p['steps'])<=8): e.append('steps')
        if int(p['local_error_num'])<0 or int(p['local_error_den'])<=0: e.append('local-error')
    except Exception: e.append('parameter-type')
    if not isinstance(case.get('freeze_root'),str) or len(case['freeze_root'])!=64: e.append('freeze-root')
    return e
def validate_case_set(obj:dict)->list[str]:
    e=[]; cases=obj.get('cases',[])
    if obj.get('case_count')!=len(cases): e.append('case-count')
    ids=[]
    for c in cases: e.extend([f"{c.get('case_id')}:{x}" for x in validate_case(c)]); ids.append(c.get('case_id'))
    if len(ids)!=len(set(ids)): e.append('duplicate-case-id')
    if cases and any(c['freeze_root']!=obj.get('freeze_root') for c in cases): e.append('freeze-mismatch')
    return e
