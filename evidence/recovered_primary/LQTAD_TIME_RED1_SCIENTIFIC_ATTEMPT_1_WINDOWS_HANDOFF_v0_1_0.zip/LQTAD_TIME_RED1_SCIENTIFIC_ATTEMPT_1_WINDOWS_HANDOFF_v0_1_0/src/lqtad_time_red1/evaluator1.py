from __future__ import annotations
from fractions import Fraction

def evaluate(case:dict, result:dict, reference:dict|None=None)->dict:
    f=case['family_id']; a=result['actual']; ok=False; metrics={}
    if f in {'TR1-RT-01','TR1-RT-02'}: ok=a['left']==a['right'] and a['trace_left']==a['trace_right']
    elif f=='TR1-RT-03': ok=a['left']==a['right']
    elif f=='TR1-RT-04': ok=a['remote_before']==a['remote_after'] and a['local_changed']
    elif f=='TR1-RT-05': ok=a['shared_left']==a['shared_right'] and a['other_channel']!=a['shared_left']
    elif f=='TR1-RT-06': ok=len(a['resource_ids'])==len(set(a['resource_ids'])) and a['counters']==[0,0] and all(x>0 for x in a['residuals'])
    elif f in {'TR1-RT-07','TR1-RT-08'}: ok=a['left']==a['right'] and (a.get('commute',True))
    elif f=='TR1-RT-09': ok=a['txA_valid'] and a['txB_valid'] and sorted(a['left'])==sorted(a['right']) and a['resource_final']==['rA','rB']
    elif f=='TR1-RT-10': ok=a['normalized_once']==a['normalized_twice']
    elif f=='TR1-RT-11': ok=a['normalized']==a['renormalized'] and [x['op'] for x in a['normalized']]==['MERGE','SPLIT'] and all('input_digest' not in x for x in a['normalized'])
    elif f=='TR1-RT-12': ok=a['tree1']==a['tree2'] and a['holonomy']==0
    elif f=='TR1-IF-01': ok=a['schema']=='LQTAD-TIME-RED1-2B-VIEW-1' and a['introduced']==[] and a['valid']
    elif f=='TR1-IF-02': ok=a['root_before']==a['root_after'] and a['resource_A']==a['resource_B']
    elif f=='TR1-IF-03': ok=a['pure_embedding'] and a['record']==['e0','e1'] and a['generation']>=2 and a['augmented_exact']
    elif f=='TR1-IF-04': ok=a['trace'][:3]==['SOURCE_2A','AD-2A-2B','AD-2B-2C'] and bool(a['source_digest']) and bool(a['resource_digest'])
    elif f=='TR1-IF-05': ok=a['law_error']==0 and a['coordinate_uncertainty']['value']==0 and a['error_provenance']['adapter']==0
    elif f=='TR1-IF-06': ok=a['stable'] and a['margin']>0 and a['coordinate']['value']==0
    elif f=='TR1-IF-07': ok=all(x in a['kernel_support'] for x in a['record'])
    elif f=='TR1-IF-08': ok=len({a['A'],a['B'],a['C'],a['D']})==1
    elif f.startswith('TR1-MP-'):
        if f.endswith('-01'): ok=a['left']==a['right']
        elif f.endswith('-02'): ok=a['defect']==0 and a['unit']=='dimensionless'
        elif f.endswith('-03'): ok=a['resource_left']==a['resource_right']
        elif f.endswith('-04'): ok=a['source_left']==a['source_right']
    elif f=='TR1-LH-01': ok=a['cert_b'] and a['cert_c'] and a['before']==a['after'] and a['merged']!=a['before']
    elif f=='TR1-LH-02': ok=a['grown']==['A','B'] and a['contracted']==['A'] and a['certificate']
    elif f=='TR1-LH-03': ok=a['before_digest']!=a['working_digest'] and a['rollback_bytes_equal']
    elif f=='TR1-LH-04': ok=a['actual']<=a['telescopic'] and a['telescopic']>=0 and a['geometric']>=0
    elif f=='TR1-LH-05': ok=a['holonomy']==0 and all(x==a['levels'][0] for x in a['levels'])
    elif f=='TR1-LH-06': ok=len(a['keys'])==len(set(a['keys'])) and len(a['values'])==len(a['keys']) and a['owner']=='A'
    elif f=='TR1-LH-07': ok=a['before_digest']!=a['pending_digest'] and a['committed_record']==['e0'] and a['rollback_equal']
    elif f=='TR1-LH-08': ok=a['before_digest']==a['after_digest'] and a['restored_valid'] and a['byte_length']>0
    else: raise ValueError(f)
    if reference is not None and reference.get('required'):
        ok = ok and reference.get('agreement',False)
    return {'evaluator':'E1','case_id':case['case_id'],'condition':bool(ok),'metrics':metrics}
