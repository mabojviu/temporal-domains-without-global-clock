from __future__ import annotations
from .runtime import execute_case
from .evaluator1 import evaluate as e1
from .evaluator2 import evaluate as e2
from .reference import evaluate as ref
from .validator import validate_case_set

def run(case_set:dict)->dict:
    errs=validate_case_set(case_set)
    if errs: raise ValueError('invalid case set:'+repr(errs[:5]))
    records=[]; disagreements=0; failures=0; reference_failures=0
    for case in case_set['cases']:
        result=execute_case(case); r=ref(case,result); a=e1(case,result,r); b=e2(case,result,r)
        agree=a['condition']==b['condition']; disagreements += int(not agree); reference_failures += int(r.get('required',False) and not r.get('agreement',False))
        condition=agree and a['condition'] and (not r.get('required',False) or r.get('agreement',False)); failures += int(not condition)
        records.append({'case_id':case['case_id'],'family_id':case['family_id'],'actual_output_digest':result['actual_output_digest'],'ledger_digest':result['ledger_digest'],'e1':a,'e2':b,'reference':r,'condition':condition})
    return {'schema':'LQTAD-TIME-RED1-CAMPAIGN-RUN-3','case_count':len(records),'failure_count':failures,'evaluator_disagreement_count':disagreements,'reference_failure_count':reference_failures,'records':records}
