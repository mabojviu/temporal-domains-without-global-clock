#!/usr/bin/env python3
import hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def main():
 f=json.load(open(ROOT/'FREEZE_LEDGER.json')); bad=[]
 for e in f['entries']:
  p=ROOT/e['path']
  if not p.exists() or sha(p)!=e['sha256'] or p.stat().st_size!=e['bytes']: bad.append(e['path'])
 canonical=json.dumps(f['entries'],sort_keys=True,separators=(',',':')).encode(); root=hashlib.sha256(canonical).hexdigest()
 if root!=f['freeze_root']: bad.append('freeze_root')
 print('PASS' if not bad else 'FAIL');
 if bad: print('\n'.join(bad[:20]))
 return 0 if not bad else 1
if __name__=='__main__': raise SystemExit(main())
