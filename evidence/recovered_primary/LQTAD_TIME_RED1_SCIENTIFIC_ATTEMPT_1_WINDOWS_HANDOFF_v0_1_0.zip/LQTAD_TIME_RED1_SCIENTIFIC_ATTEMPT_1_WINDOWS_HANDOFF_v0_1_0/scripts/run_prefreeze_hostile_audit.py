#!/usr/bin/env python3
from __future__ import annotations
import ast,copy,hashlib,json,pathlib,sys
from fractions import Fraction
import jsonschema
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'vendor')]
from lqtad_time_red1 import materialize,run,execute_case,OFFICIAL_FAMILIES
from lqtad_time_red1.validator import validate_case,validate_case_set,FORBIDDEN
from lqtad_time_red1.evaluator1 import evaluate as e1
from lqtad_time_red1.evaluator2 import evaluate as e2
from lqtad_time_red1.reference import evaluate as ref,REFERENCE_FAMILIES
from lqtad_time_red1.canonical import digest

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def gate(gid,group,name,fn,evidence):
    try: ok=bool(fn()); err=''
    except Exception as e: ok=False; err=f' | {type(e).__name__}:{e}'
    return {'gate_id':gid,'group':group,'name':name,'status':'PASS' if ok else 'FAIL','blocker':not ok,'evidence':evidence+err}
def imports(path):
    t=ast.parse(path.read_text()); out=[]
    for n in ast.walk(t):
        if isinstance(n,ast.Import): out += [x.name for x in n.names]
        elif isinstance(n,ast.ImportFrom): out.append(n.module or '')
    return out

FREEZE='0'*64
case_set=materialize('TRAINING','PREFREEZE-HOSTILE-AUDIT',FREEZE,2)
runout=run(case_set)
sample={c['family_id']:c for c in case_set['cases'] if c['parameters']['variant']==0}
raw={fam:execute_case(c) for fam,c in sample.items()}
A=[]
# A source/artifact binding
sb=json.load(open(ROOT/'configs/SOURCE_BINDINGS.json'))
A += [
 gate('A01','A','2A executor hash frozen',lambda: sb['2A_executor_sha256']=='32e32d4fbd59f15499dc04a174a017e4aa2b594573395f8ca23bcfea4d607834','2A executor'),
 gate('A02','A','2B executor hash frozen',lambda: sb['2B_executor_sha256']=='a044b25ec5eefe5fb48e24abf58f6730d777a0cad1113a90ec7ebccd6afa90e3','2B executor'),
 gate('A03','A','2C executor hash frozen',lambda: sb['2C_executor_sha256']=='d5b1cd6aafacd9f36a3326c15d191d5d4ba5036e4aa853d93859407d1fd84627','2C executor'),
 gate('A04','A','B3 original executor hash frozen',lambda: sb['B3_executor_original_sha256']=='d2ab3fbe6f1e95aebfc0b45a1f0a7bb0c1971bf8ed7c2be0103f0b6b3d4c97b4','B3 executor'),
 gate('A05','A','B3 transport hash frozen',lambda: sb['B3_runtime_transport_sha256']=='34bc641442c6b32315eeb687b048268d3c5b39f372e9e35f69b05754c3deee8f','B3 transport'),
 gate('A06','A','All source-file hashes self-verify',lambda: all(sha(ROOT/x['path'])==x['sha256'] for x in sb['source_files']),'SOURCE_BINDINGS'),
 gate('A07','A','Adapter hostile audit 64/64 PASS',lambda: json.load(open(ROOT/'evidence/ADAPTER0_HOSTILE_AUDIT.json'))['pass_count']==64,'adapter audit'),
 gate('A08','A','Pre-freeze training run is clean',lambda: runout['case_count']==78 and runout['failure_count']==0 and runout['evaluator_disagreement_count']==0 and runout['reference_failure_count']==0,'78 deterministic cases'),
]
# B adapters/registries
ad=json.load(open(ROOT/'configs/ADAPTER_REGISTRY.json')); rr=json.load(open(ROOT/'configs/ROUTE_REGISTRY.json'))
A += [
 gate('B01','B','Exactly three production adapters registered',lambda: len(ad['adapters'])==3,'ADAPTER_REGISTRY'),
 gate('B02','B','All adapters callable-bound before science',lambda: all(x['status']=='CALLABLE_BOUND' for x in ad['adapters']),'binding status'),
 gate('B03','B','AD-2A-2B has zero introduced error',lambda: ad['adapters'][0]['introduced_error']=='0','adapter error'),
 gate('B04','B','AD-2B-2C pure embedding has zero introduced error',lambda: '0' in ad['adapters'][1]['introduced_error'],'adapter error'),
 gate('B05','B','AD-2C-B3 separates law and coordinate error at zero',lambda: 'law_error=0' in ad['adapters'][2]['introduced_error'] and 'coordinate_uncertainty=0' in ad['adapters'][2]['introduced_error'],'adapter error'),
 gate('B06','B','Composed and independent reference routes registered',lambda: len(rr['routes'])==2 and {x['kind'] for x in rr['routes']}=={'production_composition','independent_reference'},'route registry'),
 gate('B07','B','Exact path pair has zero frozen bound',lambda: rr['path_pairs'][0]['bound']=='0','path pair'),
 gate('B08','B','Protected-field registry explicitly forbids upstream erasure',lambda: 'may not erase or alter' in json.load(open(ROOT/'configs/PROTECTED_FIELDS.json'))['rule'],'protected fields'),
]
# C firewalls
imgen=imports(ROOT/'src/lqtad_time_red1/casegen.py'); imrun=imports(ROOT/'src/lqtad_time_red1/runtime.py'); im1=imports(ROOT/'src/lqtad_time_red1/evaluator1.py'); im2=imports(ROOT/'src/lqtad_time_red1/evaluator2.py'); imr=imports(ROOT/'src/lqtad_time_red1/reference.py')
A += [
 gate('C01','C','Generator imports no evaluator',lambda: not any('evaluator' in x for x in imgen),'import graph'),
 gate('C02','C','Generator imports no reference',lambda: not any(x.endswith('reference') for x in imgen),'import graph'),
 gate('C03','C','Runtime imports no evaluator/reference',lambda: not any(('evaluator' in x or x.endswith('reference')) for x in imrun),'import graph'),
 gate('C04','C','E1 imports neither runtime nor E2',lambda: not any(x.endswith(('runtime','evaluator2')) for x in im1),'E1 graph'),
 gate('C05','C','E2 imports neither runtime nor E1',lambda: not any(x.endswith(('runtime','evaluator1')) for x in im2),'E2 graph'),
 gate('C06','C','Reference imports no evaluator/runtime',lambda: not any(('evaluator' in x or x.endswith('runtime')) for x in imr),'R graph'),
 gate('C07','C','Mutation suite detected 16/16 in both evaluators',lambda: json.load(open(ROOT/'evidence/MUTATION_SUITE.json'))['both_evaluators_detected']==16,'mutation suite'),
 gate('C08','C','Qualification scalar-taint canary excluded from official families',lambda: 'TR1-RT-03' not in OFFICIAL_FAMILIES and len(OFFICIAL_FAMILIES)==39,'family activation'),
]
# D validator/schemas
cschema=json.load(open(ROOT/'schemas/CASE_SCHEMA_v0_3_0.schema.json')); rschema=json.load(open(ROOT/'schemas/RESULT_SCHEMA_v0_3_0.schema.json')); wschema=json.load(open(ROOT/'schemas/WITNESS_SCHEMA_v0_3_0.schema.json'))
first=case_set['cases'][0]
A += [
 gate('D01','D','Independent case validator accepts all training cases',lambda: not validate_case_set(case_set),'validator'),
 gate('D02','D','JSON schema validates representative case',lambda: _schema_ok(cschema,first),'case JSON schema') if False else None,
]
def schema_ok(schema,obj):
    try: jsonschema.validate(obj,schema); return True
    except Exception: return False
A=[x for x in A if x is not None]
A += [
 gate('D02','D','JSON schema validates representative case',lambda: schema_ok(cschema,first),'case JSON schema'),
 gate('D03','D','Case schema forbids additional top-level fields',lambda: cschema.get('additionalProperties') is False,'case schema'),
 gate('D04','D','Case schema has no outcome fields',lambda: not (set(cschema.get('properties',{})) & FORBIDDEN),'anti-outcome'),
 gate('D05','D','Validator forbidden list covers future-kernel/reference answer',lambda: {'future_kernel','reference_answer','expected_verdict','actual_output_digest'}<=FORBIDDEN,'validator firewall'),
 gate('D06','D','Result schema requires gate_results and actual output digest',lambda: {'gate_results','actual_output_digest'}<=set(rschema['required']),'result schema'),
 gate('D07','D','Witness schema requires immutable result digest',lambda: 'immutable_result_digest' in wschema['required'],'witness schema'),
 gate('D08','D','All case IDs unique',lambda: len({c['case_id'] for c in case_set['cases']})==78,'case IDs'),
]
# E evaluator/reference exactness
A += [
 gate('E01','E','E1 passes all 39 families on both variants',lambda: all(r['e1']['condition'] for r in runout['records']),'E1'),
 gate('E02','E','E2 passes all 39 families on both variants',lambda: all(r['e2']['condition'] for r in runout['records']),'E2'),
 gate('E03','E','No E1/E2 disagreement',lambda: runout['evaluator_disagreement_count']==0,'agreement'),
 gate('E04','E','Reference scope exactly 12 multipath families',lambda: len(REFERENCE_FAMILIES)==12,'R scope'),
 gate('E05','E','All required references agree',lambda: runout['reference_failure_count']==0,'R agreement'),
 gate('E06','E','Reference is absent outside registered scope',lambda: all((r['family_id'] in REFERENCE_FAMILIES)==r['reference']['required'] for r in runout['records']),'scope enforcement'),
 gate('E07','E','Runtime results contain no scientific condition field',lambda: all('condition' not in raw[f] for f in raw),'runtime/evaluator separation'),
 gate('E08','E','Runtime results carry actual output digest and ledger digest',lambda: all(len(raw[f]['actual_output_digest'])==64 and len(raw[f]['ledger_digest'])==64 for f in raw),'output binding'),
]
# F claims/domain
claims=json.load(open(ROOT/'configs/CLAIMS_FROZEN_v0_3_0.json')); domain=json.load(open(ROOT/'configs/CASE_DOMAIN_v0_3_0.json'))
A += [
 gate('F01','F','Eight claims defined',lambda: len(claims['claims'])==8,'claim registry'),
 gate('F02','F','Claim IDs unique',lambda: len({x['claim_id'] for x in claims['claims']})==8,'claim ids'),
 gate('F03','F','Claim classes explicit',lambda: all(x['class'] in {'TRANSVERSE_STRUCTURAL','LOCALIZED_INTERFACE','LOCALIZED_OR_TRANSVERSE_BY_IMPACT_MAP'} for x in claims['claims']),'claim classes'),
 gate('F04','F','Domain fixes 39 official families',lambda: domain['official_family_count']==39 and len(OFFICIAL_FAMILIES)==39,'case domain'),
 gate('F05','F','Training/holdout cardinalities fixed before holdout nonce',lambda: domain['training_case_count']==78 and domain['holdout_case_count']==78 and domain['official_total_case_count']==156,'case counts'),
 gate('F06','F','Exact deterministic statistical protocol frozen',lambda: json.load(open(ROOT/'configs/STATISTICAL_PROTOCOL.json'))['statistical_family_count']==0,'no p-values'),
 gate('F07','F','Nonclaims explicitly frozen',lambda: len(claims['nonclaims'])>=6,'nonclaims'),
 gate('F08','F','CERT-010 remains unassigned',lambda: claims['CERT_010']=='NOT_ASSIGNED','certificate governance'),
]
# G metrics/bounds
mb=json.load(open(ROOT/'configs/METRIC_BOUND_REGISTRY.json'))
A += [
 gate('G01','G','TV law metric frozen dimensionless',lambda: any(x['metric_id']=='TV_LAW' and x['unit']=='dimensionless' for x in mb['metrics']),'metric registry'),
 gate('G02','G','Coordinate uncertainty has separate source-clock unit',lambda: any(x['metric_id']=='COORDINATE_UNCERTAINTY' and x['unit']=='source_clock_unit' for x in mb['metrics']),'unit separation'),
 gate('G03','G','Adapter exact TV bound frozen at zero',lambda: any(x['bound_id']=='ADAPTER_EXACT_BOUND' and x['value']=='0' for x in mb['bounds']),'adapter bound'),
 gate('G04','G','Multipath exact bound frozen at zero',lambda: any(x['bound_id']=='MULTIPATH_EXACT_BOUND' and x['value']=='0' for x in mb['bounds']),'multipath bound'),
 gate('G05','G','Telescopic finite-horizon bound callable-bound',lambda: any(x['bound_id']=='TELESCOPIC_FINITE_HORIZON' for x in mb['bounds']),'B3 bound'),
 gate('G06','G','Geometric finite-horizon bound callable-bound',lambda: any(x['bound_id']=='GEOMETRIC_FINITE_HORIZON' for x in mb['bounds']),'B3 bound'),
 gate('G07','G','Stable coordinate margin rule preserves units',lambda: 'same-unit margin' in next(x['rule'] for x in mb['bounds'] if x['bound_id']=='STABLE_COORDINATE_MARGIN'),'unit rule'),
 gate('G08','G','IF-05 observed adapter law defect zero in both variants',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-IF-05'),'observed training qualification'),
]
# H resources/transactions
A += [
 gate('H01','H','IF-02 resource transaction cases pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-IF-02'),'AB resources'),
 gate('H02','H','IF-08 bridge resource propagation cases pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-IF-08'),'bridge resources'),
 gate('H03','H','LH-01 merge/split roundtrip cases pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-LH-01'),'roundtrip'),
 gate('H04','H','LH-02 grow/contract sequence cases pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-LH-02'),'closure lifecycle'),
 gate('H05','H','LH-03 rollback cases pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-LH-03'),'rollback'),
 gate('H06','H','LH-06 RNG lifecycle cases pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-LH-06'),'RNG lifecycle'),
 gate('H07','H','LH-07 pending record lifecycle cases pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-LH-07'),'record lifecycle'),
 gate('H08','H','LH-08 restart identity cases pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-LH-08'),'restart'),
]
# I multipath
for idx,prefix in enumerate(('AC','BD','AD')):
    fams=[f'TR1-MP-{prefix}-{i:02d}' for i in range(1,5)]
    A += [gate(f'I{idx*2+1:02d}','I',f'{prefix} four multipath families all pass',lambda fams=fams: all(r['condition'] for r in runout['records'] if r['family_id'] in fams),f'{prefix} path pair'),
          gate(f'I{idx*2+2:02d}','I',f'{prefix} required references all agree',lambda fams=fams: all(r['reference']['agreement'] for r in runout['records'] if r['family_id'] in fams),f'{prefix} reference')]
A += [
 gate('I07','I','All 12 multipath families have two variants',lambda: sum(1 for r in runout['records'] if r['family_id'] in REFERENCE_FAMILIES)==24,'12x2'),
 gate('I08','I','Multipath impact map requires localization before structural promotion',lambda: 'promotion_requires' in json.load(open(ROOT/'configs/CLAIM_IMPACT_MAP.json'))['families']['TR1-MP-*'],'impact map'),
]
# J relational time
rt=[f'TR1-RT-{i:02d}' for i in [1,2,4,5,6,7,8,9,10,11,12]]
A += [
 gate('J01','J','All 11 official relational-time families pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id'] in rt),'RT cases'),
 gate('J02','J','Scalar gauge pair passes both variants',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-RT-01'),'C01'),
 gate('J03','J','Diagnostic scalar routing passes both variants',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-RT-02'),'C01'),
 gate('J04','J','Disconnected intervention passes both variants',lambda: all(r['condition'] for r in runout['records'] if r['family_id']=='TR1-RT-04'),'C02'),
 gate('J05','J','RNG resource families pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id'] in {'TR1-RT-05','TR1-RT-06'}),'C02'),
 gate('J06','J','Linearization families pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id'] in {'TR1-RT-07','TR1-RT-08','TR1-RT-09'}),'C03'),
 gate('J07','J','Provenance/gauge rewrite families pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id'] in {'TR1-RT-10','TR1-RT-11','TR1-RT-12'}),'C04'),
 gate('J08','J','Taint canary is qualification-only and detected',lambda: json.load(open(ROOT/'evidence/MUTATION_SUITE.json'))['mutations'][-1]['family_id']=='TR1-RT-03' and json.load(open(ROOT/'evidence/MUTATION_SUITE.json'))['mutations'][-1]['e1_detected'],'qualification firewall'),
]
# K long horizon
lh=[f'TR1-LH-{i:02d}' for i in range(1,9)]
A += [
 gate('K01','K','All eight long-horizon families pass',lambda: all(r['condition'] for r in runout['records'] if r['family_id'] in lh),'LH'),
 gate('K02','K','Approximation accumulation has nonnegative bound',lambda: all(raw['TR1-LH-04']['actual']['telescopic']>=raw['TR1-LH-04']['actual']['actual'] for _ in [0]),'LH-04'),
 gate('K03','K','Gauge-tree lifecycle holonomy is zero',lambda: raw['TR1-LH-05']['actual']['holonomy']==0,'LH-05'),
 gate('K04','K','RNG lifecycle keys unique',lambda: len(raw['TR1-LH-06']['actual']['keys'])==len(set(raw['TR1-LH-06']['actual']['keys'])),'LH-06'),
 gate('K05','K','Pending record rollback preserves original',lambda: raw['TR1-LH-07']['actual']['rollback_equal'],'LH-07'),
 gate('K06','K','Restart canonical digest identity holds',lambda: raw['TR1-LH-08']['actual']['before_digest']==raw['TR1-LH-08']['actual']['after_digest'],'LH-08'),
 gate('K07','K','Long-horizon steps bounded by frozen case schema',lambda: all(2<=c['parameters']['steps']<=8 for c in case_set['cases']),'finite horizon'),
 gate('K08','K','No long-horizon family uses statistical inference',lambda: json.load(open(ROOT/'configs/STATISTICAL_PROTOCOL.json'))['statistical_family_count']==0,'exact finite gates'),
]
# L governance/nonclaim/environment
gov=json.load(open(ROOT/'configs/GOVERNANCE_PROTOCOL_v0_3_0.json')); nc=json.load(open(ROOT/'configs/NONCLAIM_BARRIERS.json'))
src='\n'.join(p.read_text() for p in (ROOT/'src/lqtad_time_red1').glob('*.py'))
A += [
 gate('L01','L','Governance protocol has 24 blocking controls',lambda: gov['control_count']==24 and all(x['blocking'] for x in gov['controls']),'governance'),
 gate('L02','L','Holdout protocol requires post-freeze OS CSPRNG nonce',lambda: 'OS-CSPRNG' in json.load(open(ROOT/'configs/HOLDOUT_PROTOCOL_v0_3_0.json'))['steps'][2],'holdout'),
 gate('L03','L','Adjudication makes governance failure highest priority',lambda: json.load(open(ROOT/'configs/ADJUDICATION_PROTOCOL_v0_3_0.json'))['order'][0]=='CAMPAIGN_INVALID','adjudication'),
 gate('L04','L','No network access in scientific source',lambda: all(x not in src for x in ['requests','urllib','socket']),'network firewall'),
 gate('L05','L','No wall-clock/environment dependence in scientific source',lambda: all(x not in src for x in ['time.time','os.environ']),'environment firewall'),
 gate('L06','L','Nonclaim barriers include relativity and gravity',lambda: any('relativistic' in x for x in nc['forbidden_promotions']) and any('gravitational' in x for x in nc['forbidden_promotions']),'nonclaims'),
 gate('L07','L','Claim freeze candidate does not assign CERT-010',lambda: claims['CERT_010']=='NOT_ASSIGNED','certificate'),
 gate('L08','L','External holdout/science has not been executed locally',lambda: not (ROOT/'evidence/HOLDOUT_CASE_SET.json').exists() and not (ROOT/'evidence/SCIENTIFIC_RESULTS.json').exists(),'no premature science'),
]
assert len(A)==96,len(A)
passes=sum(x['status']=='PASS' for x in A); fails=96-passes
out={'schema':'LQTAD-TIME-RED1-PREFREEZE-HOSTILE-AUDIT-3','gate_count':96,'pass_count':passes,'fail_count':fails,'blockers':fails,'verdict':'PASS_TIME_RED_1_PREFREEZE_HOSTILE_AUDIT' if not fails else f'FAIL_TIME_RED_1_PREFREEZE_HOSTILE_AUDIT_{fails}_BLOCKERS','gates':A}
(ROOT/'evidence/PREFREEZE_HOSTILE_AUDIT.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(out['verdict']); print(passes,'/96 PASS')
if fails:
    for x in A:
        if x['status']=='FAIL': print(x['gate_id'],x['name'],x['evidence'])
sys.exit(1 if fails else 0)
