#!/usr/bin/env python3
import json,sys,platform,locale,pathlib,importlib.metadata as md
ROOT=pathlib.Path(__file__).resolve().parents[1]
pre=json.load(open(ROOT/"EVIDENCE/ENVIRONMENT.json",encoding="utf-8"))
cur={"python":sys.version,"platform":platform.platform(),"locale":locale.getlocale(),
     "packages":{}}
for name in ["numpy","pytest","jsonschema"]:
    try: cur["packages"][name]=md.version(name)
    except Exception: cur["packages"][name]="MISSING"
cur["python_matches_preflight"]=cur["python"]==pre.get("python")
cur["platform_matches_preflight"]=cur["platform"]==pre.get("platform")
if not cur["python_matches_preflight"] or not cur["platform_matches_preflight"] or "MISSING" in cur["packages"].values():
    pathlib.Path(ROOT/"SCIENTIFIC_ENVIRONMENT.json").write_text(json.dumps(cur,indent=2,sort_keys=True)+"\n")
    print("ENVIRONMENT_MISMATCH")
    raise SystemExit(3)
pathlib.Path(ROOT/"SCIENTIFIC_ENVIRONMENT.json").write_text(json.dumps(cur,indent=2,sort_keys=True)+"\n")
print("PASS_SCIENTIFIC_ENVIRONMENT_MATCH")
