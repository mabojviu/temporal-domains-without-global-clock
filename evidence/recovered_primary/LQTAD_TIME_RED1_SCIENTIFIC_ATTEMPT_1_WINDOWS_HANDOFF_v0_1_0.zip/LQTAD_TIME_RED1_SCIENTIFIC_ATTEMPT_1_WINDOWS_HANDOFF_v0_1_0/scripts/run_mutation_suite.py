#!/usr/bin/env python3
import copy,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path[:0]=[str(ROOT/'src'),str(ROOT/'vendor')]
from lqtad_time_red1 import materialize,execute_case
from lqtad_time_red1.evaluator1 import evaluate as e1
from lqtad_time_red1.evaluator2 import evaluate as e2
from lqtad_time_red1.reference import evaluate as ref
FREEZE='0'*64
cases={c['family_id']:c for c in materialize('TRAINING','MUTATION-SUITE',FREEZE,1)['cases']}
mutations=[]
def add(name,fam,mut): mutations.append((name,fam,mut))
add('scalar_projection','TR1-RT-01',lambda a:a.__setitem__('right',{'tampered':1}))
add('remote_intervention','TR1-RT-04',lambda a:a.__setitem__('remote_after','tampered'))
add('shared_randomness','TR1-RT-05',lambda a:a.__setitem__('shared_right',a['other_channel']))
add('commutation','TR1-RT-07',lambda a:a.__setitem__('right',{'tampered':1}))
add('provenance_idempotence','TR1-RT-10',lambda a:a.__setitem__('normalized_twice',[]))
add('adapter_schema','TR1-IF-01',lambda a:a.__setitem__('schema','BAD'))
add('adapter_law_error','TR1-IF-05',lambda a:a.__setitem__('law_error',1))
add('macro_stability','TR1-IF-06',lambda a:a.__setitem__('stable',False))
add('mp_ac_semantics','TR1-MP-AC-01',lambda a:a.__setitem__('right',{'tampered':1}))
add('mp_bd_bound','TR1-MP-BD-02',lambda a:a.__setitem__('defect',1))
add('merge_split_roundtrip','TR1-LH-01',lambda a:a.__setitem__('after',{}))
add('approx_bound','TR1-LH-04',lambda a:a.__setitem__('telescopic',0))
add('gauge_holonomy','TR1-LH-05',lambda a:a.__setitem__('holonomy',1))
add('rng_alias','TR1-LH-06',lambda a:a.__setitem__('keys',[a['keys'][0]]*len(a['keys'])))
add('restart_identity','TR1-LH-08',lambda a:a.__setitem__('after_digest','bad'))
rows=[]
for name,fam,mut in mutations:
    c=copy.deepcopy(cases[fam]); r=execute_case(c); mut(r['actual']); rr=ref(c,r); a=e1(c,r,rr); b=e2(c,r,rr)
    rows.append({'mutation':name,'family_id':fam,'e1_detected':not a['condition'],'e2_detected':not b['condition'],'reference_detected':bool(rr.get('required') and not rr.get('agreement'))})
# qualification scalar-taint canary
c=copy.deepcopy(next(iter(cases.values()))); c['family_id']='TR1-RT-03'; c['partition']='QUALIFICATION'; r=execute_case(c); a=e1(c,r,None); b=e2(c,r,None)
rows.append({'mutation':'qualification_scalar_taint_canary','family_id':'TR1-RT-03','e1_detected':not a['condition'],'e2_detected':not b['condition'],'reference_detected':False})
status=all(x['e1_detected'] and x['e2_detected'] for x in rows)
out={'schema':'LQTAD-TIME-RED1-MUTATION-SUITE-1','mutation_count':len(rows),'both_evaluators_detected':sum(x['e1_detected'] and x['e2_detected'] for x in rows),'status':'PASS' if status else 'FAIL','mutations':rows}
(ROOT/'evidence/MUTATION_SUITE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(out['status'],out['both_evaluators_detected'],'/',len(rows)); sys.exit(0 if status else 1)
