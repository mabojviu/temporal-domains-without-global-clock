#!/usr/bin/env python3
import hashlib,json,pathlib,sys,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
EXPECTED_AUTH_ID='LQTAD-TIME-RED1-SCIENTIFIC-ATTEMPT1-19C0172F48724C15'
EXPECTED_FREEZE_ROOT='b28592282482dc9357daf3421e0c379769e8d82c97920ff42d9241323ac8bc6a'
EXPECTED_CASE_SET_SHA='392a7d07831950a2f207a7f7d00c6806df45b444c8a496bdf1e1defcbcbc5ce0'
EXPECTED_PREFLIGHT_RETURN_SHA='4eac57b9e4969066907f610c3f9503da365314f86805d1576c83d407881e1894'
EXPECTED_CASE_FREEZE_SHA='af0ea6a5a953aeed9c51ac9c49a241e47cdaf4553ee81a285d9cee12628a2563'
EXPECTED_COUNT=156

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def die(s): print("PRECLAIM_FAIL:"+s); raise SystemExit(2)
def main():
 auth=json.load(open(ROOT/"SCIENTIFIC_AUTHORIZATION.json",encoding="utf-8"))
 cs=json.load(open(ROOT/"CASE_SET.json",encoding="utf-8"))
 fr=json.load(open(ROOT/"FREEZE_LEDGER.json",encoding="utf-8"))
 if auth.get("authorization_id")!=EXPECTED_AUTH_ID: die("AUTHORIZATION_ID")
 if auth.get("status")!="ISSUED_UNCLAIMED": die("AUTHORIZATION_STATUS")
 if auth.get("mode")!="OFFICIAL_SCIENCE" or auth.get("attempt_number")!=1: die("AUTHORIZATION_MODE")
 if auth.get("freeze_root")!=EXPECTED_FREEZE_ROOT or cs.get("freeze_root")!=EXPECTED_FREEZE_ROOT: die("FREEZE_ROOT")
 if sha(ROOT/"CASE_SET.json")!=EXPECTED_CASE_SET_SHA or auth.get("case_set_sha256")!=EXPECTED_CASE_SET_SHA: die("CASE_SET_HASH")
 canonical=json.dumps(fr["entries"],sort_keys=True,separators=(",",":")).encode()
 if hashlib.sha256(canonical).hexdigest()!=EXPECTED_FREEZE_ROOT: die("FREEZE_ROOT_RECOMPUTE")
 for e in fr["entries"]:
  p=ROOT/e["path"]
  if not p.exists() or p.stat().st_size!=e["bytes"] or sha(p)!=e["sha256"]: die("FROZEN_FILE:"+e["path"])
 if len(cs.get("cases",[]))!=EXPECTED_COUNT or cs.get("case_count")!=EXPECTED_COUNT: die("CASE_COUNT")
 # Validate through the frozen validator.
 sys.path[:0]=[str(ROOT/"src"),str(ROOT/"vendor")]
 from lqtad_time_red1.validator import validate_case_set
 errs=validate_case_set(cs)
 if errs: die("CASE_SET_INVALID:"+repr(errs[:3]))
 # Bind critical source hashes to the authorization.
 checks={
  "scripts/scientific_runner.py":"scientific_runner_sha256",
  "src/lqtad_time_red1/runtime.py":"runtime_sha256",
  "src/lqtad_time_red1/evaluator1.py":"evaluator1_sha256",
  "src/lqtad_time_red1/evaluator2.py":"evaluator2_sha256",
  "src/lqtad_time_red1/reference.py":"reference_sha256",
  "src/lqtad_time_red1/validator.py":"validator_sha256",
  "schemas/CASE_SCHEMA_v0_3_0.schema.json":"case_schema_sha256",
  "schemas/RESULT_SCHEMA_v0_3_0.schema.json":"result_schema_sha256",
  "schemas/WITNESS_SCHEMA_v0_3_0.schema.json":"witness_schema_sha256",
  "configs/FAMILY_REGISTRY.json":"family_registry_sha256",
  "configs/ADJUDICATION_PROTOCOL_v0_3_0.json":"adjudication_protocol_sha256",
  "configs/CLAIMS_FROZEN_v0_3_0.json":"claims_frozen_sha256",
 }
 for path,key in checks.items():
  if sha(ROOT/path)!=auth.get(key): die("BINDING:"+path)
 pre=ROOT/"EVIDENCE"/"LQTAD_TIME_RED1_EXTERNAL_WINDOWS_PREFLIGHT_RETURN_v0_1_0.zip"
 if sha(pre)!=EXPECTED_PREFLIGHT_RETURN_SHA or auth.get("preflight_return_zip_sha256")!=EXPECTED_PREFLIGHT_RETURN_SHA: die("PREFLIGHT_RETURN")
 cf=ROOT/"EVIDENCE"/"LQTA_D_TIME_RED_1_EXTERNAL_PREFLIGHT_INDEPENDENT_AUDIT_AND_CASE_SET_FREEZE_v1_0_PACKAGE.zip"
 if sha(cf)!=EXPECTED_CASE_FREEZE_SHA or auth.get("case_set_freeze_package_sha256")!=EXPECTED_CASE_FREEZE_SHA: die("CASE_FREEZE")
 ledger=ROOT/"DURABLE_LEDGER"
 if (ledger/"AUTHORIZATION_CLAIM.json").exists() or (ledger/"AUTHORIZATION_COMPLETION.json").exists(): die("AUTHORIZATION_ALREADY_USED")
 if (ROOT/"LQTAD_TIME_RED1_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_1_0.zip").exists(): die("RETURN_ALREADY_EXISTS")
 print("PASS_TIME_RED_1_SCIENTIFIC_ATTEMPT_1_PRECLAIM_BINDING")
if __name__=="__main__": main()
