#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os,pathlib,sys,traceback
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'vendor')]
from lqtad_time_red1.runtime import execute_case
from lqtad_time_red1.evaluator1 import evaluate as e1
from lqtad_time_red1.evaluator2 import evaluate as e2
from lqtad_time_red1.reference import evaluate as ref
from lqtad_time_red1.validator import validate_case_set
from lqtad_time_red1.canonical import canonicalize,digest

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write_json(path,obj): pathlib.Path(path).write_text(json.dumps(canonicalize(obj),indent=2,sort_keys=True)+'\n',encoding='utf-8')
def load(path): return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--case-set',required=True); ap.add_argument('--authorization',required=True); ap.add_argument('--ledger-dir',required=True); ap.add_argument('--output-dir',required=True); args=ap.parse_args()
 out=pathlib.Path(args.output_dir); out.mkdir(parents=True,exist_ok=True); led=pathlib.Path(args.ledger_dir); led.mkdir(parents=True,exist_ok=True)
 cs=load(args.case_set); auth=load(args.authorization); counts={'planned':len(cs.get('cases',[])),'attempted':0,'completed':0,'persisted':0}
 claim=led/'AUTHORIZATION_CLAIM.json'; completion=led/'AUTHORIZATION_COMPLETION.json'
 if claim.exists(): raise SystemExit('AUTHORIZATION_ALREADY_CLAIMED')
 if auth.get('status')!='ISSUED_UNCLAIMED': raise SystemExit('AUTHORIZATION_NOT_UNCLAIMED')
 if auth.get('authorization_id') is None: raise SystemExit('AUTHORIZATION_ID_MISSING')
 if auth.get('freeze_root')!=cs.get('freeze_root'): raise SystemExit('FREEZE_ROOT_MISMATCH')
 if auth.get('case_set_sha256')!=sha(args.case_set): raise SystemExit('CASE_SET_HASH_MISMATCH')
 errs=validate_case_set(cs)
 if errs: raise SystemExit('CASE_SET_INVALID:'+repr(errs[:3]))
 # Durable claim before first scientific operation.
 fd=os.open(str(claim),os.O_CREAT|os.O_EXCL|os.O_WRONLY); os.write(fd,json.dumps({'authorization_id':auth['authorization_id'],'status':'CLAIMED','freeze_root':auth['freeze_root']},sort_keys=True).encode()); os.close(fd)
 raw=[]; records=[]; witnesses=[]; terminal='EXCEPTION'; err_text=None
 try:
  for case in cs['cases']:
   counts['attempted']+=1; actual=execute_case(case); rr=ref(case,actual); a=e1(case,actual,rr); b=e2(case,actual,rr); agree=a['condition']==b['condition']; cond=agree and a['condition'] and (not rr.get('required') or rr.get('agreement'))
   raw.append({'case_id':case['case_id'],'family_id':case['family_id'],'actual':actual['actual'],'ledgers':actual['ledgers']})
   rec={'case_id':case['case_id'],'family_id':case['family_id'],'actual_output_digest':actual['actual_output_digest'],'ledger_digest':actual['ledger_digest'],'e1':a,'e2':b,'reference':rr,'gate_results':{'evaluator_agreement':agree,'e1':a['condition'],'e2':b['condition'],'reference':rr.get('agreement',True),'condition':cond}}
   records.append(rec); counts['completed']+=1
  # adjudication after all records
  famreg={x['family_id']:x for x in load(ROOT/'configs/FAMILY_REGISTRY.json')['families']}
  inconclusive=[r for r in records if not r['gate_results']['evaluator_agreement'] or (r['reference'].get('required') and not r['reference'].get('agreement'))]
  failed=[r for r in records if not r['gate_results']['condition']]
  if inconclusive: verdict='INCONCLUSIVE'
  elif failed:
   iface_all_pass=all(r['gate_results']['condition'] for r in records if r['family_id'].startswith('TR1-IF-'))
   structural=False; localized=False
   for r in failed:
    info=famreg[r['family_id']]; cls=info['impact_class']
    if cls=='TRANSVERSE_STRUCTURAL': structural=True; wcls='STRUCTURAL'
    elif cls=='LOCALIZED_INTERFACE': localized=True; wcls='LOCALIZED'
    else:
     wcls='STRUCTURAL' if iface_all_pass else 'LOCALIZED'; structural|=iface_all_pass; localized|=not iface_all_pass
    witnesses.append({'witness_id':hashlib.sha256((r['case_id']+'|'+info['claim_id']).encode()).hexdigest(),'case_id':r['case_id'],'family_id':r['family_id'],'claim_id':info['claim_id'],'classification':wcls,'immutable_result_digest':digest(r)})
   verdict='FAIL_STRUCTURAL' if structural else 'FAIL_LOCALIZED'
  else: verdict='PASS_CLEAN'
  write_json(out/'RAW_OUTPUTS.json',{'schema':'LQTAD-TIME-RED1-RAW-OUTPUTS-3','records':raw}); write_json(out/'RESULTS.json',{'schema':'LQTAD-TIME-RED1-RESULTS-3','records':records}); write_json(out/'WITNESSES.json',{'schema':'LQTAD-TIME-RED1-WITNESSES-3','witnesses':witnesses}); counts['persisted']=len(records); write_json(out/'EXECUTION_COUNTS.json',counts)
  pathlib.Path(out/'VERDICT.txt').write_text(verdict+'\n'); terminal='COMPLETED';
  bind={'schema':'LQTAD-TIME-RED1-OUTPUT-BINDING-3','authorization_id':auth['authorization_id'],'freeze_root':auth['freeze_root'],'case_set_sha256':sha(args.case_set),'outputs':{p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()}}
  write_json(out/'OUTPUT_BINDING.json',bind)
 except Exception:
  err_text=traceback.format_exc(); write_json(out/'EXECUTION_COUNTS.json',counts); pathlib.Path(out/'INCIDENT.txt').write_text(err_text); terminal='EXCEPTION'; raise
 finally:
  completion.write_text(json.dumps({'authorization_id':auth.get('authorization_id'),'status':'CONSUMED','terminal':terminal,'error':err_text},sort_keys=True,indent=2)+'\n')
if __name__=='__main__': main()
