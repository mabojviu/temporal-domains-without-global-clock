#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,zipfile,shutil,os
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUTZIP=ROOT/"LQTAD_TIME_RED1_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_1_0.zip"
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--preclaim-exit",type=int,required=True); ap.add_argument("--runner-exit",type=int,required=True); args=ap.parse_args()
 ret=ROOT/"ATTEMPT_RETURN_BUILD"
 if ret.exists(): shutil.rmtree(ret)
 ret.mkdir()
 for name in ["SCIENTIFIC_AUTHORIZATION.json","CASE_SET.json","SCIENTIFIC_ENVIRONMENT.json","SCIENTIFIC_ATTEMPT_1_POWERSHELL.log"]:
  p=ROOT/name
  if p.exists(): shutil.copy2(p,ret/name)
 for dname in ["DURABLE_LEDGER","SCIENTIFIC_OUTPUTS"]:
  src=ROOT/dname
  if src.exists(): shutil.copytree(src,ret/dname)
 claim=(ROOT/"DURABLE_LEDGER/AUTHORIZATION_CLAIM.json").exists()
 completion=(ROOT/"DURABLE_LEDGER/AUTHORIZATION_COMPLETION.json").exists()
 status={"schema":"LQTAD-TIME-RED1-ATTEMPT-RETURN-STATUS-1","preclaim_exit_code":args.preclaim_exit,
         "runner_exit_code":args.runner_exit,"authorization_claimed":claim,
         "authorization_completion_present":completion}
 (ret/"ATTEMPT_STATUS.json").write_text(json.dumps(status,indent=2,sort_keys=True)+"\n")
 entries=[]
 for p in sorted(ret.rglob("*")):
  if p.is_file():
   entries.append({"path":p.relative_to(ret).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)})
 (ret/"RETURN_MANIFEST.json").write_text(json.dumps({"schema":"LQTAD-TIME-RED1-RETURN-MANIFEST-1","entries":entries},indent=2,sort_keys=True)+"\n")
 if OUTZIP.exists(): raise SystemExit("RETURN_ALREADY_EXISTS")
 with zipfile.ZipFile(OUTZIP,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(ret.rglob("*")):
   if p.is_file(): z.write(p,p.relative_to(ret).as_posix())
 digest=sha(OUTZIP)
 pathlib.Path(str(OUTZIP)+".sha256").write_text(digest+"  "+OUTZIP.name+"\n")
 print("RETURN_ZIP="+str(OUTZIP)); print("SHA256="+digest)
if __name__=="__main__": main()
