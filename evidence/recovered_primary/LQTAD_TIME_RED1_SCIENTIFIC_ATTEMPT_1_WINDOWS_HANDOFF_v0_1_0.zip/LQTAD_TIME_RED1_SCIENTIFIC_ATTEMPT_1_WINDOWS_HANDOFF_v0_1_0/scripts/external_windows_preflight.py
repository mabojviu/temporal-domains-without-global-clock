#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,locale,os,pathlib,platform,secrets,subprocess,sys,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'vendor')]
from lqtad_time_red1 import materialize
from lqtad_time_red1.validator import validate_case_set

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def writej(p,o): pathlib.Path(p).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def main():
 freeze=json.load(open(ROOT/'FREEZE_LEDGER.json')); expected=freeze['freeze_root'];
 # verify every frozen file
 errors=[]
 for e in freeze['entries']:
  p=ROOT/e['path'];
  if not p.exists() or sha(p)!=e['sha256']: errors.append(e['path'])
 if errors: raise SystemExit('FROZEN_FILE_MISMATCH:'+repr(errors[:5]))
 # qualification only: unit tests and prefreeze audit; no official holdout execution
 env=os.environ.copy(); env['PYTHONPATH']=str(ROOT/'src')+os.pathsep+str(ROOT/'vendor')
 pt=subprocess.run([sys.executable,'-m','pytest','-q',str(ROOT/'tests')],cwd=ROOT,env=env,capture_output=True,text=True)
 if pt.returncode: raise SystemExit('PYTEST_FAIL\n'+pt.stdout+'\n'+pt.stderr)
 audit=subprocess.run([sys.executable,str(ROOT/'scripts/run_prefreeze_hostile_audit.py')],cwd=ROOT,env=env,capture_output=True,text=True)
 if audit.returncode: raise SystemExit('AUDIT_FAIL\n'+audit.stdout+'\n'+audit.stderr)
 nonce=secrets.token_hex(32); commitment=hashlib.sha256(bytes.fromhex(nonce)).hexdigest()
 training=materialize('TRAINING','TIME-RED1-FROZEN-TRAINING-V1',expected,2)
 holdout=materialize('HOLDOUT','HOLDOUT|'+nonce,expected,2)
 combined={'schema':'LQTAD-TIME-RED1-CASE-SET-3','partition':'COMBINED','freeze_root':expected,'case_count':training['case_count']+holdout['case_count'],'cases':training['cases']+holdout['cases']}
 errs=validate_case_set(combined)
 if errs: raise SystemExit('CASE_SET_INVALID:'+repr(errs[:5]))
 ret=ROOT/'PREFLIGHT_RETURN'; ret.mkdir(exist_ok=True)
 writej(ret/'CASE_SET.json',combined); writej(ret/'HOLDOUT_COMMITMENT.json',{'schema':'LQTAD-TIME-RED1-HOLDOUT-COMMITMENT-3','nonce_hex':nonce,'nonce_sha256':commitment,'freeze_root':expected,'training_count':training['case_count'],'holdout_count':holdout['case_count'],'case_set_sha256':sha(ret/'CASE_SET.json')})
 writej(ret/'ENVIRONMENT.json',{'python':sys.version,'platform':platform.platform(),'locale':locale.getlocale(),'timezone':os.environ.get('TZ'),'hashseed':os.environ.get('PYTHONHASHSEED'),'pytest_stdout':pt.stdout,'audit_stdout':audit.stdout})
 writej(ret/'NO_ADAPTATION_LEDGER.json',{'schema':'LQTAD-TIME-RED1-NO-ADAPTATION-3','freeze_root':expected,'frozen_entries':freeze['entries'],'rule':'Any change to a frozen entry after this holdout materialization invalidates the campaign.'})
 writej(ret/'PREFLIGHT_VERDICT.json',{'verdict':'PASS_TIME_RED_1_EXTERNAL_WINDOWS_PREFLIGHT_HOLDOUT_MATERIALIZED_SCIENCE_NOT_AUTHORIZED','freeze_root':expected,'case_set_sha256':sha(ret/'CASE_SET.json'),'scientific_cases_executed':0})
 print('PASS_TIME_RED_1_EXTERNAL_WINDOWS_PREFLIGHT_HOLDOUT_MATERIALIZED_SCIENCE_NOT_AUTHORIZED')
if __name__=='__main__': main()
