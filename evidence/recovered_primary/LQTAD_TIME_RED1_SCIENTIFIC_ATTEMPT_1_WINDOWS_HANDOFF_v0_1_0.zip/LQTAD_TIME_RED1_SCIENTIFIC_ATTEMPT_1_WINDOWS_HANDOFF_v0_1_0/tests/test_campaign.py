from __future__ import annotations
import copy
from lqtad_time_red1 import materialize,run,execute_case,OFFICIAL_FAMILIES
from lqtad_time_red1.validator import validate_case,validate_case_set
from lqtad_time_red1.evaluator1 import evaluate as e1
from lqtad_time_red1.evaluator2 import evaluate as e2
from lqtad_time_red1.reference import evaluate as ref
FREEZE='0'*64

def cases(): return materialize('TRAINING','UNIT-TEST-MATERIAL',FREEZE,1)['cases']

def test_family_count(): assert len(OFFICIAL_FAMILIES)==39 and len(set(OFFICIAL_FAMILIES))==39

def test_every_family_executes_and_two_evaluators_pass():
    seen=set()
    for c in cases():
        assert not validate_case(c); r=execute_case(c); rr=ref(c,r); a=e1(c,r,rr); b=e2(c,r,rr)
        assert a['condition'], c['family_id']; assert b['condition'], c['family_id']; assert a['condition']==b['condition']; assert rr['agreement']; seen.add(c['family_id'])
    assert seen==set(OFFICIAL_FAMILIES)

def test_case_set_and_campaign():
    cs=materialize('TRAINING','UNIT-TEST-MATERIAL-2',FREEZE,2); assert not validate_case_set(cs); r=run(cs); assert r['case_count']==78; assert r['failure_count']==0; assert r['evaluator_disagreement_count']==0; assert r['reference_failure_count']==0

def test_no_outcome_fields_in_cases():
    cs=materialize('TRAINING','X',FREEZE,1)
    raw=repr(cs)
    for word in ['actual_output_digest','expected_verdict','reference_answer','future_kernel','witness_class']: assert word not in raw

def test_duplicate_case_id_rejected():
    cs=materialize('TRAINING','X',FREEZE,1); cs['cases'][1]['case_id']=cs['cases'][0]['case_id']; assert 'duplicate-case-id' in validate_case_set(cs)

def test_bad_weight_rejected():
    c=cases()[0]; c=copy.deepcopy(c); c['parameters']['weight_num']=c['parameters']['weight_den']+1; assert 'weight' in validate_case(c)

def test_freeze_root_required():
    c=cases()[0]; c=copy.deepcopy(c); c['freeze_root']='x'; assert 'freeze-root' in validate_case(c)

def test_runtime_has_no_gate_or_pass_field():
    c=cases()[0]; r=execute_case(c); raw=repr(r); assert "'condition'" not in raw and "'passed'" not in raw and "'gate_results'" not in raw

def test_qualification_taint_canary_is_detected():
    c=cases()[0]; c=copy.deepcopy(c); c['family_id']='TR1-RT-03'; c['partition']='QUALIFICATION'; r=execute_case(c); a=e1(c,r,None); b=e2(c,r,None); assert not a['condition']; assert not b['condition']

def test_mutation_of_mp_output_is_detected_by_both():
    c=next(x for x in cases() if x['family_id']=='TR1-MP-AD-01'); r=execute_case(c); r=copy.deepcopy(r); r['actual']['right']['law_error']=1; rr=ref(c,r); assert not e1(c,r,rr)['condition']; assert not e2(c,r,rr)['condition']

def test_mutation_of_resource_digest_detected():
    c=next(x for x in cases() if x['family_id']=='TR1-IF-08'); r=execute_case(c); r=copy.deepcopy(r); r['actual']['D']='bad'; rr=ref(c,r); assert not e1(c,r,rr)['condition']; assert not e2(c,r,rr)['condition']

def test_mutation_of_remote_intervention_detected():
    c=next(x for x in cases() if x['family_id']=='TR1-RT-04'); r=execute_case(c); r=copy.deepcopy(r); r['actual']['remote_after']='bad'; rr=ref(c,r); assert not e1(c,r,rr)['condition']; assert not e2(c,r,rr)['condition']

def test_mutation_of_rollback_detected():
    c=next(x for x in cases() if x['family_id']=='TR1-LH-03'); r=execute_case(c); r=copy.deepcopy(r); r['actual']['rollback_bytes_equal']=False; rr=ref(c,r); assert not e1(c,r,rr)['condition']; assert not e2(c,r,rr)['condition']
