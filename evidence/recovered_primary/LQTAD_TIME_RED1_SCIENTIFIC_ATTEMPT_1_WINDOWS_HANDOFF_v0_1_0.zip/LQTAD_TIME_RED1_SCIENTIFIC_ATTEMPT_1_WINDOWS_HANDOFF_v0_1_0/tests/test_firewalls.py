from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
def imports(path):
    t=ast.parse(path.read_text()); out=[]
    for n in ast.walk(t):
        if isinstance(n,ast.Import): out += [x.name for x in n.names]
        if isinstance(n,ast.ImportFrom): out.append(n.module or '')
    return out

def test_generator_does_not_import_evaluators_reference_or_campaign():
    im=imports(ROOT/'src/lqtad_time_red1/casegen.py'); assert not any(x.endswith(('evaluator1','evaluator2','reference','campaign')) for x in im)

def test_runtime_does_not_import_evaluators_reference_or_campaign():
    im=imports(ROOT/'src/lqtad_time_red1/runtime.py'); assert not any(x.endswith(('evaluator1','evaluator2','reference','campaign')) for x in im)

def test_evaluators_do_not_import_runtime_or_each_other():
    for f in ('evaluator1.py','evaluator2.py'):
        im=imports(ROOT/'src/lqtad_time_red1'/f); assert not any(x.endswith(('runtime','reference','campaign','evaluator1','evaluator2')) for x in im)

def test_reference_does_not_import_evaluators_runtime_campaign():
    im=imports(ROOT/'src/lqtad_time_red1/reference.py'); assert not any(x.endswith(('runtime','campaign','evaluator1','evaluator2')) for x in im)

def test_no_network_or_environment_access():
    text='\n'.join(p.read_text() for p in (ROOT/'src/lqtad_time_red1').glob('*.py'))
    for token in ['requests','urllib','socket','os.environ','time.time']: assert token not in text
