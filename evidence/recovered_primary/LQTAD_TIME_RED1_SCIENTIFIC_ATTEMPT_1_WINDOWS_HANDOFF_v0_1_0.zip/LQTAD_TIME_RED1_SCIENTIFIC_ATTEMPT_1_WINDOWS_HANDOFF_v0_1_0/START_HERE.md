# TIME-RED-1 v0.3.0 — frozen campaign preflight package

This package is **not a scientific authorization**. It contains the frozen source/runtime/adapters/evaluators/reference/schemas/claims and an external Windows preflight that verifies the freeze, runs qualification tests, creates the post-freeze OS-CSPRNG holdout nonce, and materializes the 156-case official case set without executing scientific cases.

Run `run_windows_preflight.ps1` exactly once after extraction in a clean folder, then return the generated preflight ZIP and SHA-256 sidecar. Holdout visibility after the freeze is permitted; any frozen-file change after materialization invalidates the campaign.
