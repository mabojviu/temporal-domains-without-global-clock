$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
$ReturnZip = Join-Path $Root "LQTAD_TIME_RED1_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_1_0.zip"
if (Test-Path $ReturnZip) {
  Write-Error "RETURN_ALREADY_EXISTS: do not rerun this handoff."
  exit 90
}
$Log = Join-Path $Root "SCIENTIFIC_ATTEMPT_1_POWERSHELL.log"
"TIME-RED-1 SCIENTIFIC ATTEMPT 1" | Out-File -FilePath $Log -Encoding utf8
$pre = 0
$run = 98

python .\scripts\verify_scientific_attempt_binding.py 2>&1 | Tee-Object -FilePath $Log -Append
$pre = $LASTEXITCODE
if ($pre -eq 0) {
  python .\scripts\verify_scientific_environment.py 2>&1 | Tee-Object -FilePath $Log -Append
  $envrc = $LASTEXITCODE
  if ($envrc -eq 0) {
    python .\scripts\scientific_runner.py `
      --case-set .\CASE_SET.json `
      --authorization .\SCIENTIFIC_AUTHORIZATION.json `
      --ledger-dir .\DURABLE_LEDGER `
      --output-dir .\SCIENTIFIC_OUTPUTS 2>&1 | Tee-Object -FilePath $Log -Append
    $run = $LASTEXITCODE
  } else {
    $run = 97
  }
} else {
  $run = 96
}
python .\scripts\package_scientific_return.py --preclaim-exit $pre --runner-exit $run 2>&1 | Tee-Object -FilePath $Log -Append
$pack = $LASTEXITCODE
if ($pack -ne 0) { exit $pack }
Write-Host "ATTEMPT_RUNNER_EXIT_CODE=$run"
if ($run -eq 0) { Write-Host "SCIENTIFIC_ATTEMPT_COMPLETED_RETURN_READY" }
else { Write-Host "SCIENTIFIC_ATTEMPT_NOT_CLEAN_RETURN_READY_DO_NOT_RERUN" }
exit $run
