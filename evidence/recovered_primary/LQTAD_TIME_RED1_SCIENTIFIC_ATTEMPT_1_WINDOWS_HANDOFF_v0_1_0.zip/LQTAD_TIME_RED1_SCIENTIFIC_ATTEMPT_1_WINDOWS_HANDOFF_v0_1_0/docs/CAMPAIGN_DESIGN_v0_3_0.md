# TIME-RED-1 v0.3.0 external adversarial requalification design

## Purpose

Qualify the newly implemented transverse composition 2A -> 2B -> 2C -> B3 on a frozen finite domain, without modifying any upstream qualification. The three adapters are new scientific objects. The campaign jointly attacks operational relational-time claims, adapter contracts, registered multipath coherence, resource/transaction integrity, and B3-ended finite-horizon stability.

## Scientific domain

The official case domain has 39 activated deterministic scientific families. `TR1-RT-03` is retained only as a qualification taint canary and is forbidden from the official case set. Every official family has two training and two post-freeze holdout variants, for 78 training + 78 holdout = 156 official cases.

The primitive source is a two-domain finite product root using the callable-bound D1.6B-2A state types and keyed residual resources. The A->B adapter creates a certificate-free dynamic-closure view. The B->C adapter appends an exact rank-one mixed-state representation while preserving the complete upstream resource/source envelope. A declared binary instrument kernel is computed at runtime by the D1.6B-2C instrument primitive. The C->B3 adapter embeds that exact runtime-computable law with zero initial TV defect and a separate zero adapter coordinate-uncertainty channel.

## Independence

The generator does not import E1, E2, reference, adjudication, or campaign code. Runtime does not import evaluators/reference. E1 and E2 are separate implementations and import neither runtime nor each other. Reference is separately scoped to the 12 registered multipath families.

## Holdout

After source/runtime/evaluator/reference/schema/registry/claim hashes freeze, an external Windows preflight creates a 256-bit OS-CSPRNG nonce. Holdout seeds are deterministically derived from the nonce, freeze root, family ID, and variant. Any source or registry change after holdout materialization invalidates the campaign.

## Adjudication

Any governance failure yields `CAMPAIGN_INVALID`. E1/E2 disagreement or required reference disagreement yields `INCONCLUSIVE`. Exact interface witnesses yield `FAIL_LOCALIZED` unless the frozen claim-impact map proves a transverse composition defect. Valid structural witnesses yield `FAIL_STRUCTURAL`. If all activated claims pass, the maximum verdict is `PASS_CLEAN` within this frozen finite domain only.

## Nonclaims

No continuum, relativistic, gravitational, universal-unravelling, fundamental-time, absolute-time, or universal emergent-time claim is tested or implied.
