$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$env:PYTHONHASHSEED = "0"
python .\scripts\external_windows_preflight.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$returnDir = Join-Path $root "PREFLIGHT_RETURN"
$zip = Join-Path $root "LQTAD_TIME_RED1_EXTERNAL_WINDOWS_PREFLIGHT_RETURN_v0_1_0.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $returnDir "*") -DestinationPath $zip -CompressionLevel Optimal
$hash=(Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
"$hash  $(Split-Path $zip -Leaf)" | Set-Content -Encoding ASCII ($zip + ".sha256")
Write-Host "RETURN_ZIP=$zip"
Write-Host "SHA256=$hash"
