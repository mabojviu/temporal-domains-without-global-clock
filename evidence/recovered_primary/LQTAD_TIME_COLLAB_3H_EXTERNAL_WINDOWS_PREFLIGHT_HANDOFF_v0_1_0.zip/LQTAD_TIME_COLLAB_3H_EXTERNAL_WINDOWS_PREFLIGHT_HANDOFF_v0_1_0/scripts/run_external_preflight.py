import json,pathlib,sys,secrets,hashlib,platform,locale,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from generator import materialize
from validator import validate_case_set
fr=json.load(open(ROOT/"FREEZE_LEDGER.json",encoding="utf-8"))
canonical=json.dumps(fr["entries"],sort_keys=True,separators=(",",":")).encode()
if hashlib.sha256(canonical).hexdigest()!=fr["freeze_root"]:
    raise SystemExit("FREEZE_ROOT_FAIL")
for e in fr["entries"]:
    p=ROOT/e["path"]
    if not p.exists() or p.stat().st_size!=e["bytes"] or hashlib.sha256(p.read_bytes()).hexdigest()!=e["sha256"]:
        raise SystemExit("FROZEN_FILE_FAIL:"+e["path"])
nonce=secrets.token_hex(32)
cs=materialize(nonce,fr["freeze_root"])
errs=validate_case_set(cs)
if errs: raise SystemExit("CASE_SET_INVALID:"+repr(errs))
out=ROOT/"PREFLIGHT_RETURN_BUILD"
out.mkdir(exist_ok=False)
def dump(n,o): (out/n).write_text(json.dumps(o,indent=2,sort_keys=True)+"\n",encoding="utf-8")
dump("CASE_SET.json",cs)
raw=(out/"CASE_SET.json").read_bytes()
dump("HOLDOUT_COMMITMENT.json",{"freeze_root":fr["freeze_root"],"nonce_hex":nonce,
 "nonce_sha256":hashlib.sha256(bytes.fromhex(nonce)).hexdigest(),
 "case_set_sha256":hashlib.sha256(raw).hexdigest(),"case_count":288})
dump("ENVIRONMENT.json",{"python":sys.version,"platform":platform.platform(),"locale":locale.getlocale()})
dump("NO_ADAPTATION_LEDGER.json",{"freeze_root":fr["freeze_root"],"frozen_entries":fr["entries"],
 "rule":"Any modification of a frozen entry after nonce creation invalidates the campaign."})
dump("PREFLIGHT_VERDICT.json",{"verdict":"PASS_TIME_COLLAB_3H_EXTERNAL_PREFLIGHT_HOLDOUT_MATERIALIZED_SCIENCE_NOT_AUTHORIZED",
 "freeze_root":fr["freeze_root"],"case_set_sha256":hashlib.sha256(raw).hexdigest(),"scientific_cases_executed":0})
zipname=ROOT/"LQTAD_TIME_COLLAB_3H_EXTERNAL_WINDOWS_PREFLIGHT_RETURN_v0_1_0.zip"
with zipfile.ZipFile(zipname,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.iterdir()): z.write(p,p.name)
digest=hashlib.sha256(zipname.read_bytes()).hexdigest()
pathlib.Path(str(zipname)+".sha256").write_text(digest+"  "+zipname.name+"\n")
print("PASS_TIME_COLLAB_3H_EXTERNAL_PREFLIGHT_HOLDOUT_MATERIALIZED_SCIENCE_NOT_AUTHORIZED")
print("RETURN_ZIP="+str(zipname)); print("SHA256="+digest)
