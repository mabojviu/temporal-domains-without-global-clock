# TIME-COLLAB-3H external Windows preflight

This is NON-SCIENTIFIC. It verifies the frozen foundations, generates a 256-bit OS-CSPRNG nonce, materializes 288 unseen cases, and executes **zero** scientific cases.

Freeze root:
`7605dafed6fe36db617b381817fea83192634b2612c133ba6edb1a9f1f97cf85`

Run exactly:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_windows_preflight.ps1
```

Return both generated files:
- `LQTAD_TIME_COLLAB_3H_EXTERNAL_WINDOWS_PREFLIGHT_RETURN_v0_1_0.zip`
- `LQTAD_TIME_COLLAB_3H_EXTERNAL_WINDOWS_PREFLIGHT_RETURN_v0_1_0.zip.sha256`

Do not run `scripts/scientific_runner.py`; no scientific authorization exists yet.
