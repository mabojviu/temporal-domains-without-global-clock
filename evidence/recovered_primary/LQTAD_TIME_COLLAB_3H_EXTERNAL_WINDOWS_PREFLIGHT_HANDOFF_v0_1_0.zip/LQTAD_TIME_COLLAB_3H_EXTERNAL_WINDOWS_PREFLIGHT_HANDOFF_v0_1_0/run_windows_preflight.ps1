$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
python .\scripts\run_external_preflight.py
exit $LASTEXITCODE
