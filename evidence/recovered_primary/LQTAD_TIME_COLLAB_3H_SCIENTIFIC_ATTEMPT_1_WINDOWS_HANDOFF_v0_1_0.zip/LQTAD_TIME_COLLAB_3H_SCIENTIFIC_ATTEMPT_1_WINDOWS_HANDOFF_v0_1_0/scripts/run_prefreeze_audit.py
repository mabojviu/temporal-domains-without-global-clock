import json,pathlib,sys,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from generator import materialize
from validator import validate_case_set
from evaluator import analyze
from adjudicator import adjudicate
freeze="TRAINING-NOT-HOLDOUT"
cs=materialize("TRAINING-FIXED-NONCE-ONLY",freeze)
assert validate_case_set(cs)==[]
# Controls only are asserted scientifically here; official holdout thresholds are NOT evaluated on training.
rs=[analyze(c) for c in cs["cases"] if "CONTROL" in c["family"]]
pos=[r for r in rs if r["family"]=="POS_CHAIN_CONTROL"]
neg=[r for r in rs if r["family"]=="NEG_DIRECT_BYPASS_CONTROL"]
assert len(pos)==16 and all(r["kappa"]==r["n"] and r["Q_nonconstant"] for r in pos)
assert len(neg)==16 and all(r["kappa"]==2 and r["Q_nonconstant"] for r in neg)
print("PASS_PREFREEZE_TECHNICAL_AND_CONTROL_AUDIT")
