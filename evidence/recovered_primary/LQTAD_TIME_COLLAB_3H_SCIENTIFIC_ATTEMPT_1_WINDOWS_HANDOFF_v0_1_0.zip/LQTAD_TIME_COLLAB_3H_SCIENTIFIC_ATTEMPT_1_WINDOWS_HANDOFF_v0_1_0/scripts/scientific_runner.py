import argparse,json,pathlib,sys,traceback,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from validator import validate_case_set
from evaluator import analyze
from adjudicator import adjudicate

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def dump(p,o): pathlib.Path(p).write_text(json.dumps(o,indent=2,sort_keys=True)+"\n",encoding="utf-8")
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument("--case-set",required=True); ap.add_argument("--authorization",required=True)
 ap.add_argument("--ledger-dir",required=True); ap.add_argument("--output-dir",required=True)
 a=ap.parse_args()
 cs=json.load(open(a.case_set)); auth=json.load(open(a.authorization))
 if validate_case_set(cs): raise SystemExit("INVALID_CASE_SET")
 if sha(a.case_set)!=auth["case_set_sha256"]: raise SystemExit("CASE_SET_HASH_MISMATCH")
 ledger=pathlib.Path(a.ledger_dir); out=pathlib.Path(a.output_dir)
 ledger.mkdir(parents=True,exist_ok=True); out.mkdir(parents=True,exist_ok=True)
 claim=ledger/"AUTHORIZATION_CLAIM.json"
 if claim.exists(): raise SystemExit("AUTH_ALREADY_CLAIMED")
 dump(claim,{"authorization_id":auth["authorization_id"],"status":"CLAIMED","case_set_sha256":auth["case_set_sha256"]})
 err=None
 try:
  results=[analyze(c) for c in cs["cases"]]
  verdict,gates,summary=adjudicate(results)
  dump(out/"RESULTS.json",{"schema":"LQTA-D-TIME-COLLAB-3H-RESULTS-1","records":results})
  dump(out/"GATES.json",gates); dump(out/"SUMMARY.json",summary)
  (out/"VERDICT.txt").write_text(verdict+"\n")
  dump(out/"OUTPUT_BINDING.json",{"authorization_id":auth["authorization_id"],"case_set_sha256":auth["case_set_sha256"],
       "outputs":{p.name:sha(p) for p in [out/"RESULTS.json",out/"GATES.json",out/"SUMMARY.json",out/"VERDICT.txt"]}})
 finally:
  dump(ledger/"AUTHORIZATION_COMPLETION.json",{"authorization_id":auth["authorization_id"],"status":"CONSUMED","error":err})
if __name__=="__main__":
 main()
