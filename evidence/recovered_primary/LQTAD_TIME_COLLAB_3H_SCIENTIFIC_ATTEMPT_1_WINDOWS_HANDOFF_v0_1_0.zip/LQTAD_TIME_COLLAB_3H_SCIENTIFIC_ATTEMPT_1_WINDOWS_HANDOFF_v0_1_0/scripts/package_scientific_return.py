#!/usr/bin/env python3
import argparse,pathlib,hashlib,zipfile,shutil,json
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/"LQTAD_TIME_COLLAB_3H_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_1_0.zip"
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
ap=argparse.ArgumentParser(); ap.add_argument("--preclaim-exit",type=int,required=True); ap.add_argument("--runner-exit",type=int,required=True); a=ap.parse_args()
ret=ROOT/"ATTEMPT_RETURN_BUILD"
if ret.exists(): shutil.rmtree(ret)
ret.mkdir()
for n in ["SCIENTIFIC_AUTHORIZATION.json","CASE_SET.json","SCIENTIFIC_ENVIRONMENT.json","SCIENTIFIC_ATTEMPT_1_POWERSHELL.log"]:
 p=ROOT/n
 if p.exists(): shutil.copy2(p,ret/n)
for d in ["DURABLE_LEDGER","SCIENTIFIC_OUTPUTS"]:
 p=ROOT/d
 if p.exists(): shutil.copytree(p,ret/d)
(ret/"ATTEMPT_STATUS.json").write_text(json.dumps({"preclaim_exit_code":a.preclaim_exit,"runner_exit_code":a.runner_exit,"authorization_claimed":(ROOT/"DURABLE_LEDGER/AUTHORIZATION_CLAIM.json").exists(),"authorization_completion_present":(ROOT/"DURABLE_LEDGER/AUTHORIZATION_COMPLETION.json").exists()},indent=2,sort_keys=True)+"\n")
entries=[]
for p in sorted(ret.rglob("*")):
 if p.is_file(): entries.append({"path":p.relative_to(ret).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)})
(ret/"RETURN_MANIFEST.json").write_text(json.dumps({"entries":entries},indent=2,sort_keys=True)+"\n")
if OUT.exists(): raise SystemExit("RETURN_ALREADY_EXISTS")
with zipfile.ZipFile(OUT,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(ret.rglob("*")):
  if p.is_file(): z.write(p,p.relative_to(ret).as_posix())
d=sha(OUT); pathlib.Path(str(OUT)+".sha256").write_text(d+"  "+OUT.name+"\n")
print("RETURN_ZIP="+str(OUT)); print("SHA256="+d)
