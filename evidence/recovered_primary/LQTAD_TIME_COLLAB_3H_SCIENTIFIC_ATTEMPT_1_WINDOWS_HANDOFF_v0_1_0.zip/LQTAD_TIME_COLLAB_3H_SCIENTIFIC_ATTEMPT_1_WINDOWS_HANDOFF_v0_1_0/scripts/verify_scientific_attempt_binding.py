#!/usr/bin/env python3
import hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
AUTH='LQTAD-TIME-COLLAB-3H-SCIENTIFIC-ATTEMPT1-8AFAB90FEDC58BCD'; FREEZE='7605dafed6fe36db617b381817fea83192634b2612c133ba6edb1a9f1f97cf85'; CASESHA='6723a07feb3d3cdc266ea28203849315605ed36369c99174f1668319901fc2f2'
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def die(x): print("PRECLAIM_FAIL:"+x); raise SystemExit(2)
a=json.load(open(ROOT/"SCIENTIFIC_AUTHORIZATION.json",encoding="utf-8"))
cs=json.load(open(ROOT/"CASE_SET.json",encoding="utf-8"))
fr=json.load(open(ROOT/"FREEZE_LEDGER.json",encoding="utf-8"))
if a["authorization_id"]!=AUTH or a["status"]!="ISSUED_UNCLAIMED": die("AUTH")
if a["freeze_root"]!=FREEZE or cs["freeze_root"]!=FREEZE: die("FREEZE")
if sha(ROOT/"CASE_SET.json")!=CASESHA or a["case_set_sha256"]!=CASESHA: die("CASE_HASH")
can=json.dumps(fr["entries"],sort_keys=True,separators=(",",":")).encode()
if hashlib.sha256(can).hexdigest()!=FREEZE: die("FREEZE_RECOMPUTE")
for e in fr["entries"]:
 p=ROOT/e["path"]
 if not p.exists() or p.stat().st_size!=e["bytes"] or sha(p)!=e["sha256"]: die("FROZEN:"+e["path"])
sys.path.insert(0,str(ROOT/"src"))
from validator import validate_case_set
errs=validate_case_set(cs)
if errs: die("CASESET:"+repr(errs))
checks={"src/generator.py":"generator_sha256","src/evaluator.py":"evaluator_sha256","src/adjudicator.py":"adjudicator_sha256","src/validator.py":"validator_sha256","scripts/scientific_runner.py":"scientific_runner_sha256","HOLDOUT_SPEC.json":"holdout_spec_sha256"}
for p,k in checks.items():
 if sha(ROOT/p)!=a[k]: die("BIND:"+p)
L=ROOT/"DURABLE_LEDGER"
if (L/"AUTHORIZATION_CLAIM.json").exists() or (L/"AUTHORIZATION_COMPLETION.json").exists(): die("ALREADY_USED")
print("PASS_TIME_COLLAB_3H_SCIENTIFIC_ATTEMPT_1_PRECLAIM_BINDING")
