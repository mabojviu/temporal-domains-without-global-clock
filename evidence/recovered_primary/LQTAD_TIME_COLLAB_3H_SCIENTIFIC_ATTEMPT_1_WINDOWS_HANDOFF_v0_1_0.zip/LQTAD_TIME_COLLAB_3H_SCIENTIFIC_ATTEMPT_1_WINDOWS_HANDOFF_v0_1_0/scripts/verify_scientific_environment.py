#!/usr/bin/env python3
import json,pathlib,platform,sys,locale
ROOT=pathlib.Path(__file__).resolve().parents[1]
pre=json.load(open(ROOT/"EVIDENCE/ENVIRONMENT.json",encoding="utf-8"))
cur={"python":sys.version,"platform":platform.platform(),"locale":locale.getlocale()}
cur["python_matches_preflight"]=cur["python"]==pre.get("python")
cur["platform_matches_preflight"]=cur["platform"]==pre.get("platform")
(ROOT/"SCIENTIFIC_ENVIRONMENT.json").write_text(json.dumps(cur,indent=2,sort_keys=True)+"\n",encoding="utf-8")
if not cur["python_matches_preflight"] or not cur["platform_matches_preflight"]:
 print("ENVIRONMENT_MISMATCH"); raise SystemExit(3)
print("PASS_SCIENTIFIC_ENVIRONMENT_MATCH")
