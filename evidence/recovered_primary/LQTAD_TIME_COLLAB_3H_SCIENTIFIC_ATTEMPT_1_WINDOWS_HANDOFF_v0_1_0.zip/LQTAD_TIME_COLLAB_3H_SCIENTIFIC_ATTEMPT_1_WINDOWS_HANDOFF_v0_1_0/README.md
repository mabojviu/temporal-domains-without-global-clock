# TIME-COLLAB-3H holdout foundations

This package freezes the generator, evaluator, adjudicator, thresholds and scientific runner before any holdout nonce exists.

The official holdout contains 288 cases:
- 64 sparse base
- 64 shortcut stress
- 64 token-loss
- 64 rich ternary-rule
- 16 positive chain controls
- 16 negative direct-bypass controls

The campaign can fail scientifically. In particular, kappa=2 is treated as endpoint-only and is not sufficient for substantive success.
