from collections import Counter,defaultdict

def adjudicate(results):
    by=defaultdict(list)
    for r in results: by[r["family"]].append(r)
    gates={}
    gates["H0_TECHNICAL"]=(len(results)==288 and len({r["case_id"] for r in results})==288)
    pos=by["POS_CHAIN_CONTROL"]
    gates["H1_POSITIVE_CONTROL"]=(len(pos)==16 and all(r["Q_nonconstant"] and r["kappa"]==r["n"] for r in pos))
    neg=by["NEG_DIRECT_BYPASS_CONTROL"]
    gates["H2_NEGATIVE_CONTROL"]=(len(neg)==16 and all(r["Q_nonconstant"] and r["kappa"]==2 for r in neg))
    gates["H3_SPARSE_BASE"]=(sum(r["intermediate_collaboration"] for r in by["SPARSE_BASE"])>=24)
    gates["H4_SHORTCUT_STRESS"]=(sum(r["intermediate_collaboration"] for r in by["SHORTCUT_STRESS"])>=12)
    loss=by["TOKEN_LOSS"]; connected=[r for r in loss if r["connected_after_loss"]]
    gates["H5_TOKEN_LOSS_SURVIVAL"]=(len(connected)>=32 and sum(r["intermediate_collaboration"] for r in connected)*4>=len(connected))
    rich=by["RICH_RULE"]
    gates["H6_RICH_RULE_NONDEGENERACY"]=(sum(r["Q_nonconstant"] for r in rich)>=32)
    gates["H7_RICH_RULE_COLLABORATION"]=(sum(r["intermediate_collaboration"] for r in rich)>=16)
    outside=[r for f,rs in by.items() if "CONTROL" not in f for r in rs]
    gates["H8_NO_ENDPOINT_ONLY_PROMOTION"]=any(r["kappa"]>2 for r in outside)
    verdict="PASS_ROBUSTNESS_GENERICITY_HOLDOUT" if all(gates.values()) else "FAIL_ROBUSTNESS_GENERICITY_HOLDOUT"
    summary={}
    for fam,rs in by.items():
        summary[fam]={
          "count":len(rs),
          "Q_nonconstant":sum(r["Q_nonconstant"] for r in rs),
          "kappa_gt_2":sum(r["intermediate_collaboration"] for r in rs),
          "kappa_distribution":dict(sorted(Counter(r["kappa"] for r in rs).items())),
          "mean_essential_fraction":sum(r["essential_fraction"] for r in rs)/len(rs)
        }
        if fam=="TOKEN_LOSS":
            summary[fam]["connected_after_loss"]=sum(r["connected_after_loss"] for r in rs)
    return verdict,gates,summary
