import itertools

def has_path(n,edges):
    adj={i:[] for i in range(n)}
    for a,b in edges: adj[a].append(b)
    st=[0]; seen=set()
    while st:
        u=st.pop()
        if u==n-1:return True
        if u in seen:continue
        seen.add(u); st.extend(v for v in adj[u] if v not in seen)
    return False

def q_binary(case,bits):
    n=case["n"]; edges=case["edges"]
    if not bits[0] or not bits[n-1]: return False
    adj={i:[] for i in range(n)}
    for a,b in edges: adj[a].append(b)
    st=[0]; seen=set()
    while st:
        u=st.pop()
        if u==n-1:return True
        if u in seen:continue
        seen.add(u)
        for v in adj[u]:
            if bits[v] and v not in seen: st.append(v)
    return False

def q_rich(case,states):
    n=case["n"]; table=case["rule_table"]
    before=[table[str(i)][states[i]]["before"] for i in range(n)]
    if not before[0] or not before[n-1]: return False
    st=[0]; seen=set()
    while st:
        u=st.pop()
        if u==n-1:return True
        if u in seen:continue
        seen.add(u)
        v=table[str(u)][states[u]]["emit_to"]
        if v is not None and before[v] and v not in seen:
            st.append(v)
    return False

def analyze(case):
    n=case["n"]; rich=case["family"]=="RICH_RULE"
    alphabet=range(3) if rich else range(2)
    qfun=q_rich if rich else q_binary
    values=set(); essential=[]
    # Exact essential-variable test.
    for assignment in itertools.product(alphabet, repeat=n):
        values.add(bool(qfun(case,assignment)))
    for v in range(n):
        others=[i for i in range(n) if i!=v]
        found=False
        for vals in itertools.product(alphabet, repeat=n-1):
            base=[0]*n
            for i,x in zip(others,vals): base[i]=x
            outs=set()
            for a in alphabet:
                base[v]=a
                outs.add(bool(qfun(case,tuple(base))))
            if len(outs)>1:
                found=True; break
        if found: essential.append(v)
    kappa=len(essential) if len(values)>1 else 0
    return {"case_id":case["case_id"],"family":case["family"],"n":n,
            "Q_nonconstant":len(values)>1,"kappa":kappa,
            "intermediate_collaboration":kappa>2,
            "essential_fraction":kappa/n,
            "essential_vertices":essential,
            "connected_after_loss":has_path(n,case["edges"]) if case["family"]=="TOKEN_LOSS" else None}
