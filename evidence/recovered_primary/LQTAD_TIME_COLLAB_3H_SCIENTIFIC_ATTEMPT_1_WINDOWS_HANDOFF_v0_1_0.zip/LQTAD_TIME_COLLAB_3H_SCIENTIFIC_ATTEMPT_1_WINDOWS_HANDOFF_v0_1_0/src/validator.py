def validate_case_set(cs):
    errs=[]
    if cs.get("schema")!="LQTA-D-TIME-COLLAB-3H-CASE-SET-1": errs.append("schema")
    if cs.get("case_count")!=288 or len(cs.get("cases",[]))!=288: errs.append("count")
    ids=[c.get("case_id") for c in cs.get("cases",[])]
    if len(set(ids))!=len(ids): errs.append("duplicate_case_id")
    allowed={"SPARSE_BASE":64,"SHORTCUT_STRESS":64,"TOKEN_LOSS":64,"RICH_RULE":64,"POS_CHAIN_CONTROL":16,"NEG_DIRECT_BYPASS_CONTROL":16}
    got={k:0 for k in allowed}
    for c in cs.get("cases",[]):
        f=c.get("family")
        if f not in allowed: errs.append("family"); continue
        got[f]+=1
        n=c.get("n",0); edges=c.get("edges",[])
        if not (5<=n<=10): errs.append("n")
        if any(not (0<=a<b<n) for a,b in edges): errs.append("edge")
        out=[0]*n
        for a,b in edges: out[a]+=1
        lim=3 if f=="SHORTCUT_STRESS" else 2
        if f=="NEG_DIRECT_BYPASS_CONTROL": lim=max(lim,2)
        if max(out or [0])>lim: errs.append("fanout")
        if f=="RICH_RULE":
            t=c.get("rule_table",{})
            if set(t)!=set(str(i) for i in range(n)): errs.append("rule_table")
            for i in range(n):
                if len(t[str(i)])!=3: errs.append("rule_states")
                if any(s.get("emit_to") is not None and s.get("emit_to") not in [b for a,b in edges if a==i] for s in t[str(i)]): errs.append("bad_emit")
    if got!=allowed: errs.append("family_counts")
    return sorted(set(errs))
