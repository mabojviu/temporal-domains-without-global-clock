import hashlib, json, random

FAMILY_COUNTS={"SPARSE_BASE":64,"SHORTCUT_STRESS":64,"TOKEN_LOSS":64,"RICH_RULE":64,
               "POS_CHAIN_CONTROL":16,"NEG_DIRECT_BYPASS_CONTROL":16}

def h64(s):
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],"big")

def has_path(n,edges):
    adj={i:[] for i in range(n)}
    for a,b in edges: adj[a].append(b)
    st=[0]; seen=set()
    while st:
        u=st.pop()
        if u==n-1:return True
        if u in seen:continue
        seen.add(u); st.extend(v for v in adj[u] if v not in seen)
    return False

def sparse_graph(n,seed,max_out=2,no_direct=True):
    for attempt in range(10000):
        rng=random.Random(seed+attempt*1000003)
        poss=[(i,j) for i in range(n) for j in range(i+1,n) if not(no_direct and i==0 and j==n-1)]
        rng.shuffle(poss)
        out=[0]*n; edges=[]
        p=0.18+0.14*rng.random()
        for e in poss:
            if out[e[0]]<max_out and rng.random()<p:
                edges.append(e); out[e[0]]+=1
        if has_path(n,edges):
            return sorted(edges)
    # deterministic fallback, still within contract
    return [(i,i+1) for i in range(n-1)]

def add_shortcuts(n,base,seed):
    rng=random.Random(seed)
    edges=set(map(tuple,base)); out=[0]*n
    for a,b in edges: out[a]+=1
    poss=[(i,j) for i in range(n) for j in range(i+2,n) if (i,j) not in edges]
    rng.shuffle(poss)
    # Direct bypass is deliberately possible.
    if out[0]<3 and rng.random()<0.35:
        edges.add((0,n-1)); out[0]+=1
    added=0
    for a,b in poss:
        if added>=max(1,n//3): break
        if out[a]<3 and rng.random()<0.45:
            edges.add((a,b)); out[a]+=1; added+=1
    return sorted(edges)

def loss_graph(base,seed,p_loss):
    rng=random.Random(seed)
    return [e for e in base if rng.random()>=p_loss]

def rich_rule(n,edges,seed):
    rng=random.Random(seed)
    outs={i:[] for i in range(n)}
    for a,b in edges: outs[a].append(b)
    for i in outs: rng.shuffle(outs[i])
    # Each state is a full physically accessible local rule entry.
    table={}
    for i in range(n):
        ports=outs[i]
        states=[]
        states.append({"before":False,"emit_to":None})
        if not ports:
            states += [{"before":True,"emit_to":None},{"before":True,"emit_to":None}]
        elif len(ports)==1:
            states += [{"before":True,"emit_to":ports[0]},{"before":True,"emit_to":None}]
        else:
            states += [{"before":True,"emit_to":ports[0]},{"before":True,"emit_to":ports[1]}]
        # Permute state labels so label value has no semantic meaning.
        rng.shuffle(states)
        table[str(i)]=states
    return table

def make_case(family,index,nonce,freeze_root):
    material=f"{freeze_root}|{nonce}|{family}|{index}"
    seed=h64(material)
    if family in ("POS_CHAIN_CONTROL","NEG_DIRECT_BYPASS_CONTROL"):
        n=5+(seed%4)
    elif family=="RICH_RULE":
        n=6+(seed%3)
    else:
        n=7+(seed%4)
    base=sparse_graph(n,h64(material+"|base"),2,True)
    case={"schema":"LQTA-D-TIME-COLLAB-3H-CASE-1","family":family,"index":index,"n":n,
          "source":0,"sink":n-1,"freeze_root":freeze_root}
    if family=="SPARSE_BASE":
        case["edges"]=base
    elif family=="SHORTCUT_STRESS":
        case["base_edges"]=base
        case["edges"]=add_shortcuts(n,base,h64(material+"|shortcut"))
    elif family=="TOKEN_LOSS":
        p=[0.10,0.20,0.30][seed%3]
        case["base_edges"]=base; case["p_loss"]=p
        case["edges"]=loss_graph(base,h64(material+"|loss"),p)
    elif family=="RICH_RULE":
        case["edges"]=base
        case["rule_table"]=rich_rule(n,base,h64(material+"|rule"))
    elif family=="POS_CHAIN_CONTROL":
        case["edges"]=[(i,i+1) for i in range(n-1)]
    elif family=="NEG_DIRECT_BYPASS_CONTROL":
        case["edges"]=[(0,n-1)] + [(i,i+1) for i in range(1,n-2)]
    payload=json.dumps(case,sort_keys=True,separators=(",",":")).encode()
    case["case_id"]=hashlib.sha256(payload).hexdigest()
    return case

def materialize(nonce,freeze_root):
    cases=[]
    for fam,count in FAMILY_COUNTS.items():
        for i in range(count):
            cases.append(make_case(fam,i,nonce,freeze_root))
    return {"schema":"LQTA-D-TIME-COLLAB-3H-CASE-SET-1","freeze_root":freeze_root,
            "case_count":len(cases),"cases":cases}
