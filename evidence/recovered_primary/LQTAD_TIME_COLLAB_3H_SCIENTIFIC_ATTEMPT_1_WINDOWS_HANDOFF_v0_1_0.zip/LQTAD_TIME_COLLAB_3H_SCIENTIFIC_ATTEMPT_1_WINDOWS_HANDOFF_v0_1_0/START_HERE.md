# TIME-COLLAB-3H Scientific Attempt 1

Authorization: `LQTAD-TIME-COLLAB-3H-SCIENTIFIC-ATTEMPT1-8AFAB90FEDC58BCD`

Run once:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_scientific_attempt_1.ps1
```

Once `DURABLE_LEDGER\AUTHORIZATION_CLAIM.json` exists, the authorization is consumed and must not be rerun.

Expected return:
- `LQTAD_TIME_COLLAB_3H_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_1_0.zip`
- matching `.sha256`
