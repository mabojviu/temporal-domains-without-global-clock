The replay certifies deterministic regeneration of the accepted D1.6A computational object.
It does not extend the scientific scope beyond the declared finite abstract event families.
In particular, it does not prove D1.6B MCWF reconstruction of conflict precedence from
autonomous local clocks.
