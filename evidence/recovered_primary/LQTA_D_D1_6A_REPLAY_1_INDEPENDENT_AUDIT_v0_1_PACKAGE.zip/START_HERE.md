# D1.6A Replay 1 independent audit

**Decision:** `PASS_D16A_BYTE_IDENTICAL_REPLAY_ACCEPTED`

- Replay return SHA-256: `6513763470c6c99606729705e8333d3dac2faecb997b70b028fe3425aa8a9248`
- Sidecar and CRC: PASS
- Return manifest: 17/17 PASS
- Durable replay claim/completion: VALID
- Reference `RESULTS.json`: `dd27460bc95291949b91a2ab489b26ecd0884d935b8b7a68214c29aa809fe5ed`
- Regenerated `RESULTS.json`: `dd27460bc95291949b91a2ab489b26ecd0884d935b8b7a68214c29aa809fe5ed`
- Byte-identical equality: PASS
- Replay verdict: `PASS_BYTE_IDENTICAL_REPLAY`
