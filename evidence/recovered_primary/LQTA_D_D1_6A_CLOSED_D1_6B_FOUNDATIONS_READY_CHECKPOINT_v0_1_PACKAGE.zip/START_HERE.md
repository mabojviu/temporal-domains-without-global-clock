# D1.6A closed — D1.6B foundations ready

D1.6A is closed and qualified:

`PASS_D16A_COLLECTIVE_GLOBAL_TIME_REPRESENTATION_GAUGE_ON_DECLARED_FINITE_DOMAIN`

Exact results SHA-256:

`dd27460bc95291949b91a2ab489b26ecd0884d935b8b7a68214c29aa809fe5ed`

Byte-identical replay is accepted. D1.6B has not been opened and no external D1.6B
execution is authorized. D1.5 remains unchanged with its replay pending.
