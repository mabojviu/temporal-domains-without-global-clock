# Scientific result and scope

The campaign separates four levels:

1. **Instantaneous hazard:** support-local sufficiency passes, with maximum factorization
   error `5.5511151231257827e-17`.

2. **Intrinsic candidate clock:** ten correlated equal-fibre witnesses pass. Across the
   tested declared initial states, candidate-time separation ranges from
   `0.43826224296522209` to
   `13.887564085486723` while every declared proper
   support-containing regional view remains equal.

3. **Global arbitration:** four scheduler-fibre controls pass; remote threshold changes
   alter the global winner without changing the target regional view or target candidate.

4. **Continuation controls:** full-state phase quotient, positive-time exact restart,
   and marked-unravelling separation all pass.

The obstruction witnesses themselves are depth-zero admitted initial conditions. The
campaign does not yet establish that the same equal-fibre obstruction occurs along
positive-time descendants of one canonical initial state.
