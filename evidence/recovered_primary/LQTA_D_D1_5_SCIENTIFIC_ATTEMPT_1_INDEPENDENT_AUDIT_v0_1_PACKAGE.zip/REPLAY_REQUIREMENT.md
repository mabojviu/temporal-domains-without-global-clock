# Replay requirement

Reference `RESULTS.json` SHA-256:

`a862354d3961d70a0f75bb81f453622348a1409b673288eba9d2035d58cb6d0a`

The next external step must regenerate this file byte for byte from the exact executor,
case set and bound environment-independent inputs. Replay requires a separate one-shot
authorization and durable replay ledger.
