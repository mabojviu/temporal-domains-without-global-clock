# D1.5 Scientific Attempt 1 independent audit

**Decision:** `PASS_D15_SCIENTIFIC_ATTEMPT_1_ACCEPTED_REPLAY_REQUIRED`

The exact Windows return is authentic and internally consistent:

- 32/32 cases PASS;
- training 16/16 PASS;
- post-preflight holdout 16/16 PASS;
- D15SG00-D15SG13: 14/14 PASS;
- one-shot authorization durably claimed and completed;
- exact `RESULTS.json` SHA-256: `a862354d3961d70a0f75bb81f453622348a1409b673288eba9d2035d58cb6d0a`.

D1.5 remains uncertified pending byte-identical external replay and final master audit.
