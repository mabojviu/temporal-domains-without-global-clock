# TIME-COLLAB-3H Scientific Attempt 1 — Transport Repair v0.1.1

Authorization remains:
`LQTAD-TIME-COLLAB-3H-SCIENTIFIC-ATTEMPT1-8AFAB90FEDC58BCD` — `ISSUED_UNCLAIMED`

The v0.1.0 handoff stopped before claim because `EVIDENCE/ENVIRONMENT.json` was missing. This repair adds the exact external-preflight evidence only.

No frozen scientific file, CASE_SET, authorization, threshold, target, graph family, generator, evaluator, adjudicator, validator, or scientific runner has changed.

**Extract this repaired ZIP into a new clean folder. Do not rerun the old v0.1.0 directory.**

Run once:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_scientific_attempt_1.ps1
```

Once `DURABLE_LEDGER\AUTHORIZATION_CLAIM.json` appears, the authorization is consumed and must never be rerun.
