# Windows execution instructions

1. Extract this ZIP into a new short folder, preferably:

   `C:\LQTA\D15A1`

2. Open PowerShell in that folder.

3. Run exactly:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_scientific_attempt_1.ps1
```

The launcher first re-verifies hashes, importability, static preflight, readiness and
case-set schema. These checks occur before the one-shot claim.

Immediately before scientific invocation it writes the durable claim for:

`LQTAD-D15-SCIENTIFIC-ATTEMPT1-5F43CBD984F858CB`

Expected output files:

- `LQTAD_D15_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_2_0.zip`
- `LQTAD_D15_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_2_0.zip.sha256`

Upload both files, including a non-pass or diagnostic return. Do not rerun after a
durable claim exists.
