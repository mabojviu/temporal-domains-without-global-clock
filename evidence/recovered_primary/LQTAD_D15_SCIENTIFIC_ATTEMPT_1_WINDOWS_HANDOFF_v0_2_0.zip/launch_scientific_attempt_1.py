from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback
import venv
import zipfile

ROOT = Path(__file__).resolve().parent
AUTHORIZATION_ID = "LQTAD-D15-SCIENTIFIC-ATTEMPT1-5F43CBD984F858CB"
EXECUTOR_NAME = "LQTA_D_D1_5_REACHABLE_FIBRES_MINIMAL_SUFFICIENT_REGIONS_0_PRODUCTION_EXECUTOR_v0_2_0_METHOD_REPAIRED.zip"
EXECUTOR_ROOT_NAME = "LQTA_D_D1_5_REACHABLE_FIBRES_MINIMAL_SUFFICIENT_REGIONS_0_PRODUCTION_EXECUTOR_v0_2_0_METHOD_REPAIRED"
PREFLIGHT_NAME = "LQTAD_D15_WINDOWS_PREFLIGHT_RETURN_v0_2_0.zip"
RETURN_NAME = "LQTAD_D15_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_2_0.zip"

EXPECTED = {
    "AUTHORIZATION.json": "0ace931bb35b4c38a9876e7fec7afbe35e64b34ebf44bcf00f3b6490c7506d91",
    "CASE_SET.json": "e63554bd6fa5442d7b397f36e4c5c7a3558b73ad2598466858b28447217cdb1e",
    "CASE_SET_CUSTODY.json": "e7038397f4f38a8e5abff7f9c6be4f446fe26deb3074f44f5ef3488fa0ed100e",
    "LQTAD_D15_WINDOWS_PREFLIGHT_RETURN_v0_2_0.zip": "1b9e94655db948afc8e9d2542e0c713c41e35d72f9c231665e0f20801a43494a",
    "LQTA_D_D1_5_REACHABLE_FIBRES_MINIMAL_SUFFICIENT_REGIONS_0_PRODUCTION_EXECUTOR_v0_2_0_METHOD_REPAIRED.zip": "98f3d878d72e8fdd118352464494096abdf8fb57ef7f7567b19b53ae1f9153bc",
    "LQTA_D_D1_5_REACHABLE_FIBRES_MINIMAL_SUFFICIENT_REGIONS_CAMPAIGN_DESIGN_AND_READINESS_v0_2_0_PACKAGE.zip": "8cd81a21c5c39f2acba7ddaf2e6b0b15ff8bcc964c3e11971eeaff93d85910b8",
    "LQTA_D_D1_5_SCIENTIFIC_ATTEMPT_1_ONE_SHOT_AUTHORIZATION_v0_1_PACKAGE.zip": "78134cd512d1b96481f2586508343cd7773ca0c727a3b003fd46a248b68697ba",
    "LQTA_D_D1_5_SCIENTIFIC_CASE_SET_AND_POST_PREFLIGHT_HOLDOUT_FREEZE_v0_1_PACKAGE.zip": "292cbb2434a67acf4e13fd686bb11250ce551e2384df2652224f89e462ea5d69",
    "LQTA_D_D1_5_WINDOWS_PREFLIGHT_RETURN_v0_1_INDEPENDENT_AUDIT_AND_V0_2_0_METHOD_REPAIR_PACKAGE.zip": "fcf12480708537985024232332ba1e7f7806b60d0a1cc39410bee75931b745ca",
    "LQTA_D_D1_5_WINDOWS_PREFLIGHT_RETURN_v0_2_0_INDEPENDENT_AUDIT_v0_1_PACKAGE.zip": "cf9fb9cf3bf4f5d11d41735573a35f76c46c6c492c209ed57211f84f3bff344f"
}

WORK = ROOT / "WORK_D15_SCIENTIFIC_ATTEMPT_1"
STAGE = ROOT / "RETURN_STAGE_D15_SCIENTIFIC_ATTEMPT_1"
VENV = ROOT / "VENV_D15_SCIENTIFIC_ATTEMPT_1"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def canonical_digest(obj: dict) -> str:
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    ).hexdigest()

def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )

def ledger_root() -> Path:
    preferred = Path("C:/LQTA/D15_DURABLE_AUTHORIZATION_LEDGER")
    if Path("C:/LQTA").exists():
        return preferred
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        raise RuntimeError("No durable ledger root is available")
    return Path(local) / "LQTA" / "D15_DURABLE_AUTHORIZATION_LEDGER"

def venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

def run_logged(command: list[str], log_path: Path, env=None) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("wb") as log:
        cp = subprocess.run(
            command,
            cwd=ROOT,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )
    return int(cp.returncode)

def verify_inputs() -> None:
    failures = []
    for name, expected in EXPECTED.items():
        path = ROOT / name
        if not path.is_file():
            failures.append(f"missing: {name}")
            continue
        actual = sha256_file(path)
        if actual != expected:
            failures.append(f"sha256 mismatch: {name} actual={actual} expected={expected}")
    if failures:
        raise RuntimeError("; ".join(failures))

def create_claim(ledger: Path) -> Path:
    ledger.mkdir(parents=True, exist_ok=True)
    claim_path = ledger / f"{AUTHORIZATION_ID}.claimed.json"
    auth_hash = sha256_file(ROOT / "AUTHORIZATION.json")
    payload = {
        "schema": "LQTAD-D15-DURABLE-AUTHORIZATION-LEDGER-1",
        "authorization_id": AUTHORIZATION_ID,
        "status": "CLAIMED_AND_CONSUMED_BEFORE_SCIENTIFIC_INVOCATION",
        "authorization_sha256": auth_hash,
        "executor_sha256": sha256_file(ROOT / EXECUTOR_NAME),
        "case_set_sha256": sha256_file(ROOT / "CASE_SET.json"),
        "preflight_return_sha256": sha256_file(ROOT / PREFLIGHT_NAME),
    }
    payload["claim_digest"] = canonical_digest(payload)
    data = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd = os.open(str(claim_path), flags, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    return claim_path

def create_completion(
    ledger: Path,
    campaign_exit_code: int | None,
    verdict: str,
    result_path: Path | None,
    status: str,
) -> Path:
    completion = {
        "schema": "LQTAD-D15-DURABLE-AUTHORIZATION-LEDGER-1",
        "authorization_id": AUTHORIZATION_ID,
        "status": status,
        "campaign_exit_code": campaign_exit_code,
        "verdict": verdict,
        "result_sha256": sha256_file(result_path) if result_path and result_path.is_file() else None,
    }
    completion["completion_digest"] = canonical_digest(completion)
    path = ledger / f"{AUTHORIZATION_ID}.completed.json"
    path.write_text(
        json.dumps(completion, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return path

def copy_if_exists(source: Path, destination: Path) -> None:
    if not source.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        shutil.copytree(source, destination, dirs_exist_ok=True)
    else:
        shutil.copy2(source, destination)

def package_return() -> tuple[Path, str]:
    entries = []
    for p in sorted(STAGE.rglob("*")):
        if p.is_file() and p.name != "RETURN_MANIFEST.json":
            entries.append({
                "path": p.relative_to(STAGE).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    write_json(
        STAGE / "RETURN_MANIFEST.json",
        {"schema": "LQTAD-D15-SCIENTIFIC-RETURN-MANIFEST-1", "entries": entries},
    )

    out = ROOT / RETURN_NAME
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for p in sorted(STAGE.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(STAGE).as_posix())
    with zipfile.ZipFile(out) as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"return ZIP CRC failure: {bad}")
    digest = sha256_file(out)
    Path(str(out) + ".sha256").write_text(
        f"{digest}  {out.name}\n",
        encoding="ascii",
    )
    return out, digest

def main() -> int:
    ledger = ledger_root()
    ledger.mkdir(parents=True, exist_ok=True)
    claim_path = ledger / f"{AUTHORIZATION_ID}.claimed.json"
    completion_path = ledger / f"{AUTHORIZATION_ID}.completed.json"

    campaign_invoked = False
    campaign_exit_code = None
    wrapper_exit_code = 0
    classification = "UNSET"
    verdict = "NO_VERDICT"
    output = WORK / "SCIENTIFIC_OUTPUT"
    executor = None

    try:
        verify_inputs()
        auth = json.loads((ROOT / "AUTHORIZATION.json").read_text(encoding="utf-8"))
        if auth["authorization_id"] != AUTHORIZATION_ID:
            raise RuntimeError("authorization ID mismatch")
        if auth["status"] != "AUTHORIZED_ONE_SHOT":
            raise RuntimeError("authorization is not active")
        if auth["executor_sha256"] != sha256_file(ROOT / EXECUTOR_NAME):
            raise RuntimeError("authorization/executor mismatch")
        if auth["case_set_file_sha256"] != sha256_file(ROOT / "CASE_SET.json"):
            raise RuntimeError("authorization/case-set mismatch")
        if auth["accepted_preflight_return_sha256"] != sha256_file(ROOT / PREFLIGHT_NAME):
            raise RuntimeError("authorization/preflight mismatch")

        # Never invoke after a durable claim.
        if claim_path.is_file():
            classification = "RERUN_BLOCKED_EXISTING_DURABLE_CLAIM"
            wrapper_exit_code = 4
            return wrapper_exit_code

        if WORK.exists():
            shutil.rmtree(WORK)
        if STAGE.exists():
            shutil.rmtree(STAGE)
        WORK.mkdir(parents=True)
        STAGE.mkdir(parents=True)

        with zipfile.ZipFile(ROOT / EXECUTOR_NAME) as zf:
            bad = zf.testzip()
            if bad is not None:
                raise RuntimeError(f"executor CRC failure: {bad}")
            zf.extractall(WORK)

        executor = WORK / EXECUTOR_ROOT_NAME
        if not executor.is_dir():
            raise RuntimeError("canonical executor root missing")

        if not venv_python().is_file():
            venv.EnvBuilder(with_pip=True, clear=False).create(VENV)
        python = venv_python()
        if not python.is_file():
            raise RuntimeError("virtual-environment Python not found")

        pip_code = run_logged(
            [
                str(python),
                "-m",
                "pip",
                "install",
                "--disable-pip-version-check",
                "-r",
                str(executor / "requirements.txt"),
            ],
            STAGE / "PIP_INSTALL_LOG.txt",
        )
        if pip_code != 0:
            classification = "PRECLAIM_DEPENDENCY_INSTALL_FAILURE"
            wrapper_exit_code = 10
            return wrapper_exit_code

        env = os.environ.copy()
        env["PYTHONPATH"] = str(executor / "src")
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONUTF8"] = "1"

        import_code = run_logged(
            [
                str(python),
                "-B",
                "-c",
                "import lqtad_d15,lqtad_pa0; print(lqtad_d15.__version__)",
            ],
            STAGE / "IMPORT_SELF_CHECK_LOG.txt",
            env,
        )
        if import_code != 0:
            classification = "PRECLAIM_IMPORT_FAILURE"
            wrapper_exit_code = 11
            return wrapper_exit_code

        static_code = run_logged(
            [str(python), "-B", str(executor / "scripts" / "run_static_preflight.py")],
            STAGE / "STATIC_PREFLIGHT_LOG.txt",
            env,
        )
        if static_code != 0:
            classification = "PRECLAIM_STATIC_PREFLIGHT_FAILURE"
            wrapper_exit_code = 12
            return wrapper_exit_code

        readiness_code = run_logged(
            [str(python), "-B", str(executor / "scripts" / "run_readiness.py")],
            STAGE / "READINESS_RECHECK_LOG.txt",
            env,
        )
        if readiness_code != 0:
            classification = "PRECLAIM_READINESS_RECHECK_FAILURE"
            wrapper_exit_code = 13
            return wrapper_exit_code

        validation_code = run_logged(
            [
                str(python),
                "-B",
                "-c",
                (
                    "import json;"
                    "from pathlib import Path;"
                    "from lqtad_d15.campaign import validate_case_set;"
                    "p=Path(r'" + str(ROOT / "CASE_SET.json").replace("\\", "\\\\") + "');"
                    "x=validate_case_set(json.loads(p.read_text(encoding='utf-8')));"
                    "print(json.dumps(x,sort_keys=True))"
                ),
            ],
            STAGE / "CASE_SET_VALIDATION_LOG.txt",
            env,
        )
        if validation_code != 0:
            classification = "PRECLAIM_CASE_SET_VALIDATION_FAILURE"
            wrapper_exit_code = 14
            return wrapper_exit_code

        # This exclusive durable write is the authorization-consumption boundary.
        create_claim(ledger)

        output.mkdir(parents=True, exist_ok=True)
        campaign_invoked = True
        campaign_exit_code = run_logged(
            [
                str(python),
                "-B",
                str(executor / "scripts" / "run_campaign.py"),
                "--case-set",
                str(ROOT / "CASE_SET.json"),
                "--output-dir",
                str(output),
            ],
            STAGE / "SCIENTIFIC_EXECUTION_LOG.txt",
            env,
        )
        wrapper_exit_code = campaign_exit_code

        results_path = output / "RESULTS.json"
        verdict_path = output / "VERDICT.txt"
        if results_path.is_file() and verdict_path.is_file():
            verdict = verdict_path.read_text(encoding="utf-8").strip()
            completion_status = (
                "SCIENTIFIC_ATTEMPT_COMPLETED"
                if campaign_exit_code in (0, 2)
                else "SCIENTIFIC_ATTEMPT_COMPLETED_WITH_NONSTANDARD_EXIT"
            )
            create_completion(
                ledger,
                campaign_exit_code,
                verdict,
                results_path,
                completion_status,
            )
            classification = (
                "SCIENTIFIC_ATTEMPT_COMPLETED_ALLPASS"
                if campaign_exit_code == 0 and verdict == "PASS_ALL_DECLARED_GATES"
                else "SCIENTIFIC_ATTEMPT_COMPLETED_NONPASS"
            )
        else:
            verdict = "EXECUTION_ERROR_NO_CANONICAL_RESULT"
            create_completion(
                ledger,
                campaign_exit_code,
                verdict,
                None,
                "SCIENTIFIC_ATTEMPT_EXECUTION_ERROR",
            )
            classification = "SCIENTIFIC_ATTEMPT_RETURNED_WITHOUT_CANONICAL_PAYLOAD"
            if wrapper_exit_code == 0:
                wrapper_exit_code = 20

        run_logged(
            [str(python), "-B", str(executor / "scripts" / "capture_environment.py")],
            STAGE / "ENVIRONMENT.json",
            env,
        )
        return wrapper_exit_code

    except BaseException as exc:
        wrapper_exit_code = 90
        classification = "SCIENTIFIC_HANDOFF_WRAPPER_EXCEPTION"
        write_json(
            STAGE / "WRAPPER_FAILURE.json",
            {
                "schema": "LQTAD-D15-SCIENTIFIC-WRAPPER-FAILURE-1",
                "authorization_id": AUTHORIZATION_ID,
                "exception_type": type(exc).__name__,
                "message": str(exc),
                "traceback": traceback.format_exc(),
            },
        )
        if claim_path.is_file() and not completion_path.is_file():
            create_completion(
                ledger,
                campaign_exit_code,
                "WRAPPER_EXCEPTION_AFTER_CLAIM",
                None,
                "SCIENTIFIC_ATTEMPT_EXECUTION_ERROR",
            )
        return wrapper_exit_code

    finally:
        STAGE.mkdir(parents=True, exist_ok=True)

        copy_if_exists(output, STAGE / "SCIENTIFIC_OUTPUT")
        copy_if_exists(claim_path, STAGE / "AUTHORIZATION_LEDGER" / claim_path.name)
        copy_if_exists(completion_path, STAGE / "AUTHORIZATION_LEDGER" / completion_path.name)

        for name in [
            "AUTHORIZATION.json",
            "CASE_SET.json",
            "CASE_SET_CUSTODY.json",
            "INPUT_HASHES.json",
        ]:
            copy_if_exists(ROOT / name, STAGE / "HANDOFF_INPUTS" / name)

        write_json(
            STAGE / "RETURN_STATUS.json",
            {
                "schema": "LQTAD-D15-WINDOWS-SCIENTIFIC-RETURN-1",
                "authorization_id": AUTHORIZATION_ID,
                "classification": classification,
                "campaign_invoked": campaign_invoked,
                "campaign_exit_code": campaign_exit_code,
                "wrapper_exit_code": wrapper_exit_code,
                "claim_present": claim_path.is_file(),
                "completion_present": completion_path.is_file(),
                "results_present": (output / "RESULTS.json").is_file(),
                "verdict_present": (output / "VERDICT.txt").is_file(),
                "verdict": verdict,
            },
        )

        try:
            out, digest = package_return()
            print("D1.5 scientific return created:")
            print(out)
            print(digest)
            print(classification)
            print(f"Claim present: {claim_path.is_file()}")
            print(f"Completion present: {completion_path.is_file()}")
        except BaseException:
            traceback.print_exc()

if __name__ == "__main__":
    raise SystemExit(main())
