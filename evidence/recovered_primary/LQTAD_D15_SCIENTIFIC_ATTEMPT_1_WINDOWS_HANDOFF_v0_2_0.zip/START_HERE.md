# D1.5 Scientific Attempt 1 Windows handoff

Authorization ID:

`LQTAD-D15-SCIENTIFIC-ATTEMPT1-5F43CBD984F858CB`

This package is the external scientific-execution boundary. It contains the exact
v0.2.0 repaired executor, accepted Windows preflight, independent preflight audit,
frozen 32-case set, post-preflight holdout custody, and one-shot authorization.

Use only `run_scientific_attempt_1.ps1`.
