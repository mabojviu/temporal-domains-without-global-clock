# Scientific scope

The campaign evaluates:

- support sufficiency for instantaneous jump hazards;
- candidate-clock obstructions on equal accessible fibres;
- all proper support-containing spatial regions in the declared finite lattices;
- product controls;
- global scheduler-access obstructions;
- full-region global-phase quotient controls;
- positive-time prefix restart;
- ensemble-equivalent but marked-distinct unravellings.

Full-region minimality is only within the declared spatial subset lattice. The campaign
does not establish universal nonlocalizability, signalling, autonomous regional MCWF
dynamics or minimality against arbitrary nonlinear compressions.
