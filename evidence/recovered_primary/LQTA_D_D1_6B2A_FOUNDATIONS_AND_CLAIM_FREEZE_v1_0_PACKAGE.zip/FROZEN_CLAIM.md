# D1.6B-2A frozen claim

> On a declared finite pure-state marked-MCWF domain with a certified operational partition coarser than the unique finest exact state-generator-marked-unravelling partition, each disjoint operational domain supports a runtime-autonomous exact competing-risk clock despite arbitrary finite pure-state entanglement inside that domain. Within each connected calibrated relation component, those clocks reproduce the bound finite marked-event process, including keyed budgets, finite-horizon censoring, and tie resolution. Across unrelated components they reconstruct the same event-poset/serialization-gauge class, not a physically privileged total order. Proper subdomains can be obstructed by equal-fibre continuation witnesses.

This claim excludes autonomous domain-boundary discovery, mixed
conditioned states, approximation, generic many-body locality,
unravelling independence, continuum limits, relativity, gravity, and
unrestricted universal time emergence.
