# LQTA-D D1.6B-2A Foundations v0.2.1

## Consolidated normative object

**Status:** `TARGETED_COMPLETION_COMPLETE_FINAL_AUDIT_PENDING`

The v0.2.0 text below remains normative except where superseded by the v0.2.1 amendment appended after it.

---

# LQTA-D D1.6B-2A

## Exact Correlated-Domain Clocks and Collective Chronology

**Foundations v0.2.0 — Revised after individual and joint gate audit**

**Status:** `REVISED_FOUNDATIONS_COMPLETE_REAUDIT_REQUIRED_CLAIM_FREEZE_NOT_ACTIVATED`

---

## 0. Purpose, governance, and non-retroactivity

D1.6B-2A studies the first exact positive domain in which an operational
trajectory clock is attached not to an elementary line, but to a finite
correlated quantum domain whose conditioned pure branch may be internally
entangled.

The phase question is

\[
\boxed{
\text{Can exact temporal autonomy survive when the runtime-local object is
a correlated quantum domain rather than a primitive line?}
}
\]

This revision incorporates all mandatory repairs R01–R10 identified by
the joint mathematical and adversarial audit, and adds review gates
G2A-11 and G2A-12.

This document does not alter D1.5, D1.6A, D1.6B-0, D1.6B-1, CERT-009,
the active MCWF successor, or the submitted article. It creates no
executor, freezes no scientific case set, and authorizes no external
execution.

Claim freeze remains inactive until v0.2.0 passes a new independent and
joint audit.

---

## 1. Upstream scientific position

D1.6B-0 qualified, on its declared finite factor-component domain,

\[
\{\text{autonomous factor clocks}\}
+
\{\text{consistent relational calibrations}\}
\Longrightarrow
\text{a reconstructed collective MCWF chronology}.
\]

D1.6B-1 then qualified, on its declared finite piecewise-factorized
domain,

\[
\{\text{certified local interaction events}\}
\Longrightarrow
\{\mathcal R_{jk}(C)\}
\Longrightarrow
\{\mathcal D(C)\}
\Longrightarrow
\text{a dynamically reconfigured collective chronology}.
\]

D1.6B-1 also isolated the next obstruction: after an interaction is
removed, the conditioned branch may remain entangled across the proposed
cut. In that case, exact primitive-line clocks need not exist.

D1.6B-2A therefore tests whether exact temporal locality can be retained
by replacing elementary lines with disjoint correlated operational
domains.

The intended hierarchy is

\[
\Pi_{\mathrm{corr}}(\Psi)
\longrightarrow
\mathsf G_{\mathrm{temp}}
\longrightarrow
\mathcal D_{\min}
\longrightarrow
\mathcal D_{\mathrm{op}}
\longrightarrow
\{\Theta_D\}_{D\in\mathcal D_{\mathrm{op}}}
\longrightarrow
[T].
\]

Here:

- \(\mathcal D_{\min}\) is a mathematical finest exact partition;
- \(\mathcal D_{\mathrm{op}}\) is the certified active clock partition;
- \(\mathcal D_{\mathrm{op}}\) may be a coarsening of
  \(\mathcal D_{\min}\);
- active clocks never overlap.

---

## 2. Fixed mathematical setting

### 2.1 Primitive tensor factorization

Let \(J\) be a finite set of primitive factors and

\[
\mathcal H
=
\bigotimes_{j\in J}\mathcal H_j,
\qquad
2\le \dim\mathcal H_j<\infty.
\]

The primitive tensor factorization is declared model data. D1.6B-2A
does not derive it.

For \(S\subseteq J\),

\[
\mathcal H_S
=
\bigotimes_{j\in S}\mathcal H_j,
\qquad
\bar S=J\setminus S.
\]

### 2.2 Fixed pure-state marked MCWF representation

At context \(C\), the conditioned branch is a unit vector

\[
|\Psi_C\rangle\in\mathcal H.
\]

The active marked MCWF representation is

\[
H_{\mathrm{eff}}(C)
=
H(C)
-
\frac{i}{2}
\sum_{\mu\in\mathsf M(C)}
L_\mu(C)^\dagger L_\mu(C)
\]

with fixed marked catalogue

\[
\mathcal L(C)
=
\{(\mu,L_\mu(C)):\mu\in\mathsf M(C)\}.
\]

All domain, support, event, and clock claims are relative to this declared
marked unraveling.

### 2.3 Marked-unravelling equivalence contract

For theorem-level covariance only, the following representation changes
are admissible when labels, keys, counters, budgets, and operator digests
are transported consistently:

1. a bijective channel relabelling;
2. an independent constant phase
   \(L_\mu\mapsto e^{i\varphi_\mu}L_\mu\), with post-jump states compared
   as canonically normalized rays.

The following transformations are phase-changing and are excluded:

1. non-diagonal unitary mixing of marked channels;
2. affine displacement
   \(L_\mu\mapsto L_\mu+\alpha_\mu I\), even with Hamiltonian
   compensation;
3. marked-channel splitting or merging;
4. state-dependent or context-dependent mixing;
5. any transformation changing keyed channel identity.

A scientific executor must bind exact channel labels, matrices, keys, and
digests. It may not invoke even the admissible covariance transformations
during a frozen run.

### 2.4 Piecewise-fixed context

All exact theorems apply on intervals where the following remain fixed:

- primitive tensor factorization;
- marked jump catalogue;
- effective-generator support sectors;
- certified operational partition;
- domain ownership map;
- relation-network version.

Any change creates a new context and invalidates all affected boundary
and candidate certificates.

---

## 3. Basis-independent operator support

### Definition 3.1 — Local identity and traceless subspaces

For each primitive factor,

\[
\mathcal B(\mathcal H_j)
=
\operatorname{span}\{I_j\}
\oplus
\mathfrak t_j,
\]

where \(\mathfrak t_j\) is the Hilbert–Schmidt orthogonal complement of
the identity.

### Definition 3.2 — Support sectors

For \(S\subseteq J\), define

\[
\mathcal V_S
=
\bigotimes_{j\in S}\mathfrak t_j
\otimes
\bigotimes_{j\notin S}\operatorname{span}\{I_j\}.
\]

Then

\[
\mathcal B(\mathcal H)
=
\bigoplus_{S\subseteq J}\mathcal V_S.
\]

Let \(P_S\) be the unique sector projection.

### Definition 3.3 — Sector support and canonical support

For \(A\in\mathcal B(\mathcal H)\),

\[
\operatorname{SecSupp}(A)
=
\{S\subseteq J:P_S(A)\ne0\}.
\]

Its canonical support is

\[
\operatorname{Supp}(A)
=
\bigcup_{S\in\operatorname{SecSupp}(A)}S.
\]

Equivalently, \(\operatorname{Supp}(A)\) is the smallest \(S\) such that

\[
A=A_S\otimes I_{\bar S}.
\]

Permitted changes of local traceless Hilbert–Schmidt bases preserve each
subspace \(\mathcal V_S\). Therefore
\(\operatorname{SecSupp}(A)\) and \(\operatorname{Supp}(A)\) are
basis independent.

### Definition 3.4 — Scalar identity sector

The empty sector of the effective generator is

\[
P_\varnothing(H_{\mathrm{eff}})
=
\zeta(C)I.
\]

It creates no hyperedge and no domain connection.

For exact unnormalized propagation it is assigned to the operational
domain containing the fixed primitive anchor

\[
j_\star=\min J.
\]

This deterministic convention includes the scalar exactly once. It does
not change normalized branch rays, marked hazards, candidate comparisons,
or event selection. The anchor rule remains fixed across merges and
splits: the current domain containing \(j_\star\) owns the scalar sector.

---

## 4. Exact correlation and minimal temporal partition

### Definition 4.1 — Product partition

A partition \(\Pi\) of \(J\) is a product partition of a nonzero pure
vector \(|\Psi\rangle\) when

\[
|\Psi\rangle
=
\bigotimes_{B\in\Pi}|\psi_B\rangle.
\]

### Theorem 4.2 — Unique finest correlation partition

Every nonzero pure vector

\[
|\Psi\rangle
\in
\bigotimes_{j\in J}\mathcal H_j
\]

has a unique finest product partition, denoted

\[
\Pi_{\mathrm{corr}}(\Psi).
\]

#### Proof

The one-block partition is a product partition, so the family of product
partitions is nonempty.

Let \(\Pi\) and \(\Sigma\) be product partitions. Fix \(A\in\Pi\).
Because \(|\Psi\rangle\) factorizes across \(\Pi\), the reduced state
\(\rho_A\) is pure. Because the same global state factorizes across
\(\Sigma\),

\[
\rho_A
=
\bigotimes_{\substack{B\in\Sigma\\A\cap B\ne\varnothing}}
\rho_{A\cap B}.
\]

A tensor product of density operators is pure only if every nontrivial
factor is pure. Hence the pure state on \(A\) factorizes across all
nonempty intersections \(A\cap B\), \(B\in\Sigma\).

Repeating this for every \(A\in\Pi\) proves that \(|\Psi\rangle\)
factorizes across the common refinement

\[
\Pi\wedge\Sigma
=
\{A\cap B:
A\in\Pi,\ B\in\Sigma,\ A\cap B\ne\varnothing\}.
\]

The partition lattice of finite \(J\) is finite. The meet of all product
partitions is therefore itself a product partition, refines every other
product partition, and is unique. ∎

### Definition 4.3 — Generator and jump hyperedges

The non-scalar generator hyperedges are

\[
\mathsf E_{\mathrm{eff}}(C)
=
\left\{
S\ne\varnothing:
P_S(H_{\mathrm{eff}}(C))\ne0
\right\}.
\]

The marked-jump hyperedges are

\[
\mathsf E_{\mathrm{jump}}(C)
=
\left\{
\operatorname{Supp}(L_\mu(C)):
\mu\in\mathsf M(C)
\right\}.
\]

Singleton hyperedges are retained for provenance but do not connect
different primitive factors.

### Definition 4.4 — Exact temporal hypergraph

The exact temporal hypergraph is

\[
\mathsf G_{\mathrm{temp}}(C,\Psi)
=
\left(
J,\,
\mathsf E_{\mathrm{eff}}(C)
\cup
\mathsf E_{\mathrm{jump}}(C)
\cup
\Pi_{\mathrm{corr}}(\Psi)
\right).
\]

### Definition 4.5 — Minimal exact temporal partition

The unique finest exact temporal partition is

\[
\mathcal D_{\min}(C,\Psi)
=
\pi_0\!\left(
\mathsf G_{\mathrm{temp}}(C,\Psi)
\right).
\]

For \(S\subseteq J\),

\[
\operatorname{cl}_{\min}^{\mathrm{temp}}(S)
=
\bigcup
\left\{
D\in\mathcal D_{\min}:
D\cap S\ne\varnothing
\right\}.
\]

This construction is state-, generator-, and marked-unravelling-relative.
It is a mathematical boundary certificate, not an autonomous local
discovery algorithm.

### Theorem 4.6 — Finest exact-partition theorem

Let

\[
\mathcal D_{\min}
=
\mathcal D_{\min}(C,\Psi).
\]

Then:

\[
|\Psi\rangle
=
\bigotimes_{D\in\mathcal D_{\min}}
|\psi_D\rangle;
\]

\[
H_{\mathrm{eff}}
=
\zeta I
+
\sum_{D\in\mathcal D_{\min}}
H_{\mathrm{eff},D}\otimes I_{\bar D};
\]

and every marked jump has a unique containing block,

\[
L_\mu
=
L_{\mu,D(\mu)}
\otimes
I_{\overline{D(\mu)}}.
\]

Moreover, \(\mathcal D_{\min}\) is the unique finest partition with all
three properties.

#### Proof

Every block of \(\Pi_{\mathrm{corr}}(\Psi)\) is a hyperedge and therefore
lies inside one connected component. Regrouping those product factors
gives the branch factorization.

Every nonempty support sector of \(H_{\mathrm{eff}}\) lies inside one
connected component. Grouping sector projections by component gives the
additive decomposition. The empty sector is the separately treated scalar
\(\zeta I\).

Every marked-jump support is a hyperedge, hence lies inside one connected
component.

Conversely, any partition satisfying the three properties must contain
inside one block every exact correlation block, every nonzero
non-scalar generator support sector, and every marked-jump support.
It is therefore a coarsening of the connected-component partition.
Thus \(\mathcal D_{\min}\) is unique and finest. ∎

---

## 5. Operational clock partition and exclusive ownership

### Definition 5.1 — Certified operational partition

A certified operational partition

\[
\mathcal D_{\mathrm{op}}(C)
\]

is any partition satisfying

\[
\mathcal D_{\mathrm{op}}(C)
\succeq
\mathcal D_{\min}(C,\Psi_C),
\]

where \(\succeq\) denotes “is a coarsening of.”

The operational partition is the partition actually carrying active
clocks. It does not silently refine when a finer mathematical
factorization appears.

### Definition 5.2 — Exclusive clock ownership

At every fixed context:

\[
D,E\in\mathcal D_{\mathrm{op}},
\qquad
D\cap E\ne\varnothing
\Longrightarrow
D=E.
\]

Every primitive factor, marked channel, channel key, residual budget,
counter, dependency version, and candidate certificate has exactly one
operational owner.

Overlapping state, generator, jump, or dependency supports induce domain
fusion. They never create overlapping autonomous clocks.

### Definition 5.3 — Ownership maps

The certified boundary record contains total maps

\[
\omega_J:J\to\mathcal D_{\mathrm{op}},
\]

\[
\omega_{\mathsf M}:\mathsf M\to\mathcal D_{\mathrm{op}},
\]

\[
\omega_K:\mathsf K\to\mathcal D_{\mathrm{op}},
\]

where \(\mathsf K\) is the set of keyed stochastic resources. These maps
are single-valued and mutually consistent with the declared supports.

### Definition 5.4 — Operational lifecycle

A merge is a certified union operation:

\[
D_1,\ldots,D_r
\longrightarrow
D_1\cup\cdots\cup D_r.
\]

A split is permitted only when:

1. a new boundary certificate exhibits a finer
   \(\mathcal D_{\min}\);
2. the effective generator and marked catalogue are contained in the
   proposed child domains;
3. the conditioned branch factorizes across the proposed cut;
4. no active physical or temporal relation crosses the cut;
5. keyed resources and counters admit a unique nonduplicating partition;
6. archived relational provenance supports the new clock charts;
7. the D1.6B-1 admissible-split protocol succeeds.

A finer mathematical factorization alone does not trigger a split.

### Gate G2A-11 — Exclusive ownership and lifecycle

Before claim freeze, an independent audit must verify:

- disjoint active domains;
- single ownership of factors, channels, keys, budgets, and counters;
- merge-as-union semantics;
- certified, nonimplicit split semantics;
- transactional rollback of failed lifecycle transitions.

---

## 6. Certified boundary versus local runtime

### Definition 6.1 — Boundary certificate

A boundary certificate is

\[
\beta_C
=
\left(
\Pi_{\mathrm{corr}},
\operatorname{SecSupp}(H_{\mathrm{eff}}),
\{\operatorname{Supp}(L_\mu)\}_\mu,
\mathcal D_{\min},
\mathcal D_{\mathrm{op}},
\omega_J,
\omega_{\mathsf M},
\omega_K,
\nu_\beta,
d_\beta
\right).
\]

Its construction may use the full conditioned branch and the full
declared generator. D1.6B-2A does not claim that this certificate can be
discovered from strictly local runtime data.

### Definition 6.2 — Certified domain initialization

For every \(D\in\mathcal D_{\mathrm{op}}\), certified initialization
delivers only:

\[
\Theta_D(0)
=
\left(
|\psi_D\rangle,
s_D,
\mathbf R_D,
\mathbf c_D,
\nu_D,
H_{\mathrm{eff},D},
\mathcal L_D,
\mathcal R_D,
d_D
\right).
\]

It does not deliver:

- the global branch;
- remote domain states;
- remote thresholds or counters;
- a primitive global timestamp;
- a global candidate vector.

The future executor must verify that no such forbidden object is retained
inside a domain runtime state.

### Definition 6.3 — Runtime-autonomous exact domain clock

After certified initialization, a domain clock is runtime-autonomous on a
declared finite horizon when \(\Theta_D\) determines:

1. its normalized and unnormalized no-jump branch segments;
2. every marked hazard and candidate owned by \(D\);
3. every selected post-jump state and keyed update in \(D\);
4. every dependency-version and certificate invalidation in \(D\);

without runtime access to remote domain states, resources, or a primitive
global scalar time.

Autonomous discovery of \(\beta_C\) is excluded and reserved for
D1.6B-2B or a separately named precursor layer.

---

## 7. Exact keyed competing-risk contract

### Definition 7.1 — Keyed exponential oracle

Every marked channel \(\mu\) has a unique immutable key \(k_\mu\) and
counter \(c_\mu\).

The bound successor supplies a deterministic keyed oracle

\[
\mathfrak E(k_\mu,c_\mu)
\in(0,\infty)
\]

whose outputs realize the frozen independent
\(\operatorname{Exp}(1)\) budgets.

At initialization,

\[
R_\mu
=
\mathfrak E(k_\mu,c_\mu).
\]

No domain may derive \(R_\mu\) from a global state, global clock, or
remote stochastic resource.

### Definition 7.2 — Hazard consumption

For a no-jump advance of physical duration \(\Delta s_D\),

\[
R_\mu
\longmapsto
R_\mu
-
\int_{0}^{\Delta s_D}
\lambda_{\mu,D}(u)\,du.
\]

The next candidate is the first \(\tau_{\mu,D}\ge0\) satisfying

\[
\int_0^{\tau_{\mu,D}}
\lambda_{\mu,D}(u)\,du
=
R_\mu.
\]

### Definition 7.3 — Event update

When channel \(\mu_\star\) is selected:

1. every channel budget is reduced by its integrated hazard to the event;
2. the domain state undergoes the marked jump and normalization;
3. \(c_{\mu_\star}\leftarrow c_{\mu_\star}+1\);
4. \(R_{\mu_\star}\leftarrow
   \mathfrak E(k_{\mu_\star},c_{\mu_\star})\);
5. every nonselected channel retains its remaining budget;
6. all candidates affected by the new state or generator version are
   recomputed from their retained budgets.

A remote event advances an independent domain along its no-jump flow and
consumes its hazards over the corresponding relationally calibrated
duration. If the remote event does not change its state, generator,
catalogue, or dependency version, its physical absolute candidate is
preserved.

### Definition 7.4 — Physical parameter and chart

Hazard integration uses the physical domain parameter \(s_D\).

A displayed or relational clock chart is

\[
\vartheta_D(s_D)
=
a_Ds_D+b_D,
\qquad
a_D>0.
\]

Changing \(\vartheta_D\) changes representation, not the physical hazard
integral or keyed resource state.

---

## 8. Correlated-domain flow, hazards, and certificates

### Definition 8.1 — Domain-local generator

For \(D\in\mathcal D_{\mathrm{op}}\), let
\(H_{\mathrm{eff},D}\) be the sum of all non-scalar support sectors
contained in \(D\), plus \(\zeta I_D\) only when \(D\) owns the anchor
\(j_\star\).

### Definition 8.2 — Domain-local no-jump flow

\[
|\widetilde\psi_D(s)\rangle
=
e^{-iH_{\mathrm{eff},D}s}
|\psi_D(0)\rangle.
\]

Whenever the vector is nonzero,

\[
|\psi_D(s)\rangle
=
\frac{|\widetilde\psi_D(s)\rangle}
{\|\,|\widetilde\psi_D(s)\rangle\,\|}.
\]

### Definition 8.3 — Domain hazard and candidate

For \(\mu\) owned by \(D\),

\[
\lambda_{\mu,D}(s)
=
\langle\psi_D(s)|
L_{\mu,D}^\dagger L_{\mu,D}
|\psi_D(s)\rangle,
\]

\[
A_{\mu,D}(s)
=
\int_0^s\lambda_{\mu,D}(u)\,du,
\]

\[
\tau_{\mu,D}
=
\inf\{s\ge0:A_{\mu,D}(s)\ge R_\mu\}.
\]

### Definition 8.4 — Domain candidate certificate

\[
\chi_{\mu,D}
=
\left(
D,\mu,\tau_{\mu,D},
R_\mu,c_\mu,\nu_D,d_D,d_\beta
\right).
\]

The boundary digest \(d_\beta\) prevents use of a candidate after the
certified domain partition has changed.

---

## 9. Exact theorem program

### Theorem 9.1 — Operational product and generator decomposition

Let \(\mathcal D_{\mathrm{op}}\succeq\mathcal D_{\min}\). Then

\[
|\Psi\rangle
=
\bigotimes_{D\in\mathcal D_{\mathrm{op}}}
|\psi_D\rangle,
\]

\[
H_{\mathrm{eff}}
=
\sum_{D\in\mathcal D_{\mathrm{op}}}
H_{\mathrm{eff},D}\otimes I_{\bar D},
\]

with the scalar sector included exactly once by the anchor convention,
and every marked channel is contained in exactly one operational domain.

#### Proof

Each operational block is a union of minimal exact blocks. Regrouping
the factors and local generator terms of Theorem 4.6 yields the first two
statements. Single-valued ownership maps give unique marked-channel
containment. ∎

### Theorem 9.2 — Preservation between certified boundary updates

Assume the operational partition, generator, marked catalogue, and
ownership maps remain fixed on a branch interval.

Then

\[
e^{-iH_{\mathrm{eff}}s}
=
\bigotimes_{D\in\mathcal D_{\mathrm{op}}}
e^{-iH_{\mathrm{eff},D}s}.
\]

Whenever every no-jump factor is nonzero, normalized no-jump evolution
preserves the operational product structure.

A marked jump with strictly positive selected hazard changes only its
owning domain and leaves every remote normalized domain state unchanged.

#### Proof

Operators on disjoint operational domains commute, and the scalar sector
is included once. Hence the exponential factorizes.

The norm of a tensor product is the product of the norms, so normalization
factorizes whenever no factor vanishes.

A selected channel has positive hazard, hence its jump vector is nonzero.
Its marked operator acts as the identity on all remote domains. Global
normalization therefore reduces to normalization of the selected domain
factor, while every remote normalized factor remains unchanged. ∎

### Theorem 9.3 — Exact domain-hazard and candidate sufficiency

For every channel \(\mu\) owned by \(D\),

\[
\lambda_\mu(\Psi)
=
\lambda_{\mu,D}(\psi_D).
\]

The finite candidate process owned by \(D\) is determined by

\[
\left(
|\psi_D\rangle,
H_{\mathrm{eff},D},
\mathcal L_D,
\mathbf R_D,
\mathbf c_D,
\nu_D
\right)
\]

and is independent of all remote runtime states and stochastic resources.

#### Proof

The branch and marked operator factorize across
\(D|\bar D\), so the remote unit norm cancels from the expectation.
Theorem 9.2 makes the future no-jump branch domain-local. Definitions
7.1–7.3 make every budget, candidate, and keyed update uniquely owned by
the domain. ∎

### Theorem 9.4 — Exact reconstruction from correlated-domain clocks

Assume:

1. a valid boundary certificate \(\beta_C\);
2. a disjoint operational partition
   \(\mathcal D_{\mathrm{op}}\succeq\mathcal D_{\min}\);
3. certified initialization with no forbidden global runtime object;
4. exact keyed-resource semantics;
5. consistent positive-affine relations between the relevant domain
   charts;
6. D1.6B-1-compliant merge, invalidation, and split transitions.

Then, on the declared finite horizon, the domain-clock engine reproduces
the bound global marked MCWF reference in:

- selected marked channel;
- conditioned branch ray;
- keyed budgets and counters;
- domain versions and valid certificates;
- marked-event order inside each connected relation component;
- the same event-poset/serialization-gauge class across mutually
  unrelated components.

No domain hazard evaluator, candidate generator, or local post-jump update
requires a primitive global scalar time.

#### Proof

By Theorem 9.3, the union of all domain candidate sets equals the global
candidate set. D1.6B-0 reconstruction applies after treating the disjoint
operational domains as super-factors. D1.6B-1 supplies the exact
relation-update, merge, invalidation, and split semantics.

Within each connected relation component, consistent chart transitions
select the same marked candidate. Across unrelated components, only the
already qualified event-poset quotient is physical. Theorem 9.2 and the
keyed update contract preserve the state and stochastic resources.
Induction over the finite event horizon proves the claim. ∎

### Theorem 9.5 — Clock-gauge invariance

Independent positive-affine chart changes

\[
g_D(s)=a_Ds+b_D,
\qquad
a_D>0,
\]

act on relations by

\[
\phi_{D\to E}
\longmapsto
g_E\circ\phi_{D\to E}\circ g_D^{-1}.
\]

They leave physical hazard integrals, selected marked events, conditioned
branch rays, keyed resources, and the event-poset quotient invariant.

#### Proof

Hazards use \(s_D\), not the chart coordinate. The conjugated relation
network preserves all physical candidate comparisons. The remaining
objects are independent of chart representation. ∎

### Theorem 9.6 — Admissible operational coarsening invariance

Let \(\mathcal D_{\mathrm{op}}'\) be a coarsening of
\(\mathcal D_{\mathrm{op}}\). If all channel identities, keys, budgets,
counters, internal relation records, and ownership provenance are
preserved without duplication, then replacing
\(\mathcal D_{\mathrm{op}}\) by \(\mathcal D_{\mathrm{op}}'\) leaves the
marked trajectory and event-poset quotient unchanged.

#### Proof

The coarsened generator is the sum of commuting child-domain generators,
the marked catalogue is their disjoint union, and keyed resources are
unchanged. Therefore the physical candidate set and all selected updates
are identical. The coarsening changes audit representation, not
trajectory content. ∎

### Theorem 9.7 — Proper-subdomain equal-fibre obstruction

Let \(S\subsetneq D\) and let \(\pi_S\) contain every datum allowed to a
proposed \(S\)-clock.

If two admissible domain records \(x_D,y_D\) satisfy

\[
\pi_S(x_D)=\pi_S(y_D)
\]

but their exact continuation kernels differ,

\[
K_D(\cdot|x_D)
\ne
K_D(\cdot|y_D),
\]

then no clock measurable only from \(\pi_S\) can be exact on both records.

#### Proof

An \(S\)-clock receives identical input on the two records and must
produce the same continuation prediction. Since the exact kernels differ,
at least one prediction is wrong. ∎

---

## 10. Correlation-specific continuation obstruction

### Corollary 10.1 — Nonlocal-channel control

For

\[
|\Phi^\pm\rangle
=
\frac{|00\rangle\pm|11\rangle}{\sqrt2}
\]

and

\[
L
=
\sqrt{\gamma}
|\Phi^+\rangle\langle\Phi^+|,
\]

the one-factor reduced states coincide, while

\[
\lambda_L(\Phi^+)=\gamma,
\qquad
\lambda_L(\Phi^-)=0.
\]

This is a valid proper-subdomain obstruction control, but the channel
itself is nonlocal.

### Corollary 10.2 — Local-channel steering witness

Let

\[
|\Phi^\pm\rangle
=
\frac{|00\rangle\pm|11\rangle}{\sqrt2},
\]

\[
L_A
=
\sqrt{\gamma}
|+\rangle\langle+|_A\otimes I_B,
\]

\[
L_B
=
\sqrt{\kappa}
I_A\otimes|+\rangle\langle+|_B.
\]

Choose identical local records for the proposed primitive clocks,
including reduced states, keyed budgets, counters, versions, and allowed
local histories.

Before any jump,

\[
\rho_A^\pm=\rho_B^\pm=\frac{I}{2},
\]

and the \(A\)-channel hazard is

\[
\lambda_A(\Phi^\pm)=\frac{\gamma}{2}.
\]

Conditioned on the \(A\)-jump,

\[
|\Phi^+\rangle
\longmapsto
|+\rangle_A|+\rangle_B,
\]

\[
|\Phi^-\rangle
\longmapsto
|+\rangle_A|-\rangle_B.
\]

The subsequent \(B\)-channel hazards are

\[
\lambda_B^{(+)}=\kappa,
\qquad
\lambda_B^{(-)}=0.
\]

Hence the same primitive \(B\)-local pre-jump record leads to different
exact continuation kernels. The missing datum is the cross-domain
correlation phase. An architecture that transmits this phase as a
mandatory dependency message has enlarged the permitted clock record and
must represent that dependency in the correlated operational domain.

Therefore exact independent primitive clocks are obstructed on this
class, while an \(AB\)-domain clock is sufficient.

### Gate G2A-12 — Correlation-specific obstruction

Before claim freeze, an independent audit must verify:

- equality of every permitted primitive local record;
- equality of the initial \(A\)-hazard;
- the two normalized post-\(A\)-jump states;
- the \(\kappa\) versus \(0\) future \(B\)-hazard;
- that no undeclared dependency message is available to the primitive
  clocks.

---

## 11. Obstruction catalogue

D1.6B-2A is not exact across a proposed operational partition when any of
the following occurs.

### O1 — Cross-domain conditioned correlation

\[
\operatorname{SchmidtRank}_{D|\bar D}(\Psi)>1.
\]

### O2 — Cross-domain effective-generator sector

A nonzero non-scalar support sector crosses an operational cut.

### O3 — Cross-domain marked jump

A marked jump support crosses an operational cut.

### O4 — Marked-unravelling mismatch

The boundary certificate and runtime use different marked instruments.

### O5 — Shared or aliased stochastic resources

A key, threshold, budget, counter, or candidate has multiple owners.

### O6 — Stale boundary certificate

The state, generator, catalogue, ownership, or relation version changes
without invalidating affected certificates.

### O7 — Inconsistent chart relations

The relation network has a nonpositive rate or fails cycle consistency.

### O8 — Approximate structure represented as exact

Small coupling, small Schmidt coefficients, or small sector norms are
set to zero without a proved error bound.

### O9 — Hidden memory outside the domain record

The continuation kernel depends on undeclared history, environment
records, or controller state.

### O10 — Improper primitive refinement

A correlated operational domain is split despite an equal-fibre
continuation witness.

### O11 — Implicit lifecycle transition

A merge or split occurs without a valid transactional boundary update.

### O12 — Scalar-sector duplication

The empty support sector of \(H_{\mathrm{eff}}\) is omitted or assigned
to more than one operational domain.

These are obstructions to the declared exact architecture. They do not
prove that a privileged fundamental scalar time exists.

---

## 12. Revised narrow scientific hypothesis

D1.6B-2A proposes the following restricted claim:

> On a declared finite pure-state marked-MCWF domain with a certified
> operational partition coarser than the unique finest exact
> state–generator–marked-unravelling partition, each disjoint operational
> domain supports a runtime-autonomous exact competing-risk clock despite
> arbitrary finite pure-state entanglement inside that domain. Consistent
> relations among those domain clocks reconstruct the bound finite
> marked-event chronology within connected relation components and the
> same event-poset/serialization-gauge class across unrelated components,
> while proper subdomains can be obstructed by equal-fibre continuation
> witnesses.

This claim is not frozen by v0.2.0.

---

## 13. Scope boundary

### In scope

- finite-dimensional pure conditioned branches;
- a fixed primitive tensor factorization;
- a fixed marked MCWF unravelling;
- piecewise-fixed effective generator and marked catalogue;
- exact product structure between certified operational domains;
- arbitrary finite pure-state entanglement within a domain;
- exact support sectors;
- disjoint active clock ownership;
- keyed competing-risk budgets and counters;
- certified initialization;
- positive-affine inter-domain clock relations;
- finite marked-event horizons;
- event-poset-qualified reconstruction;
- exact proper-subdomain continuation obstructions.

### Out of scope

- mixed conditioned trajectories;
- approximate factorization or weak-coupling bounds;
- autonomous discovery of the exact boundary certificate;
- generic time-dependent many-body generators;
- positive primitive clocks across an obstructed entangled cut;
- unravelling-independent temporal domains;
- continuum, thermodynamic, relativistic, or gravitational limits;
- universal absence of extensive collective coordination;
- the unrestricted assertion that physical time is nonfundamental;
- D1.6B-2B dynamic closure discovery;
- D1.6B-2C globalization and scaling;
- D1.6B-3 approximate/macroscopic closure.

A system-wide correlated operational domain is compatible with the
claim. The absence of primitive global scalar time does not imply the
absence of extensive collective temporal information.

---

## 14. Review gates before claim freeze

### G2A-01 — Pure-state factorization lemma

Verify the reduced-state-purity proof of Theorem 4.2.

### G2A-02 — Support-sector invariance

Verify the basis-independent direct-sum decomposition and sector support.

### G2A-03 — Marked-unravelling contract

Verify the permitted covariance transformations and excluded
phase-changing transformations.

### G2A-04 — Keyed-resource equivalence

Bind the exact key, counter, budget, renewal, retention, and candidate
semantics to the active successor.

### G2A-05 — Finest exact and operational partitions

Verify Theorem 4.6 and the distinction
\(\mathcal D_{\min}\preceq\mathcal D_{\mathrm{op}}\).

### G2A-06 — Normalization locality

Verify Theorem 9.2 including nonzero-flow and positive-hazard caveats.

### G2A-07 — Reconstruction inheritance

Verify certified initialization, no-global-runtime-state, and exact
inheritance from D1.6B-0 and D1.6B-1.

### G2A-08 — Proper-subdomain obstruction

Verify Theorem 9.7 and both explicit controls.

### G2A-09 — Dynamic-boundary separation

Verify that global/broader boundary certification is not conflated with
local runtime autonomy or D1.6B-2B discovery.

### G2A-10 — Claim-language audit

Verify all finite-horizon, fixed-unravelling, pure-state, operational,
and event-poset qualifications.

### G2A-11 — Exclusive ownership and lifecycle

Verify disjoint active clocks, single resource ownership, union merges,
certified splits, and transactional rollback.

### G2A-12 — Correlation-specific continuation obstruction

Verify the local-channel steering witness and absence of undeclared
dependency messages.

---

## 15. Future campaign implications

A future scientific campaign should include positive families for:

1. a Bell-entangled two-factor domain plus a remote independent domain;
2. a GHZ-type internal domain with exact external product structure;
3. domain-contained multifactor marked channels;
4. local marked channels whose continuation requires the full correlated
   domain state;
5. domain-chart gauge covariance;
6. calibration-root invariance;
7. exact agreement with the bound global marked MCWF successor;
8. admissible operational coarsening;
9. certified merge and restored-product split;
10. anchor-scalar invariance.

Adversarial families should include:

1. cross-domain entanglement;
2. hidden generator sector across a cut;
3. marked jump crossing a cut;
4. unravelling substitution;
5. key or budget aliasing;
6. stale boundary certification;
7. inconsistent chart relations;
8. approximate-rank spoofing;
9. hidden memory;
10. primitive equal-fibre obstruction;
11. overlapping clock ownership;
12. implicit split;
13. scalar-sector duplication;
14. undeclared correlation message.

No case set is frozen by this document.

---

## 16. Phase ladder

\[
\boxed{
\begin{aligned}
\text{D1.6B-2A:}\quad&
\text{exact correlated-domain clocks};\\
\text{D1.6B-2B:}\quad&
\text{dynamic closure discovery and domain growth/shrink};\\
\text{D1.6B-2C:}\quad&
\text{globalization obstruction and scaling};\\
\text{D1.6B-3:}\quad&
\text{approximate closure and macroscopic collective time}.
\end{aligned}
}
\]

D1.6B-2B remains unopened.

---

## 17. Revised conclusion

D1.6B-2A no longer assumes that every primitive line must retain its own
autonomous clock under entanglement.

Instead, it identifies:

1. a unique finest exact mathematical partition
   \(\mathcal D_{\min}\);
2. a certified disjoint operational clock partition
   \(\mathcal D_{\mathrm{op}}\);
3. exclusive ownership of states, channels, keys, budgets, counters, and
   certificates;
4. runtime-autonomous exact domain clocks after certified initialization.

The revised structural statement is

\[
\boxed{
\text{entanglement need not destroy temporal locality;}
\quad
\text{it can relocate the exact clock from primitive lines to a disjoint
correlated operational domain}.
}
\]

The next action is a complete re-audit of gates G2A-01 through G2A-12.
No claim freeze or executor construction is authorized by this revision.


---


# D1.6B-2A Foundations v0.2.1 — Normative Targeted Completion

**Status:** `TARGETED_COMPLETION_COMPLETE_FINAL_AUDIT_PENDING`

This amendment is normative and supersedes any inconsistent wording in
Foundations v0.2.0. All definitions and theorems not explicitly amended
remain unchanged.

## A. Exact active-successor finite-execution contract

### A.1 Normative successor binding

The finite execution semantics are bound to:

`LQTA_D_MCWF_POST_ARTICLE_QUALIFIED_SUCCESSOR_0_PRODUCTION_EXECUTOR_v0_2_0_MASTER_REMEDIATION_BOUND.zip`

SHA-256:

`4f58f4ad82f469970991e406f3123a25159d539188dd660e3956f4409821c0de`

Normative embedded sources:

- `rng.py`: `915647404419231ded95833ab54684d2f1a53c5d2ba61208b733620001f27d74`
- `mcwf.py`: `92adb94cbcdd440738bfe9bca6d4df2522fa49c78201e6636c99250ce0721f15`
- `constants.py`: `a6ef15097a6c146f2da321308d016a56b5cfe8e1ba8fc300b447a796e1c2f21a`
- `types.py`: `d40426e4069509a0f0c235eed67e50453d42464591cdb2ab2b3a6bd15657dbe5`
- `canonical.py`: `b7336b13da856f17b1297d0d16d854cc4a0af804f6f3cb0e92af4bfe0784ce08`

If prose and the bound source disagree on a finite-execution detail, the
bound source controls.

### A.2 Ideal law and deterministic keyed realization

The mathematical competing-risk model uses independent
\(E_\mu\sim\operatorname{Exp}(1)\) budgets. The frozen executor supplies
a deterministic keyed realization of that law; no cryptographic
independence theorem is claimed.

For global channel index \(j\), seed \(\sigma\), trajectory identifier
\(q\), generation counter \(c_j\), and role `wait_threshold`, the exact
event-key payload is

```json
{
  "namespace": "LQTAD-PA0",
  "seed": sigma,
  "trajectory": q,
  "channel": j,
  "generation": c_j,
  "role": "wait_threshold"
}
```

A domain preserves the global channel index. Local renumbering is
forbidden during a frozen run.

The canonical JSON payload is hashed with SHA-256. The first 16 bytes are
read as a big-endian integer \(n\), then

\[
u=\frac{n+\tfrac12}{2^{128}},
\qquad
E=-\log u,
\]

with the exact endpoint clamp in the bound `rng.py`.

### A.3 Residual-budget transition

At initialization, \(c_j=0\) and the keyed budget is generated from the
exact payload above.

When channel \(j_\star\) is selected:

1. every channel budget is reduced by its integrated hazard to the event;
2. the selected jump is applied and normalized;
3. \(c_{j_\star}\) increases by one;
4. only the selected budget is renewed from the new key;
5. every nonselected channel retains its remaining budget;
6. affected candidates are recomputed from retained budgets.

### A.4 Finite horizon and censoring

The default search horizon is

\[
H_{\mathrm{search}}=10000.0.
\]

`None` means `CENSORED_WITHIN_HORIZON`, never mathematical infinity.

The bound candidate solver:

- censors a jump operator with numerical norm at most \(10^{-15}\);
- starts bracketing at \(\min(0.03125,H_{\mathrm{search}})\);
- doubles the bracket up to the frozen horizon;
- uses the bound quadrature and Brent tolerances and iteration limits.

A campaign may alter the search horizon only by freezing the new value in
its evidence bindings.

### A.5 Tie semantics

For reached finite candidates \(d_j\),

\[
d_{\min}=\min_j d_j.
\]

The frozen tie test is

\[
|d_j-d_{\min}|
\le
10^{-10}\max(1,|d_{\min}|).
\]

The winner is the lowest global channel identifier in the tie set.

Candidate statuses, horizon, tie set, tie policy, consumed key, renewal
key, candidate keys, budgets, integrated hazards, counters, and state
digests are part of the bound event payload.

### A.6 Component-local advancement

A selected event advances every domain in the same connected calibrated
relation component to the corresponding event coordinate. Those domains
consume hazards over their induced physical durations.

A domain in an unrelated relation component is not advanced by that
event. No elapsed duration between unrelated components is physically
declared.

Thus D1.6B-2A has one next-event process per connected relation component.
Any total serialization across unrelated components is an audit
materialization belonging to the event-poset gauge.

## B. Componentwise reconstruction amendment

### Theorem B.1 — Exact componentwise reconstruction

Under the hypotheses of Theorem 9.4 and the exact contract in Section A,
the domain-clock engine reproduces the bound marked MCWF process within
each connected relation component in:

- selected marked channel;
- conditioned branch ray;
- keyed budgets and counters;
- reached/censored candidate status;
- tie set and lowest-channel winner;
- versions and valid certificates;
- marked-event order.

Across unrelated components it reproduces the same
event-poset/serialization-gauge class, not a privileged total order.

The phrase “selected marked channel” in Foundations v0.2.0 is henceforth
read componentwise unless an explicit audit serialization is requested.

## C. Admissible operational coarsening amendment

### Theorem C.1 — Calibrated or freshly initialized coarsening

A coarsening of operational domains is admissible only when:

1. the child clocks have a certified consistent calibration/gluing
   relation network defining the parent chart; or
2. the parent receives fresh certified initialization from a valid
   boundary certificate.

Channel identities, keys, budgets, counters, internal relations, and
ownership provenance must be preserved without duplication.

Under these conditions, coarsening leaves every componentwise marked
trajectory and the event-poset quotient unchanged.

Without calibration or fresh initialization, coarsening is forbidden
because it would insert an undeclared synchronization.

## D. Transactional lifecycle amendment

### D.1 Complete operational root

The authoritative immutable root is

\[
\mathfrak Q
=
(
\beta_C,
\mathcal D_{\mathrm{op}},
\omega_J,
\omega_{\mathsf M},
\omega_K,
\{\Theta_D\}_D,
\mathcal R,
\mathcal A,
\nu_{\mathrm{root}},
d_{\mathrm{root}}
).
\]

Its canonical serialization binds the operational partition, ownership
maps, domain states, stochastic resources, relations, versions, and all
pending candidates.

### D.2 Prepare–validate–commit

Every merge or split is copy-on-write:

\[
\mathfrak Q^-
\longrightarrow
\widetilde{\mathfrak Q}
\longrightarrow
\mathfrak Q^+.
\]

1. **Snapshot:** retain immutable \(\mathfrak Q^-\) and its digest.
2. **Prepare:** build \(\widetilde{\mathfrak Q}\) without mutation.
3. **Validate:** check branch factorization, generator/jump containment,
   relation consistency, exclusive ownership, unique resource transfer,
   archived provenance, and every D1.6B-1 precondition.
4. **Commit:** perform one atomic root replacement and one canonical
   transaction-ledger append.
5. **Post-commit:** increment affected versions exactly once and invalidate
   every certificate bound to changed state, generator, ownership,
   relation, or boundary digests.

### D.3 Exact rollback

Any failure before atomic commit leaves the authoritative state equal to
\(\mathfrak Q^-\).

The implementation must use copy-on-write plus atomic compare-and-swap or
an equivalent atomic root-pointer replacement. A failed commit cannot
expose partial state.

Rollback requires byte-identical canonical serialization:

\[
\operatorname{bytes}(\mathfrak Q_{\mathrm{after\ failure}})
=
\operatorname{bytes}(\mathfrak Q^-).
\]

A failure reported after a successful atomic commit is not rolled back;
the committed \(\mathfrak Q^+\) remains authoritative and the later
failure is logged separately.

## E. Completed frozen-claim candidate

> On a declared finite pure-state marked-MCWF domain with a certified
> operational partition coarser than the unique finest exact
> state–generator–marked-unravelling partition, each disjoint operational
> domain supports a runtime-autonomous exact competing-risk clock despite
> arbitrary finite pure-state entanglement inside that domain. Within
> each connected calibrated relation component, those clocks reproduce
> the bound finite marked-event process, including keyed budgets,
> finite-horizon censoring, and tie resolution. Across unrelated
> components they reconstruct the same event-poset/serialization-gauge
> class, not a physically privileged total order. Proper subdomains can
> be obstructed by equal-fibre continuation witnesses.

This amendment does not activate claim freeze. Claim freeze requires a
final all-gates audit.
