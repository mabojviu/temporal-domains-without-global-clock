from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import traceback
import venv
import zipfile

ROOT = Path(__file__).resolve().parent
AUTHORIZATION_ID = "LQTAD-D15-REPLAY1-1CEE6A47C5BAA1A0"
EXECUTOR_NAME = "LQTA_D_D1_5_REACHABLE_FIBRES_MINIMAL_SUFFICIENT_REGIONS_0_PRODUCTION_EXECUTOR_v0_2_0_METHOD_REPAIRED.zip"
EXECUTOR_ROOT_NAME = "LQTA_D_D1_5_REACHABLE_FIBRES_MINIMAL_SUFFICIENT_REGIONS_0_PRODUCTION_EXECUTOR_v0_2_0_METHOD_REPAIRED"
RETURN_NAME = "LQTAD_D15_REPLAY_1_WINDOWS_RETURN_v0_2_0.zip"

EXPECTED = {
    "CASE_SET.json": "e63554bd6fa5442d7b397f36e4c5c7a3558b73ad2598466858b28447217cdb1e",
    "LQTAD_D15_SCIENTIFIC_ATTEMPT_1_WINDOWS_RETURN_v0_2_0.zip": "901990ef573cc4bef21e086fa402264139fffa6b553fcac5c23855fe18d7f7d2",
    "LQTAD_D15_WINDOWS_PREFLIGHT_RETURN_v0_2_0.zip": "1b9e94655db948afc8e9d2542e0c713c41e35d72f9c231665e0f20801a43494a",
    "LQTA_D_D1_5_REACHABLE_FIBRES_MINIMAL_SUFFICIENT_REGIONS_0_PRODUCTION_EXECUTOR_v0_2_0_METHOD_REPAIRED.zip": "98f3d878d72e8fdd118352464494096abdf8fb57ef7f7567b19b53ae1f9153bc",
    "LQTA_D_D1_5_REPLAY_1_ONE_SHOT_AUTHORIZATION_v0_1_PACKAGE.zip": "b545f0954b75f07602a61484c85408ec5fa3c4d09fd0b8fde61f04cc8076047b",
    "LQTA_D_D1_5_SCIENTIFIC_ATTEMPT_1_INDEPENDENT_AUDIT_v0_1_PACKAGE.zip": "99259dcf411078865b4ed3fb79886a54962cd5505b172c9d92497e27c5dd5c50",
    "REFERENCE_RESULTS.json": "a862354d3961d70a0f75bb81f453622348a1409b673288eba9d2035d58cb6d0a",
    "REPLAY_AUTHORIZATION.json": "2c911854823fc11863f383775b355e9f2bd944991b5fe0512f26be3cae4cf516"
}

WORK = ROOT / "WORK_D15_REPLAY_1"
STAGE = ROOT / "RETURN_STAGE_D15_REPLAY_1"
VENV = ROOT / "VENV_D15_REPLAY_1"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def canonical_digest(obj: dict) -> str:
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    ).hexdigest()

def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )

def ledger_root() -> Path:
    preferred = Path("C:/LQTA/D15_DURABLE_REPLAY_LEDGER")
    if Path("C:/LQTA").exists():
        return preferred
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        raise RuntimeError("No durable replay-ledger root is available")
    return Path(local) / "LQTA" / "D15_DURABLE_REPLAY_LEDGER"

def venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

def run_logged(command: list[str], log_path: Path, env=None) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("wb") as log:
        cp = subprocess.run(
            command,
            cwd=ROOT,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )
    return int(cp.returncode)

def verify_inputs() -> None:
    failures = []
    for name, expected in EXPECTED.items():
        path = ROOT / name
        if not path.is_file():
            failures.append(f"missing: {name}")
            continue
        actual = sha256_file(path)
        if actual != expected:
            failures.append(f"sha256 mismatch: {name} actual={actual} expected={expected}")
    if failures:
        raise RuntimeError("; ".join(failures))

def create_claim(ledger: Path) -> Path:
    ledger.mkdir(parents=True, exist_ok=True)
    path = ledger / f"{AUTHORIZATION_ID}.claimed.json"
    payload = {
        "schema": "LQTAD-D15-DURABLE-REPLAY-LEDGER-1",
        "authorization_id": AUTHORIZATION_ID,
        "status": "CLAIMED_AND_CONSUMED_BEFORE_REPLAY_INVOCATION",
        "authorization_sha256": sha256_file(ROOT / "REPLAY_AUTHORIZATION.json"),
        "executor_sha256": sha256_file(ROOT / EXECUTOR_NAME),
        "case_set_sha256": sha256_file(ROOT / "CASE_SET.json"),
        "reference_results_sha256": sha256_file(ROOT / "REFERENCE_RESULTS.json"),
    }
    payload["claim_digest"] = canonical_digest(payload)
    data = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    return path

def create_completion(ledger: Path, report: Path | None, verdict: str, exit_code: int | None, status: str) -> Path:
    payload = {
        "schema": "LQTAD-D15-DURABLE-REPLAY-LEDGER-1",
        "authorization_id": AUTHORIZATION_ID,
        "status": status,
        "replay_exit_code": exit_code,
        "verdict": verdict,
        "replay_report_sha256": sha256_file(report) if report and report.is_file() else None,
    }
    payload["completion_digest"] = canonical_digest(payload)
    path = ledger / f"{AUTHORIZATION_ID}.completed.json"
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path

def copy_if_exists(source: Path, destination: Path) -> None:
    if not source.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        shutil.copytree(source, destination, dirs_exist_ok=True)
    else:
        shutil.copy2(source, destination)

def package_return() -> tuple[Path, str]:
    entries = []
    for p in sorted(STAGE.rglob("*")):
        if p.is_file() and p.name != "RETURN_MANIFEST.json":
            entries.append({
                "path": p.relative_to(STAGE).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    write_json(
        STAGE / "RETURN_MANIFEST.json",
        {"schema": "LQTAD-D15-REPLAY-RETURN-MANIFEST-1", "entries": entries},
    )

    out = ROOT / RETURN_NAME
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for p in sorted(STAGE.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(STAGE).as_posix())
    with zipfile.ZipFile(out) as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"return ZIP CRC failure: {bad}")
    digest = sha256_file(out)
    Path(str(out) + ".sha256").write_text(
        f"{digest}  {out.name}\n",
        encoding="ascii",
    )
    return out, digest

def main() -> int:
    ledger = ledger_root()
    ledger.mkdir(parents=True, exist_ok=True)
    claim_path = ledger / f"{AUTHORIZATION_ID}.claimed.json"
    completion_path = ledger / f"{AUTHORIZATION_ID}.completed.json"

    replay_invoked = False
    replay_exit_code = None
    wrapper_exit_code = 0
    classification = "UNSET"
    verdict = "NO_VERDICT"
    output = WORK / "REPLAY_OUTPUT"

    try:
        verify_inputs()
        auth = json.loads((ROOT / "REPLAY_AUTHORIZATION.json").read_text(encoding="utf-8"))
        if auth["authorization_id"] != AUTHORIZATION_ID:
            raise RuntimeError("replay authorization ID mismatch")
        if auth["status"] != "AUTHORIZED_ONE_SHOT":
            raise RuntimeError("replay authorization is not active")
        if auth["executor_sha256"] != sha256_file(ROOT / EXECUTOR_NAME):
            raise RuntimeError("authorization/executor mismatch")
        if auth["case_set_file_sha256"] != sha256_file(ROOT / "CASE_SET.json"):
            raise RuntimeError("authorization/case-set mismatch")
        if auth["reference_results_sha256"] != sha256_file(ROOT / "REFERENCE_RESULTS.json"):
            raise RuntimeError("authorization/reference-results mismatch")

        if claim_path.is_file():
            classification = "REPLAY_RERUN_BLOCKED_EXISTING_DURABLE_CLAIM"
            wrapper_exit_code = 4
            return wrapper_exit_code

        if WORK.exists():
            shutil.rmtree(WORK)
        if STAGE.exists():
            shutil.rmtree(STAGE)
        WORK.mkdir(parents=True)
        STAGE.mkdir(parents=True)

        with zipfile.ZipFile(ROOT / EXECUTOR_NAME) as zf:
            bad = zf.testzip()
            if bad is not None:
                raise RuntimeError(f"executor CRC failure: {bad}")
            zf.extractall(WORK)

        executor = WORK / EXECUTOR_ROOT_NAME
        if not executor.is_dir():
            raise RuntimeError("canonical executor root missing")

        if not venv_python().is_file():
            venv.EnvBuilder(with_pip=True, clear=False).create(VENV)
        python = venv_python()
        if not python.is_file():
            raise RuntimeError("virtual-environment Python not found")

        pip_code = run_logged(
            [
                str(python),
                "-m",
                "pip",
                "install",
                "--disable-pip-version-check",
                "-r",
                str(executor / "requirements.txt"),
            ],
            STAGE / "PIP_INSTALL_LOG.txt",
        )
        if pip_code != 0:
            classification = "PRECLAIM_DEPENDENCY_INSTALL_FAILURE"
            wrapper_exit_code = 10
            return wrapper_exit_code

        env = os.environ.copy()
        env["PYTHONPATH"] = str(executor / "src")
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONUTF8"] = "1"

        import_code = run_logged(
            [str(python), "-B", "-c", "import lqtad_d15,lqtad_pa0; print(lqtad_d15.__version__)"],
            STAGE / "IMPORT_SELF_CHECK_LOG.txt",
            env,
        )
        if import_code != 0:
            classification = "PRECLAIM_IMPORT_FAILURE"
            wrapper_exit_code = 11
            return wrapper_exit_code

        static_code = run_logged(
            [str(python), "-B", str(executor / "scripts" / "run_static_preflight.py")],
            STAGE / "STATIC_PREFLIGHT_LOG.txt",
            env,
        )
        if static_code != 0:
            classification = "PRECLAIM_STATIC_PREFLIGHT_FAILURE"
            wrapper_exit_code = 12
            return wrapper_exit_code

        validation_code = run_logged(
            [
                str(python),
                "-B",
                "-c",
                (
                    "import json;"
                    "from pathlib import Path;"
                    "from lqtad_d15.campaign import validate_case_set;"
                    "p=Path(r'" + str(ROOT / "CASE_SET.json").replace("\\", "\\\\") + "');"
                    "x=validate_case_set(json.loads(p.read_text(encoding='utf-8')));"
                    "print(json.dumps(x,sort_keys=True))"
                ),
            ],
            STAGE / "CASE_SET_VALIDATION_LOG.txt",
            env,
        )
        if validation_code != 0:
            classification = "PRECLAIM_CASE_SET_VALIDATION_FAILURE"
            wrapper_exit_code = 13
            return wrapper_exit_code

        create_claim(ledger)

        output.mkdir(parents=True, exist_ok=True)
        replay_invoked = True
        replay_exit_code = run_logged(
            [
                str(python),
                "-B",
                str(executor / "scripts" / "run_campaign.py"),
                "--case-set",
                str(ROOT / "CASE_SET.json"),
                "--output-dir",
                str(output),
            ],
            STAGE / "REPLAY_EXECUTION_LOG.txt",
            env,
        )

        regenerated = output / "RESULTS.json"
        reference = ROOT / "REFERENCE_RESULTS.json"
        if regenerated.is_file():
            reference_bytes = reference.read_bytes()
            regenerated_bytes = regenerated.read_bytes()
            byte_identical = reference_bytes == regenerated_bytes
            report = {
                "schema": "LQTAD-D15-REPLAY-REPORT-1",
                "authorization_id": AUTHORIZATION_ID,
                "reference_results_sha256": sha256_file(reference),
                "regenerated_results_sha256": sha256_file(regenerated),
                "byte_identical": byte_identical,
                "scientific_verdict": (
                    (output / "VERDICT.txt").read_text(encoding="utf-8").strip()
                    if (output / "VERDICT.txt").is_file()
                    else None
                ),
                "replay_process_exit_code": replay_exit_code,
            }
            report_path = output / "REPLAY_REPORT.json"
            write_json(report_path, report)
            verdict = "PASS_BYTE_IDENTICAL_REPLAY" if byte_identical and replay_exit_code == 0 else "FAIL_REPLAY_MISMATCH"
            (output / "REPLAY_VERDICT.txt").write_text(verdict + "\n", encoding="utf-8")
            wrapper_exit_code = 0 if verdict == "PASS_BYTE_IDENTICAL_REPLAY" else 2
            classification = (
                "REPLAY_COMPLETED_BYTE_IDENTICAL"
                if verdict == "PASS_BYTE_IDENTICAL_REPLAY"
                else "REPLAY_COMPLETED_MISMATCH"
            )
            create_completion(
                ledger,
                report_path,
                verdict,
                replay_exit_code,
                "REPLAY_COMPLETED",
            )
        else:
            verdict = "EXECUTION_ERROR_NO_REGENERATED_RESULTS"
            wrapper_exit_code = 20
            classification = "REPLAY_RETURNED_WITHOUT_RESULTS"
            create_completion(
                ledger,
                None,
                verdict,
                replay_exit_code,
                "REPLAY_EXECUTION_ERROR",
            )

        run_logged(
            [str(python), "-B", str(executor / "scripts" / "capture_environment.py")],
            STAGE / "ENVIRONMENT.json",
            env,
        )
        return wrapper_exit_code

    except BaseException as exc:
        wrapper_exit_code = 90
        classification = "REPLAY_HANDOFF_WRAPPER_EXCEPTION"
        write_json(
            STAGE / "WRAPPER_FAILURE.json",
            {
                "schema": "LQTAD-D15-REPLAY-WRAPPER-FAILURE-1",
                "authorization_id": AUTHORIZATION_ID,
                "exception_type": type(exc).__name__,
                "message": str(exc),
                "traceback": traceback.format_exc(),
            },
        )
        if claim_path.is_file() and not completion_path.is_file():
            create_completion(
                ledger,
                None,
                "WRAPPER_EXCEPTION_AFTER_CLAIM",
                replay_exit_code,
                "REPLAY_EXECUTION_ERROR",
            )
        return wrapper_exit_code

    finally:
        STAGE.mkdir(parents=True, exist_ok=True)
        copy_if_exists(output, STAGE / "REPLAY_OUTPUT")
        copy_if_exists(claim_path, STAGE / "REPLAY_LEDGER" / claim_path.name)
        copy_if_exists(completion_path, STAGE / "REPLAY_LEDGER" / completion_path.name)

        for name in [
            "REPLAY_AUTHORIZATION.json",
            "REFERENCE_RESULTS.json",
            "CASE_SET.json",
            "INPUT_HASHES.json",
        ]:
            copy_if_exists(ROOT / name, STAGE / "INPUTS" / name)

        write_json(
            STAGE / "RETURN_STATUS.json",
            {
                "schema": "LQTAD-D15-WINDOWS-REPLAY-RETURN-1",
                "authorization_id": AUTHORIZATION_ID,
                "classification": classification,
                "replay_invoked": replay_invoked,
                "replay_exit_code": replay_exit_code,
                "wrapper_exit_code": wrapper_exit_code,
                "claim_present": claim_path.is_file(),
                "completion_present": completion_path.is_file(),
                "results_present": (output / "RESULTS.json").is_file(),
                "replay_report_present": (output / "REPLAY_REPORT.json").is_file(),
                "verdict": verdict,
            },
        )

        try:
            out, digest = package_return()
            print("D1.5 replay return created:")
            print(out)
            print(digest)
            print(classification)
            print(f"Claim present: {claim_path.is_file()}")
            print(f"Completion present: {completion_path.is_file()}")
        except BaseException:
            traceback.print_exc()

if __name__ == "__main__":
    raise SystemExit(main())
