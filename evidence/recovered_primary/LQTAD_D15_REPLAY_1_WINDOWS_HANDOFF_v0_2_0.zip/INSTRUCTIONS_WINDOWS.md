# Windows replay instructions

1. Extract this ZIP into a new short folder, preferably:

   `C:\LQTA\D15R1`

2. Open PowerShell in that folder.

3. Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_replay_1.ps1
```

Expected return files:

- `LQTAD_D15_REPLAY_1_WINDOWS_RETURN_v0_2_0.zip`
- `LQTAD_D15_REPLAY_1_WINDOWS_RETURN_v0_2_0.zip.sha256`

Upload both files, including any non-pass diagnostic return. Do not rerun after the
durable replay claim exists.
