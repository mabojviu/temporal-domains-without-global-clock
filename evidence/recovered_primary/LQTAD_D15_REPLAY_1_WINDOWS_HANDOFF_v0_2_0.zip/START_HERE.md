# D1.5 external Replay 1

Authorization ID:

`LQTAD-D15-REPLAY1-1CEE6A47C5BAA1A0`

This handoff regenerates the accepted D1.5 Scientific Attempt 1 result from the exact
executor and case set. The required criterion is byte-identical equality of
`RESULTS.json`.

Use only `run_replay_1.ps1`.
