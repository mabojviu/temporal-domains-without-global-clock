# Numbering and non-retroactivity

This package is a phase-final D1.6B-1 qualification. It does not modify
CERT-009, the submitted article, D1.5, D1.6A, D1.6B-0 or any frozen
upstream artifact. No new master CERT number is assigned by this
package.
