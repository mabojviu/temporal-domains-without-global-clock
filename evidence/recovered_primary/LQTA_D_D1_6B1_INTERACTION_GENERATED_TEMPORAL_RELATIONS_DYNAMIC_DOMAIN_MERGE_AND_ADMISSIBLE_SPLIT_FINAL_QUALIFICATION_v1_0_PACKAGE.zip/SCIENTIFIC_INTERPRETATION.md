# Scientific interpretation

D1.6B-0 qualified reconstruction from an already consistent relational
network. D1.6B-1 qualifies the next finite constructive implication:

\[
\{\text{certified local interaction events}\}
\Longrightarrow
\{\mathcal R_{jk}(C)\}
\Longrightarrow
\{\mathcal D(C)\}
\Longrightarrow
\text{a dynamically reconfigured collective chronology}.
\]

The temporal relations are therefore not merely static input data in
this domain. They are created at local interfaces, updated when the
interaction changes, removed through an admissible split and used to
determine the current connected temporal domains.

The next open issue is not whether relations can change once a local
encounter is certified. It is how correlated or entangled conditioned
domains carry temporal information, and whether clocks must attach to
causally closed correlated domains rather than elementary factors.
