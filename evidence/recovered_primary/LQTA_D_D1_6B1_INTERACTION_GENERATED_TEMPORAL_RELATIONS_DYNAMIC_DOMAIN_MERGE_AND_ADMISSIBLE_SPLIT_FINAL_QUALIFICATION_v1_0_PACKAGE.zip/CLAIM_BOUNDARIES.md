# Claim boundaries

## Qualified

- Relation creation from certified active local interfaces.
- Sequential relational gluing of finite local-clock domains.
- Affine clock-gauge and calibration-root invariance.
- Dynamic domain merge.
- Exact affected-certificate invalidation.
- Remote-certificate preservation.
- Exact admissible split with archived relational provenance.
- Detection of the declared interaction, cycle, stale-interface,
  entanglement, residual-path, missing-provenance and invalidation
  obstructions.
- Structural absence of a primitive global-time object from the
  declared relation generator and domain selector.
- Byte-identical external replay.

## Not qualified

- Autonomous discovery of interface encounters.
- Generic many-body interacting MCWF reconstruction.
- Correlated or entangled branches as positive local-clock domains.
- Universal absence of extensive collective coordination.
- Continuum, relativistic or gravitational emergence.
- The unrestricted assertion that physical time is nonfundamental.
